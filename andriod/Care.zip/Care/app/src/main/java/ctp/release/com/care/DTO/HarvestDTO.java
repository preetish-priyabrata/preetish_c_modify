package ctp.release.com.care.DTO;

/**
 * Created by admin on 17-01-2018.
 */

public class HarvestDTO {
    String employee_id;
    String user_id;
    String district_name;
    String block_name;
    String GP_name;
    String Village_name;
    String enter_lat;
    String enter_long;
    String month_no;
    String present_year;
    String care_hhi_slno;
    String Spouse;
    String care_hhi;
    String women_name;
    String your_id_delete_phl_id;

    String class_training_status;
    String class_subject_matter;
    String demo_subject_matter;
    String care_implements_status;
    String care_farmer_parcticing;
    String class_male_present;
    String class_female_present;
    String demo_male_present;
    String demo_female_present;
    String inputs_provided_id;
    String demo_training_status;

    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getDistrict_name() {
        return district_name;
    }

    public void setDistrict_name(String district_name) {
        this.district_name = district_name;
    }

    public String getBlock_name() {
        return block_name;
    }

    public void setBlock_name(String block_name) {
        this.block_name = block_name;
    }

    public String getGP_name() {
        return GP_name;
    }

    public void setGP_name(String GP_name) {
        this.GP_name = GP_name;
    }

    public String getVillage_name() {
        return Village_name;
    }

    public void setVillage_name(String village_name) {
        Village_name = village_name;
    }

    public String getEnter_lat() {
        return enter_lat;
    }

    public void setEnter_lat(String enter_lat) {
        this.enter_lat = enter_lat;
    }

    public String getEnter_long() {
        return enter_long;
    }

    public void setEnter_long(String enter_long) {
        this.enter_long = enter_long;
    }

    public String getMonth_no() {
        return month_no;
    }

    public void setMonth_no(String month_no) {
        this.month_no = month_no;
    }

    public String getPresent_year() {
        return present_year;
    }

    public void setPresent_year(String present_year) {
        this.present_year = present_year;
    }

    public String getCare_hhi_slno() {
        return care_hhi_slno;
    }

    public void setCare_hhi_slno(String care_hhi_slno) {
        this.care_hhi_slno = care_hhi_slno;
    }

    public String getSpouse() {
        return Spouse;
    }

    public void setSpouse(String spouse) {
        Spouse = spouse;
    }

    public String getCare_hhi() {
        return care_hhi;
    }

    public void setCare_hhi(String care_hhi) {
        this.care_hhi = care_hhi;
    }

    public String getWomen_name() {
        return women_name;
    }

    public void setWomen_name(String women_name) {
        this.women_name = women_name;
    }

    public String getYour_id_delete_phl_id() {
        return your_id_delete_phl_id;
    }

    public void setYour_id_delete_phl_id(String your_id_delete_phl_id) {
        this.your_id_delete_phl_id = your_id_delete_phl_id;
    }

    public String getClass_training_status() {
        return class_training_status;
    }

    public void setClass_training_status(String class_training_status) {
        this.class_training_status = class_training_status;
    }

    public String getClass_subject_matter() {
        return class_subject_matter;
    }

    public void setClass_subject_matter(String class_subject_matter) {
        this.class_subject_matter = class_subject_matter;
    }

    public String getDemo_subject_matter() {
        return demo_subject_matter;
    }

    public void setDemo_subject_matter(String demo_subject_matter) {
        this.demo_subject_matter = demo_subject_matter;
    }

    public String getCare_implements_status() {
        return care_implements_status;
    }

    public void setCare_implements_status(String care_implements_status) {
        this.care_implements_status = care_implements_status;
    }

    public String getCare_farmer_parcticing() {
        return care_farmer_parcticing;
    }

    public void setCare_farmer_parcticing(String care_farmer_parcticing) {
        this.care_farmer_parcticing = care_farmer_parcticing;
    }

    public String getClass_male_present() {
        return class_male_present;
    }

    public void setClass_male_present(String class_male_present) {
        this.class_male_present = class_male_present;
    }

    public String getClass_female_present() {
        return class_female_present;
    }

    public void setClass_female_present(String class_female_present) {
        this.class_female_present = class_female_present;
    }

    public String getDemo_male_present() {
        return demo_male_present;
    }

    public void setDemo_male_present(String demo_male_present) {
        this.demo_male_present = demo_male_present;
    }

    public String getDemo_female_present() {
        return demo_female_present;
    }

    public void setDemo_female_present(String demo_female_present) {
        this.demo_female_present = demo_female_present;
    }

    public String getInputs_provided_id() {
        return inputs_provided_id;
    }

    public void setInputs_provided_id(String inputs_provided_id) {
        this.inputs_provided_id = inputs_provided_id;
    }

    public String getDemo_training_status() {
        return demo_training_status;
    }

    public void setDemo_training_status(String demo_training_status) {
        this.demo_training_status = demo_training_status;
    }
}
