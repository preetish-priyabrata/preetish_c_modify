package ctp.release.com.care;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import ctp.release.com.care.DTO.HarvestDTO;
import ctp.release.com.care.DTO.PhlDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

/**
 * Created by admin on 09-01-2018.
 */

public class Harvest_Lost_FromView extends AppCompatActivity {
    EditText year,month;
    EditText training,mentioned_subject,male,female,demonstration,subject_matter,dem_male,dem_female,name_input,implement,farmer_participate;
    String [] select_array = {"Yes","No"};
    Button save;
    ProgressDialog progressDialog;
    int i=0;
    AlertDialog dialog;
    GPSTracker mGPS;
    ArrayList<HarvestDTO> harvestDTOs = new ArrayList<HarvestDTO>();
SharedPreferenceClass sharedPreferenceClass;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    String [] subject_array = {"Improved Storing","FAQ and other on pluses,Veg/Fruit/Grains"};
    String monthId ="";
    DatabaseHandlerNew databaseHandlerNew;
    String [] input_data;
    ArrayList<PhlDTO> phlDTO = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.harvest_loss);
        sharedPreferenceClass = new SharedPreferenceClass(this);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        mGPS = new GPSTracker(Harvest_Lost_FromView.this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        progressDialog = new ProgressDialog(this);

        year = (EditText) findViewById(R.id.year);
        month = (EditText) findViewById(R.id.month);
        training = (EditText) findViewById(R.id.training);
        mentioned_subject = (EditText) findViewById(R.id.mentioned_subject);
        male = (EditText) findViewById(R.id.male);
        female = (EditText) findViewById(R.id.female);
        demonstration = (EditText) findViewById(R.id.demonstration);


        subject_matter = (EditText) findViewById(R.id.subject_matter);
        dem_male = (EditText) findViewById(R.id.dem_male);
        dem_female = (EditText) findViewById(R.id.dem_female);
        name_input = (EditText) findViewById(R.id.name_input);

        implement = (EditText) findViewById(R.id.implement);
        farmer_participate = (EditText) findViewById(R.id.farmer_participate);


        save = (Button) findViewById(R.id.save_farmland);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        year.setEnabled(false);
        month.setEnabled(false);
        training.setEnabled(false);
        mentioned_subject.setEnabled(false);
        male.setEnabled(false);
        female.setEnabled(false);
        demonstration.setEnabled(false);


        subject_matter.setEnabled(false);
        dem_male.setEnabled(false);
        dem_female.setEnabled(false);
        name_input.setEnabled(false);

        implement.setEnabled(false);
        farmer_participate.setEnabled(false);

        harvestDTOs = databaseHandlerNew.getHarvest_DataWithID(getIntent().getStringExtra("id"));

        year.setText(harvestDTOs.get(0).getPresent_year());
        month.setText((month_array[Integer.valueOf(harvestDTOs.get(0).getMonth_no())-1]));
        training.setText(getYesNo(harvestDTOs.get(0).getClass_training_status()));
        mentioned_subject.setText(harvestDTOs.get(0).getClass_subject_matter());
        male.setText(harvestDTOs.get(0).getClass_male_present());
        female.setText(harvestDTOs.get(0).getClass_female_present());
        demonstration.setText(harvestDTOs.get(0).getDemo_training_status());


        subject_matter.setText(getYesNo(harvestDTOs.get(0).getDemo_subject_matter()));
        dem_male.setText(harvestDTOs.get(0).getDemo_male_present());
        dem_female.setText(harvestDTOs.get(0).getDemo_female_present());
        name_input.setText(harvestDTOs.get(0).getInputs_provided_id());

        implement.setText(getYesNo(harvestDTOs.get(0).getCare_implements_status()));
        farmer_participate.setText(getYesNo(harvestDTOs.get(0).getCare_farmer_parcticing()));
    }
    private String getYesNo(String val){

        if(val.equals("1")){
            return "Yes";
        }
        else{
            return "No";
        }

    }
}
