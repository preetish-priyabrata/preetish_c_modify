package ctp.release.com.care;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import ctp.release.com.care.DTO.HHI_InOut_DTO;
import ctp.release.com.care.DTO.ThematicDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

/**
 * Created by admin on 09-01-2018.
 */

public class HHI_Input_OutputView extends AppCompatActivity {
    String [] thematic_intervation = {"HKG","Crop Diversification","LST","Post Harvest Management","poultry","Goatery","Diary","collective strenghtening","bcc"};
    String [] thematic_intervation_key;
    EditText date,activity, support,year,month;
    EditText production,consumption, sale,remark,signature;
    private int mYear, mMonth, mDay, mHour, mMinute;
SharedPreferenceClass sharedPreferenceClass;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    ArrayList<ThematicDTO> thematicDTOs ;
    String monthId ="",thematic_id = "";;
    GPSTracker mGPS;
    Button save;
    ProgressDialog progressDialog;
    int i=0;
    AlertDialog dialog;
    DatabaseHandlerNew databaseHandlerNew;
    ArrayList<HHI_InOut_DTO> hhi_inOut_dtos = new ArrayList<HHI_InOut_DTO>();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hhi_input_output);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        thematicDTOs = new ArrayList<ThematicDTO>();
        sharedPreferenceClass  = new SharedPreferenceClass(this);
        mGPS = new GPSTracker(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        progressDialog=new ProgressDialog(this);

        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);

        date= (EditText) findViewById(R.id.date);
        activity= (EditText) findViewById(R.id.activity);
        support= (EditText) findViewById(R.id.support);
        production= (EditText) findViewById(R.id.production);

        consumption= (EditText) findViewById(R.id.consumption);
        sale= (EditText) findViewById(R.id.sale);
        remark= (EditText) findViewById(R.id.remark);
        signature= (EditText) findViewById(R.id.signature);



        save= (Button) findViewById(R.id.save_farmland);

        year.setEnabled(false);
        month.setEnabled(false);

        date.setEnabled(false);
        activity.setEnabled(false);
        support.setEnabled(false);
        production.setEnabled(false);

        consumption.setEnabled(false);
        sale.setEnabled(false);
        remark.setEnabled(false);
        signature.setEnabled(false);


    save.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
finish();
       }
    });

        hhi_inOut_dtos = databaseHandlerNew.getHHI_InOut_DataWithID(getIntent().getStringExtra("id"));

        year.setText(hhi_inOut_dtos.get(0).getPresent_year());
        month.setText((month_array[Integer.valueOf(hhi_inOut_dtos.get(0).getMonth_no())-1]));

        date.setText(hhi_inOut_dtos.get(0).getDate_picker());
        activity.setText(hhi_inOut_dtos.get(0).getActivity());
        support.setText(hhi_inOut_dtos.get(0).getSupport());
        production.setText(hhi_inOut_dtos.get(0).getProduction());

        consumption.setText(hhi_inOut_dtos.get(0).getConsumption());
        sale.setText(hhi_inOut_dtos.get(0).getSale());
        remark.setText(hhi_inOut_dtos.get(0).getRemark());
       // signature.setText(hhi_inOut_dtos.get(0).getS());


    }




}
