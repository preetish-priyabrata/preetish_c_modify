package ctp.release.com.care;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import ctp.release.com.care.DTO.ShgFomDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

public class SHGFormView extends AppCompatActivity {
    EditText saving_passbook,passbook, gr_passbook,year,month,member_committee,committee_name,nutrition;
    EditText total_members,last_meet_date, member_presence,meeting_register,cash_book,linkage_credit,bank,member_linkage,technical_support;
    EditText purpose_linkage,topic_nutrition,accessed_agri,what_service,msp_faq,what_topic,discussed_agriculture,what_agriculture;
    private int mYear, mMonth, mDay, mHour, mMinute;
    SharedPreferenceClass sharedPreferenceClass;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    String [] committee_array = {"SMC","Health","Water&sanitations","PanchayatRaj","Ward Member","Forest Rights committee","ASHA","AWW","Other CRP"};
    String [] select_array = {"Yes","No"};
    String monthId ="";
    Button save;
    ProgressDialog progressDialog;
    int i=0;
    AlertDialog dialog;
    GPSTracker mGPS;
    DatabaseHandlerNew databaseHandlerNew;
    ArrayList<ShgFomDTO> shgFormDTOs = new ArrayList<ShgFomDTO>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shgform);
        sharedPreferenceClass  = new SharedPreferenceClass(this);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        mGPS = new GPSTracker(SHGFormView.this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        progressDialog=new ProgressDialog(this);

        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);

        last_meet_date= (EditText) findViewById(R.id.last_meet_date);
        total_members= (EditText) findViewById(R.id.total_members);
        member_presence= (EditText) findViewById(R.id.member_presence);
        meeting_register= (EditText) findViewById(R.id.meeting_register);

        cash_book= (EditText) findViewById(R.id.cash_book);
        linkage_credit= (EditText) findViewById(R.id.linkage_credit);
        bank= (EditText) findViewById(R.id.bank);
        member_linkage= (EditText) findViewById(R.id.member_linkage);
        technical_support= (EditText) findViewById(R.id.technical_support);
        saving_passbook= (EditText) findViewById(R.id.saving_passbook);
        passbook= (EditText) findViewById(R.id.passbook);
        gr_passbook= (EditText) findViewById(R.id.gr_passbook);
        member_committee= (EditText) findViewById(R.id.member_committee);
        committee_name= (EditText) findViewById(R.id.committee_name);
        nutrition= (EditText) findViewById(R.id.nutrition);

        purpose_linkage= (EditText) findViewById(R.id.purpose_linkage);
        topic_nutrition= (EditText) findViewById(R.id.topic_nutrition);
        accessed_agri= (EditText) findViewById(R.id.accessed_agri);
        what_service= (EditText) findViewById(R.id.what_service);
        msp_faq= (EditText) findViewById(R.id.msp_faq);
        what_topic= (EditText) findViewById(R.id.what_topic);
        discussed_agriculture= (EditText) findViewById(R.id.discussed_agriculture);
        what_agriculture= (EditText) findViewById(R.id.what_agriculture);



        save= (Button) findViewById(R.id.save_farmland);




        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

finish();
            }
        });



        year.setEnabled(false);
        month.setEnabled(false);

        last_meet_date.setEnabled(false);
        total_members.setEnabled(false);
        member_presence.setEnabled(false);
        meeting_register.setEnabled(false);

        cash_book.setEnabled(false);
        linkage_credit.setEnabled(false);
        bank.setEnabled(false);
        member_linkage.setEnabled(false);
        technical_support.setEnabled(false);
        saving_passbook.setEnabled(false);
        passbook.setEnabled(false);
        gr_passbook.setEnabled(false);
        member_committee.setEnabled(false);
        committee_name.setEnabled(false);
        nutrition.setEnabled(false);

        purpose_linkage.setEnabled(false);
        topic_nutrition.setEnabled(false);
        accessed_agri.setEnabled(false);
        what_service.setEnabled(false);
        msp_faq.setEnabled(false);
        what_topic.setEnabled(false);
        discussed_agriculture.setEnabled(false);
        what_agriculture.setEnabled(false);

        shgFormDTOs = databaseHandlerNew.getShg_form_dataWithID(getIntent().getStringExtra("id"));

        year.setText(shgFormDTOs.get(0).getPresent_year());
        month.setText((month_array[Integer.valueOf(shgFormDTOs.get(0).getMonth_no())-1]));

        last_meet_date.setText(shgFormDTOs.get(0).getLast_event_date());
        total_members.setText(shgFormDTOs.get(0).getNo_of_member());
        member_presence.setText(shgFormDTOs.get(0).getMember_present_month_meeting());
        meeting_register.setText(getYesNo(shgFormDTOs.get(0).getMeeting()));

        cash_book.setText(getYesNo(shgFormDTOs.get(0).getCash()));
        linkage_credit.setText(getYesNo(shgFormDTOs.get(0).getLinkage_external_credit()));
        bank.setText(shgFormDTOs.get(0).getBank_linked());
        member_linkage.setText(shgFormDTOs.get(0).getLinkages_market());
        technical_support.setText(shgFormDTOs.get(0).getLinkages_technical_support());
        saving_passbook.setText(getYesNo(shgFormDTOs.get(0).getSaving()));
        passbook.setText(getYesNo(shgFormDTOs.get(0).getIndividual()));
        gr_passbook.setText(shgFormDTOs.get(0).getGroup());
        member_committee.setText(shgFormDTOs.get(0).getCommittee_no_linked());
        committee_name.setText(shgFormDTOs.get(0).getCommittee_name());
        nutrition.setText(getYesNo(shgFormDTOs.get(0).getMonthly_status()));

        purpose_linkage.setText(getYesNo(shgFormDTOs.get(0).getPurpose_linkage()));
        topic_nutrition.setText(getYesNo(shgFormDTOs.get(0).getTopic_nutrition()));
        accessed_agri.setText(getYesNo(shgFormDTOs.get(0).getAccessed_agri()));
        what_service.setText(shgFormDTOs.get(0).getWhat_service());
        msp_faq.setText(getYesNo(shgFormDTOs.get(0).getMsp_faq()));
        what_topic.setText(shgFormDTOs.get(0).getWhat_topic());
        discussed_agriculture.setText(getYesNo(shgFormDTOs.get(0).getDiscussed_agriculture()));
        what_agriculture.setText(shgFormDTOs.get(0).getWhat_agriculture());

    }

    private String getYesNo(String val){

        if(val.equals("1")){
            return "Yes";
        }
        else{
            return "No";
        }

    }
}
