package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class TrainingDTO {
    String training_type;

    public String getTraining_type() {
        return training_type;
    }

    public void setTraining_type(String training_type) {
        this.training_type = training_type;
    }
}
