package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class PlusesDTO {
    String item_crop;

    public String getItem_crop() {
        return item_crop;
    }

    public void setItem_crop(String item_crop) {
        this.item_crop = item_crop;
    }
}
