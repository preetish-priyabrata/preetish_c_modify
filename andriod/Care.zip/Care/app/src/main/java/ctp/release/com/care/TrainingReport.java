package ctp.release.com.care;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import ctp.release.com.care.DTO.HhidDTO;
import ctp.release.com.care.DTO.LocationDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

/**
 * Created by admin on 11-01-2018.
 */

public class TrainingReport extends AppCompatActivity {
    Button find;
    EditText village_name;
    String [] select_array;
    String [] dist_array;
    String [] block_array;
    String [] gp_array;
    String village,dist,gp,block;
    AlertDialog dialog;
    ProgressDialog progressDialog;
    int i = 0;


    ArrayList<LocationDTO> locationInformation = new ArrayList<LocationDTO>();
    ArrayList<HhidDTO> HHiData = new ArrayList<HhidDTO>();
    DatabaseHandlerNew databaseHandlerNew;

    SharedPreferenceClass sharedPreferenceClass;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.training_report);
        progressDialog = new ProgressDialog(this);
        sharedPreferenceClass=new SharedPreferenceClass(this);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        find= (Button) findViewById(R.id.find);
        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TrainingReport.this,TrainingForm.class)
                        .putExtra("village",village)
                        .putExtra("gp",gp)
                        .putExtra("block",block)
                        .putExtra("dist",dist));
            }
        });


        if(databaseHandlerNew.getLocationCount()>0){

            locationInformation = databaseHandlerNew.getUserData();

            select_array = new String[locationInformation.size()];
            dist_array = new String[locationInformation.size()];
            block_array = new String[locationInformation.size()];
            gp_array = new String[locationInformation.size()];
            for (int j=0;j<locationInformation.size();j++) {

                select_array[j] = locationInformation.get(j).getCare_assU_village_id();
                dist_array[j] = locationInformation.get(j).getCare_assU_district_id();
                block_array[j] = locationInformation.get(j).getCare_assU_block_id();
                gp_array[j] = locationInformation.get(j).getCare_assU_gp_id();

            }

        }



        village_name = (EditText) findViewById(R.id.village_edit);
        village_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i < select_array.length; i++) {
                    if (select_array[i].equals(village_name.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(village_name, "Please select village",
                        select_array, pos);
            }
        });
       // getUserInfo();
    }


    private void showCoverageList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {

                                    block = block_array[i];
                                    village = select_array[i];
                                    gp = gp_array[i];
                                    dist = dist_array[i];
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }

    private void getUserInfo() {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_assigned_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            JSONObject jsonObject = new JSONObject(response);

                            JSONArray jsonArray = jsonObject.getJSONArray("Type_of_pulses");
                            JSONArray village = jsonObject.getJSONArray("location_information");



                            if (jsonArray.length() > 0) {


                                select_array = new String[village.length()];
                                dist_array = new String[village.length()];
                                block_array = new String[village.length()];
                                gp_array = new String[village.length()];
                                for (int j=0;j<village.length();j++){
                                    JSONObject object = village.getJSONObject(j);
                                    select_array[i] = object.getString("care_assU_village_id");
                                    dist_array[i] = object.getString("care_assU_district_id");
                                    block_array[i] = object.getString("care_assU_block_id");
                                    gp_array[i] = object.getString("care_assU_gp_id");



                                }


                            }
                            else{

                                Toast.makeText(TrainingReport.this, "No Data for this search",
                                        Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (i < 3) {
                        Log.e("Retry due to error ", "for time : " + i);
                        i++;
                        getUserInfo();
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(TrainingReport.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(TrainingReport.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {



                Map<String, String> params = new HashMap<>();
                params.put("employee_id",sharedPreferenceClass.getValue_string("employee_id"));
                params.put("userid",sharedPreferenceClass.getValue_string("userid"));



                Log.d("params are :", "" + params);
                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);
    }


}
