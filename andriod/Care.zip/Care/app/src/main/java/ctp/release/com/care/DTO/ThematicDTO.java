package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class ThematicDTO {
    String thematic_key;
    String thematic_name;

    public String getThematic_key() {
        return thematic_key;
    }

    public void setThematic_key(String thematic_key) {
        this.thematic_key = thematic_key;
    }

    public String getThematic_name() {
        return thematic_name;
    }

    public void setThematic_name(String thematic_name) {
        this.thematic_name = thematic_name;
    }
}
