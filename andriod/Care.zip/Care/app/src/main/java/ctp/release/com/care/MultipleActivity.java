package ctp.release.com.care;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.animation.LayoutTransition;
import android.app.Activity;
import android.content.Context;
/**
 * Created by admin on 26-01-2018.
 */

public class MultipleActivity extends AppCompatActivity {

    EditText textIn,textIn1;
    Button buttonAdd;
    LinearLayout container;
    Button buttonShowAll;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.multiple_activity);
        textIn = (EditText)findViewById(R.id.textin);
        textIn1 = (EditText)findViewById(R.id.textin1);
        buttonAdd = (Button)findViewById(R.id.add);
        container = (LinearLayout)findViewById(R.id.container);

        toolbar= (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar.setTitle(getIntent().getStringExtra("title"));
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        buttonAdd.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View arg0) {



                LayoutInflater layoutInflater =
                        (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                final View addView = layoutInflater.inflate(R.layout.row, null);
                final TextView textOut = (TextView)addView.findViewById(R.id.textout);
                final TextView textOut1 = (TextView)addView.findViewById(R.id.textout1);
                textOut.setText(textIn.getText().toString());
                textOut1.setText(textIn1.getText().toString());
                Button buttonRemove = (Button)addView.findViewById(R.id.remove);
                buttonRemove.setOnClickListener(new OnClickListener(){

                    @Override
                    public void onClick(View v) {
                        ((LinearLayout)addView.getParent()).removeView(addView);
                    }});




                container.addView(addView, 0);

                textIn.setText("");
                textIn1.setText("");
            }});

        LayoutTransition transition = new LayoutTransition();
        container.setLayoutTransition(transition);

        buttonShowAll = (Button)findViewById(R.id.showall);
        buttonShowAll.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View arg0) {

                String showallPrompt = "";
                String quantity = "";

                int childCount = container.getChildCount();


                for(int c=0; c<childCount; c++){
                    View childView = container.getChildAt(c);
                    TextView childTextView = (TextView)(childView.findViewById(R.id.textout));
                    TextView childTextView1 = (TextView)(childView.findViewById(R.id.textout1));
                    String childTextViewText = (String)(childTextView.getText());
                    String childTextViewText1 = (String)(childTextView1.getText());


                    if(showallPrompt.equals("")) {
                        showallPrompt = childTextViewText;
                        quantity = childTextViewText1;
                    }
                    else {
                        showallPrompt = showallPrompt + "," + childTextViewText;
                        quantity = quantity + "," + childTextViewText1;
                    }
                }

                Intent intent = getIntent();
                intent.putExtra("value", showallPrompt);
                intent.putExtra("quantity", quantity);
                setResult(10, intent);
                finish();

            }});
    }
}
