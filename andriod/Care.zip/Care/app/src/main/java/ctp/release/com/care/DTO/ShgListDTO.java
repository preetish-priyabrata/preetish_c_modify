package ctp.release.com.care.DTO;

/**
 * Created by admin on 19-01-2018.
 */

public class ShgListDTO {

    String care_shg_id;
    String care_shg_slno;
    String care_shg_name;
    String care_shg_village;

    public String getCare_shg_id() {
        return care_shg_id;
    }

    public void setCare_shg_id(String care_shg_id) {
        this.care_shg_id = care_shg_id;
    }

    public String getCare_shg_slno() {
        return care_shg_slno;
    }

    public void setCare_shg_slno(String care_shg_slno) {
        this.care_shg_slno = care_shg_slno;
    }

    public String getCare_shg_name() {
        return care_shg_name;
    }

    public void setCare_shg_name(String care_shg_name) {
        this.care_shg_name = care_shg_name;
    }

    public String getCare_shg_village() {
        return care_shg_village;
    }

    public void setCare_shg_village(String care_shg_village) {
        this.care_shg_village = care_shg_village;
    }
}
