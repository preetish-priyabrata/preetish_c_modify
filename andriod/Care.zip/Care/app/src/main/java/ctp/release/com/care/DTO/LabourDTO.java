package ctp.release.com.care.DTO;

/**
 * Created by admin on 17-01-2018.
 */

public class LabourDTO {
    String employee_id;
    String user_id;
    String district_name;
    String block_name;
    String GP_name;
    String Village_name;
    String enter_lat;
    String enter_long;
    String month_no;
    String present_year;
    String care_hhi_slno;
    String Spouse;
    String care_hhi;
    String women_name;
    String your_id_delete_phl_id;

    String traget_active_id;
    String class_training_status;
    String device_implement_status;
    String demostration_date;
    String implemant_device_name;
    String male_present;
    String female_present;
    String farmer_implement_male;
    String farmer_implement_female;


    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getDistrict_name() {
        return district_name;
    }

    public void setDistrict_name(String district_name) {
        this.district_name = district_name;
    }

    public String getBlock_name() {
        return block_name;
    }

    public void setBlock_name(String block_name) {
        this.block_name = block_name;
    }

    public String getGP_name() {
        return GP_name;
    }

    public void setGP_name(String GP_name) {
        this.GP_name = GP_name;
    }

    public String getVillage_name() {
        return Village_name;
    }

    public void setVillage_name(String village_name) {
        Village_name = village_name;
    }

    public String getEnter_lat() {
        return enter_lat;
    }

    public void setEnter_lat(String enter_lat) {
        this.enter_lat = enter_lat;
    }

    public String getEnter_long() {
        return enter_long;
    }

    public void setEnter_long(String enter_long) {
        this.enter_long = enter_long;
    }

    public String getMonth_no() {
        return month_no;
    }

    public void setMonth_no(String month_no) {
        this.month_no = month_no;
    }

    public String getPresent_year() {
        return present_year;
    }

    public void setPresent_year(String present_year) {
        this.present_year = present_year;
    }

    public String getCare_hhi_slno() {
        return care_hhi_slno;
    }

    public void setCare_hhi_slno(String care_hhi_slno) {
        this.care_hhi_slno = care_hhi_slno;
    }

    public String getSpouse() {
        return Spouse;
    }

    public void setSpouse(String spouse) {
        Spouse = spouse;
    }

    public String getCare_hhi() {
        return care_hhi;
    }

    public void setCare_hhi(String care_hhi) {
        this.care_hhi = care_hhi;
    }

    public String getWomen_name() {
        return women_name;
    }

    public void setWomen_name(String women_name) {
        this.women_name = women_name;
    }

    public String getYour_id_delete_phl_id() {
        return your_id_delete_phl_id;
    }

    public void setYour_id_delete_phl_id(String your_id_delete_phl_id) {
        this.your_id_delete_phl_id = your_id_delete_phl_id;
    }

    public String getTraget_active_id() {
        return traget_active_id;
    }

    public void setTraget_active_id(String traget_active_id) {
        this.traget_active_id = traget_active_id;
    }

    public String getClass_training_status() {
        return class_training_status;
    }

    public void setClass_training_status(String class_training_status) {
        this.class_training_status = class_training_status;
    }

    public String getDevice_implement_status() {
        return device_implement_status;
    }

    public void setDevice_implement_status(String device_implement_status) {
        this.device_implement_status = device_implement_status;
    }

    public String getDemostration_date() {
        return demostration_date;
    }

    public void setDemostration_date(String demostration_date) {
        this.demostration_date = demostration_date;
    }

    public String getImplemant_device_name() {
        return implemant_device_name;
    }

    public void setImplemant_device_name(String implemant_device_name) {
        this.implemant_device_name = implemant_device_name;
    }

    public String getMale_present() {
        return male_present;
    }

    public void setMale_present(String male_present) {
        this.male_present = male_present;
    }

    public String getFemale_present() {
        return female_present;
    }

    public void setFemale_present(String female_present) {
        this.female_present = female_present;
    }

    public String getFarmer_implement_male() {
        return farmer_implement_male;
    }

    public void setFarmer_implement_male(String farmer_implement_male) {
        this.farmer_implement_male = farmer_implement_male;
    }

    public String getFarmer_implement_female() {
        return farmer_implement_female;
    }

    public void setFarmer_implement_female(String farmer_implement_female) {
        this.farmer_implement_female = farmer_implement_female;
    }
}
