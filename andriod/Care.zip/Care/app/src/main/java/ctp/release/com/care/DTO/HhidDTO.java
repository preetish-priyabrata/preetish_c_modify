package ctp.release.com.care.DTO;

/**
 * Created by admin on 15-01-2018.
 */

public class HhidDTO {

    String hhid;
    String hhidsl;
    String woman_farmer;
    String spouse_name;

    public String getHhid() {
        return hhid;
    }

    public void setHhid(String hhid) {
        this.hhid = hhid;
    }

    public String getHhidsl() {
        return hhidsl;
    }

    public void setHhidsl(String hhidsl) {
        this.hhidsl = hhidsl;
    }

    public String getWoman_farmer() {
        return woman_farmer;
    }

    public void setWoman_farmer(String woman_farmer) {
        this.woman_farmer = woman_farmer;
    }

    public String getSpouse_name() {
        return spouse_name;
    }

    public void setSpouse_name(String spouse_name) {
        this.spouse_name = spouse_name;
    }
}
