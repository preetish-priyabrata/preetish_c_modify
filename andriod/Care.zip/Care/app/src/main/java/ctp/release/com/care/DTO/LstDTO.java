package ctp.release.com.care.DTO;

/**
 * Created by admin on 15-01-2018.
 */

public class LstDTO {

    String care_sl_no;
    String care_activity_name;

    public String getCare_sl_no() {
        return care_sl_no;
    }

    public void setCare_sl_no(String care_sl_no) {
        this.care_sl_no = care_sl_no;
    }

    public String getCare_activity_name() {
        return care_activity_name;
    }

    public void setCare_activity_name(String care_activity_name) {
        this.care_activity_name = care_activity_name;
    }
}
