package ctp.release.com.care.DTO;

/**
 * Created by admin on 18-01-2018.
 */

public class ShgFomDTO {
    String employee_id;
    String user_id;
    String district_name;
    String block_name;
    String GP_name;
    String Village_name;
    String enter_lat;
    String enter_long;
    String month_no;
    String present_year;
    String care_hhi_slno;
    String care_hhi;
    String care_shg_name;
    String your_delete_id;
    String Meeting;
    String Cash;
    String Individual;
    String Group;
    String Saving;
    String Monthly_status;
    String Linkage_external_credit;
    String no_of_member;
    String last_event_date;
    String member_present_month_meeting;
    String Bank_linked;
    String linkages_market;
    String linkages_technical_support;
    String committee_no_linked;
    String committee_name;

    String accessed_agri;
    String what_service;
    String msp_faq;
    String what_topic;
    String discussed_agriculture;
    String what_agriculture;
    String purpose_linkage;
    String topic_nutrition;

    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getDistrict_name() {
        return district_name;
    }

    public void setDistrict_name(String district_name) {
        this.district_name = district_name;
    }

    public String getBlock_name() {
        return block_name;
    }

    public void setBlock_name(String block_name) {
        this.block_name = block_name;
    }

    public String getGP_name() {
        return GP_name;
    }

    public void setGP_name(String GP_name) {
        this.GP_name = GP_name;
    }

    public String getVillage_name() {
        return Village_name;
    }

    public void setVillage_name(String village_name) {
        Village_name = village_name;
    }

    public String getEnter_lat() {
        return enter_lat;
    }

    public void setEnter_lat(String enter_lat) {
        this.enter_lat = enter_lat;
    }

    public String getEnter_long() {
        return enter_long;
    }

    public void setEnter_long(String enter_long) {
        this.enter_long = enter_long;
    }

    public String getMonth_no() {
        return month_no;
    }

    public void setMonth_no(String month_no) {
        this.month_no = month_no;
    }

    public String getPresent_year() {
        return present_year;
    }

    public void setPresent_year(String present_year) {
        this.present_year = present_year;
    }

    public String getCare_hhi_slno() {
        return care_hhi_slno;
    }

    public void setCare_hhi_slno(String care_hhi_slno) {
        this.care_hhi_slno = care_hhi_slno;
    }

    public String getCare_hhi() {
        return care_hhi;
    }

    public void setCare_hhi(String care_hhi) {
        this.care_hhi = care_hhi;
    }

    public String getMeeting() {
        return Meeting;
    }

    public void setMeeting(String meeting) {
        Meeting = meeting;
    }

    public String getCash() {
        return Cash;
    }

    public void setCash(String cash) {
        Cash = cash;
    }

    public String getIndividual() {
        return Individual;
    }

    public void setIndividual(String individual) {
        Individual = individual;
    }

    public String getGroup() {
        return Group;
    }

    public void setGroup(String group) {
        Group = group;
    }

    public String getSaving() {
        return Saving;
    }

    public void setSaving(String saving) {
        Saving = saving;
    }

    public String getMonthly_status() {
        return Monthly_status;
    }

    public void setMonthly_status(String monthly_status) {
        Monthly_status = monthly_status;
    }

    public String getLinkage_external_credit() {
        return Linkage_external_credit;
    }

    public void setLinkage_external_credit(String linkage_external_credit) {
        Linkage_external_credit = linkage_external_credit;
    }

    public String getNo_of_member() {
        return no_of_member;
    }

    public void setNo_of_member(String no_of_member) {
        this.no_of_member = no_of_member;
    }

    public String getLast_event_date() {
        return last_event_date;
    }

    public void setLast_event_date(String last_event_date) {
        this.last_event_date = last_event_date;
    }

    public String getMember_present_month_meeting() {
        return member_present_month_meeting;
    }

    public void setMember_present_month_meeting(String member_present_month_meeting) {
        this.member_present_month_meeting = member_present_month_meeting;
    }

    public String getBank_linked() {
        return Bank_linked;
    }

    public void setBank_linked(String bank_linked) {
        Bank_linked = bank_linked;
    }

    public String getLinkages_market() {
        return linkages_market;
    }

    public void setLinkages_market(String linkages_market) {
        this.linkages_market = linkages_market;
    }

    public String getLinkages_technical_support() {
        return linkages_technical_support;
    }

    public void setLinkages_technical_support(String linkages_technical_support) {
        this.linkages_technical_support = linkages_technical_support;
    }

    public String getCommittee_no_linked() {
        return committee_no_linked;
    }

    public void setCommittee_no_linked(String committee_no_linked) {
        this.committee_no_linked = committee_no_linked;
    }

    public String getCommittee_name() {
        return committee_name;
    }

    public void setCommittee_name(String committee_name) {
        this.committee_name = committee_name;
    }

    public String getCare_shg_name() {
        return care_shg_name;
    }

    public void setCare_shg_name(String care_shg_name) {
        this.care_shg_name = care_shg_name;
    }

    public String getYour_delete_id() {
        return your_delete_id;
    }

    public void setYour_delete_id(String your_delete_id) {
        this.your_delete_id = your_delete_id;
    }

    public String getAccessed_agri() {
        return accessed_agri;
    }

    public void setAccessed_agri(String accessed_agri) {
        this.accessed_agri = accessed_agri;
    }

    public String getWhat_service() {
        return what_service;
    }

    public void setWhat_service(String what_service) {
        this.what_service = what_service;
    }

    public String getMsp_faq() {
        return msp_faq;
    }

    public void setMsp_faq(String msp_faq) {
        this.msp_faq = msp_faq;
    }

    public String getWhat_topic() {
        return what_topic;
    }

    public void setWhat_topic(String what_topic) {
        this.what_topic = what_topic;
    }

    public String getDiscussed_agriculture() {
        return discussed_agriculture;
    }

    public void setDiscussed_agriculture(String discussed_agriculture) {
        this.discussed_agriculture = discussed_agriculture;
    }

    public String getWhat_agriculture() {
        return what_agriculture;
    }

    public void setWhat_agriculture(String what_agriculture) {
        this.what_agriculture = what_agriculture;
    }

    public String getPurpose_linkage() {
        return purpose_linkage;
    }

    public void setPurpose_linkage(String purpose_linkage) {
        this.purpose_linkage = purpose_linkage;
    }

    public String getTopic_nutrition() {
        return topic_nutrition;
    }

    public void setTopic_nutrition(String topic_nutrition) {
        this.topic_nutrition = topic_nutrition;
    }
}
