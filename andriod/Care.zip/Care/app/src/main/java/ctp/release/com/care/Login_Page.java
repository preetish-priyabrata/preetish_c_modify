package ctp.release.com.care;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

/**
 * Created by admin on 07-06-2017.
 */
public class Login_Page extends AppCompatActivity {
EditText user_id,password;
    TextView loginbutton,fogetpasswor_txt,signup;
    ProgressDialog progressDialog;
    SharedPreferenceClass sharedPreferenceClass;
    int i=0;
    String username,Password;
    SharedPreferences preferences;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_login);
        progressDialog=new ProgressDialog(this);

        sharedPreferenceClass = new SharedPreferenceClass(this);
        user_id= (EditText) findViewById(R.id.user_id);
        password= (EditText) findViewById(R.id.password);

        loginbutton= (TextView) findViewById(R.id.loginbutton);

        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username=user_id.getText().toString();
                Password=password.getText().toString();
               if(username.length() < 1){
                   user_id.setError("please enter username");

               }
                else if(Password.length() < 1){
                   password.setError("please enter password");
               }
                else{
                    login();
               }
            }
        });
    }

    private void login() {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_login/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject object= null;

                            if (jsonObject.getString("response_status").equals("1")){

                                JSONObject data = jsonObject.getJSONObject("user_information");
                                sharedPreferenceClass.setValue_string("employee_id",data.getString("employee_id"));
                                sharedPreferenceClass.setValue_string("user_name",data.getString("user_name"));
                                sharedPreferenceClass.setValue_string("userid",data.getString("userid"));
                                sharedPreferenceClass.setValue_string("isLogin","true");

                                Toast.makeText(Login_Page.this, "Login Successful", Toast.LENGTH_SHORT).show();



                                startActivity(new Intent(Login_Page.this,MainActivity.class));
                                finish();
                            }
                            else{
                                Toast.makeText(Login_Page.this, "Login Unsuccessful,Try again", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (i < 3) {
                        Log.e("Retry due to error ", "for time : " + i);
                        i++;
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(Login_Page.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(Login_Page.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Password:admin@123
                Map<String, String> params = new HashMap<>();
                params.put("email",user_id.getText().toString());
                params.put("password",password.getText().toString());


                Log.d("params are :", "" + params);

                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


    }

}

