package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class ShgDTO {
    String care_name;

    public String getCare_name() {
        return care_name;
    }

    public void setCare_name(String care_name) {
        this.care_name = care_name;
    }
}
