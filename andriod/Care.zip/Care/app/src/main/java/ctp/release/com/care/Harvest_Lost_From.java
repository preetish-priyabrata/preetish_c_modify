package ctp.release.com.care;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import ctp.release.com.care.DTO.PhlDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

/**
 * Created by admin on 09-01-2018.
 */

public class Harvest_Lost_From extends AppCompatActivity {
    EditText year,month;
    EditText training,mentioned_subject,male,female,demonstration,subject_matter,dem_male,dem_female,name_input,implement,farmer_participate;
    String [] select_array = {"Yes","No"};
    Button save;
    ProgressDialog progressDialog;
    int i=0;
    AlertDialog dialog;
    GPSTracker mGPS;
SharedPreferenceClass sharedPreferenceClass;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    String [] subject_array = {"Improved Storing","FAQ and other on pluses,Veg/Fruit/Grains"};
    String monthId ="";
    DatabaseHandlerNew databaseHandlerNew;
    String [] input_data;
    ArrayList<PhlDTO> phlDTO = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.harvest_loss);
        sharedPreferenceClass = new SharedPreferenceClass(this);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        mGPS = new GPSTracker(Harvest_Lost_From.this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        progressDialog=new ProgressDialog(this);
        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);
        training= (EditText) findViewById(R.id.training);
        mentioned_subject= (EditText) findViewById(R.id.mentioned_subject);
        male= (EditText) findViewById(R.id.male);
        female= (EditText) findViewById(R.id.female);
        demonstration= (EditText) findViewById(R.id.demonstration);


        subject_matter= (EditText) findViewById(R.id.subject_matter);
        dem_male= (EditText) findViewById(R.id.dem_male);
        dem_female= (EditText) findViewById(R.id.dem_female);
        name_input= (EditText) findViewById(R.id.name_input);

        implement= (EditText) findViewById(R.id.implement);
        farmer_participate= (EditText) findViewById(R.id.farmer_participate);

        training.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(training.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(training, "Please select",
                        select_array, pos,"training");
            }
        });
        demonstration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(demonstration.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(demonstration, "Please select",
                        select_array, pos, "demonstration");
            }
        });

        implement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(implement.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(implement, "Please select",
                        select_array, pos, "");
            }
        });

        farmer_participate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(farmer_participate.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(farmer_participate, "Please select",
                        select_array, pos, "");
            }
        });

        mentioned_subject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <subject_array.length; i++) {
                    if (subject_array[i].equals(mentioned_subject.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(mentioned_subject, "Please select",
                        subject_array, pos, "");
            }
        });
        subject_matter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <subject_array.length; i++) {
                    if (subject_array[i].equals(subject_matter.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(subject_matter, "Please select",
                        subject_array, pos, "");
            }
        });
           phlDTO = databaseHandlerNew.getPhlInput();
        input_data = new String[phlDTO.size()];
        for(int i=0;i<phlDTO.size();i++){
            input_data[i] = phlDTO.get(i).getPhl_name();
        }

        name_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <input_data.length; i++) {
                    if (input_data[i].equals(name_input.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(name_input, "Please select",
                        input_data, pos, "");
            }
        });


        save= (Button) findViewById(R.id.save_farmland);







        month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <month_array.length; i++) {
                    if (month_array[i].equals(month.getText().toString())) {
                        pos = i;
                    }
                }
                showMonthList(month, "Please select month",
                        month_array, pos);
            }
        });
        year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <year_array.length; i++) {
                    if (year_array[i].equals(year.getText().toString())) {
                        pos = i;
                    }
                }
                showYearList(year, "Please select year",
                        year_array, pos);
            }
        });




    save.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if(mGPS.canGetLocation) {
            sendToDatabase();
        }
        else{
            Toast.makeText(Harvest_Lost_From.this, "We can not get your location please enable your gps", Toast.LENGTH_SHORT).show();
        }

       }
    });

    }

    public void sendToDatabase(){

        Random r = new Random();
        int randomNumber = r.nextInt(1234567890);

        databaseHandlerNew.AddHarvest_loss_(sharedPreferenceClass.getValue_string("employee_id"),
       sharedPreferenceClass.getValue_string("userid"),
        getIntent().getStringExtra("dist"),
        getIntent().getStringExtra("block"),
        getIntent().getStringExtra("gp"),
        getIntent().getStringExtra("village"),
        String.valueOf(mGPS.getLatitude()),
        String.valueOf(mGPS.getLongitude()),
        monthId,
        year.getText().toString(),
        getIntent().getStringExtra("care_hhi_id"),
        getIntent().getStringExtra("care_spouse_name"),
        getIntent().getStringExtra("care_hhi_id"),
        getIntent().getStringExtra("care_women_farmer"),
        String.valueOf(randomNumber),
        getYesNo(training.getText().toString()),
        getYesNo(subject_matter.getText().toString()),
        getYesNo(demonstration.getText().toString()),
        getYesNo(implement.getText().toString()),
        getYesNo(farmer_participate.getText().toString()),
        male.getText().toString(),
        female.getText().toString(),
        dem_male.getText().toString(),
        dem_female.getText().toString(),
        name_input.getText().toString(),
        "2");

        Toast.makeText(Harvest_Lost_From.this, "Submitted", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(Harvest_Lost_From.this,Harvest_Lost_FromView.class);
        intent.putExtra("id",String.valueOf(randomNumber));
        startActivity(intent);
        finish();
    }

    private void submit() {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_phl_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject object= null;

                            if (jsonObject.getString("response_status").equals("1")){
                                Toast.makeText(Harvest_Lost_From.this, "Submitted", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                            else{
                                Toast.makeText(Harvest_Lost_From.this, "Please insert all data", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (i < 3) {
                        Log.e("Retry due to error ", "for time : " + i);
                        i++;
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(Harvest_Lost_From.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(Harvest_Lost_From.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Password:admin@123
                Map<String, String> params = new HashMap<>();
                params.put("employee_id",sharedPreferenceClass.getValue_string("employee_id"));
                params.put("userid",sharedPreferenceClass.getValue_string("userid"));
                params.put("district_name",getIntent().getStringExtra("dist"));
                params.put("block_name",getIntent().getStringExtra("block"));

                params.put("GP_name",getIntent().getStringExtra("gp"));
                params.put("Village_name",getIntent().getStringExtra("village"));
                params.put("enter_lat", String.valueOf(mGPS.getLatitude()));
                params.put("enter_long", String.valueOf(mGPS.getLongitude()));
                params.put("month_no",monthId);

                params.put("present_year",year.getText().toString());
                params.put("care_hhi_slno",getIntent().getStringExtra("care_hhi_id"));
                params.put("care_hhi",getIntent().getStringExtra("care_hhi_id"));
                params.put("women_name",getIntent().getStringExtra("care_women_farmer"));
                params.put("Spouse",getIntent().getStringExtra("care_spouse_name"));
                params.put("your_id_delete_phl_id","78");


                params.put("class_training_status",getYesNo(training.getText().toString()));
                params.put("class_subject_matter",getYesNo(subject_matter.getText().toString()));
                params.put("demo_subject_matter",getYesNo(demonstration.getText().toString()));
                params.put("care_implements_status",getYesNo(implement.getText().toString()));
                params.put("care_farmer_parcticing",getYesNo(farmer_participate.getText().toString()));



                params.put("class_male_present",male.getText().toString());
                params.put("class_female_present",female.getText().toString());
                params.put("demo_male_present",dem_male.getText().toString());
                params.put("demo_female_present",dem_female.getText().toString());
                params.put("inputs_provided_id",name_input.getText().toString());
                params.put("demo_training_status","2");




                Log.d("params are :", "" + params);

                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


    }

    private String getYesNo(String val){

        if(val.equals("Yes")){
            return "1";
        }
        else{
            return "2";
        }

    }
    private void showCoverageList(final EditText text3, String s3, final String[] coverage, int pos, final String name) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            if(name.endsWith("training"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    subject_matter.setEnabled(false);
                                    subject_matter.setText("");
                                    male.setEnabled(false);
                                    male.setText("0");
                                    female.setEnabled(false);
                                    female.setText("0");
                                }
                                else{
                                    subject_matter.setEnabled(true);
                                    subject_matter.setText("");
                                    male.setEnabled(true);
                                    male.setText("");
                                    female.setEnabled(true);
                                    female.setText("");
                                }
                            }
                            else if(name.endsWith("demonstration"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    mentioned_subject.setEnabled(false);
                                    mentioned_subject.setText("");
                                    dem_male.setEnabled(false);
                                    dem_male.setText("0");
                                    dem_female.setEnabled(false);
                                    dem_female.setText("0");
                                }
                                else{
                                    mentioned_subject.setEnabled(true);
                                    mentioned_subject.setText("");
                                    dem_male.setEnabled(true);
                                    dem_male.setText("");
                                    dem_female.setEnabled(true);
                                    dem_female.setText("");
                                }
                            }

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    private void showMonthList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    monthId = String.valueOf(i+1);
                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    private void showYearList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
}
