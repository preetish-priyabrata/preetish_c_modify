package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class PhlDTO {

    String phl_key;
    String phl_name;

    public String getPhl_key() {
        return phl_key;
    }

    public void setPhl_key(String phl_key) {
        this.phl_key = phl_key;
    }

    public String getPhl_name() {
        return phl_name;
    }

    public void setPhl_name(String phl_name) {
        this.phl_name = phl_name;
    }
}
