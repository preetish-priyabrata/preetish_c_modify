package ctp.release.com.care;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

/**
 * Created by admin on 09-01-2018.
 */

public class Labour_Saving_From extends AppCompatActivity {
    EditText year,month;
    EditText implement_device,target_activity,training_setting,demonstration_date,present_male,present_female,device_use,farmer_using_male,farmer_using_female;
    String [] select_array = {"Yes","No"};
    Button save;
    ProgressDialog progressDialog;
    int i=0;
    AlertDialog dialog;
SharedPreferenceClass sharedPreferenceClass;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    String [] target_array = {"Land Preparation","Planting and Showing","Transplanting","Weeding","Fertilizer & Application","Spraying","Irrigation","Harvesting","Others Specify"};
    private int mYear, mMonth, mDay, mHour, mMinute;
    String monthId ="";
    GPSTracker mGPS;
    DatabaseHandlerNew databaseHandlerNew;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.labour_saving);
        databaseHandlerNew=new DatabaseHandlerNew(this);
        sharedPreferenceClass = new SharedPreferenceClass(this);
        mGPS = new GPSTracker(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        progressDialog=new ProgressDialog(this);
        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);
        implement_device= (EditText) findViewById(R.id.implement_device);
        target_activity= (EditText) findViewById(R.id.target_activity);
        training_setting= (EditText) findViewById(R.id.training_setting);
        demonstration_date= (EditText) findViewById(R.id.demonstration_date);
        present_male= (EditText) findViewById(R.id.present_male);
        present_female= (EditText) findViewById(R.id.present_female);
        device_use= (EditText) findViewById(R.id.device_use);
        farmer_using_male= (EditText) findViewById(R.id.farmer_using_male);
        farmer_using_female= (EditText) findViewById(R.id.farmer_using_female);


        demonstration_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get Current Date
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(Labour_Saving_From.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                demonstration_date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

        training_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(training_setting.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(training_setting, "Please select",
                        select_array, pos,"training_setting");
            }
        });
        device_use.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(device_use.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(device_use, "Please select",
                        select_array, pos, "device_use");
            }
        });

        save= (Button) findViewById(R.id.save_farmland);





        month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <month_array.length; i++) {
                    if (month_array[i].equals(month.getText().toString())) {
                        pos = i;
                    }
                }
                showMonthList(month, "Please select month",
                        month_array, pos);
            }
        });

        target_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <target_array.length; i++) {
                    if (target_array[i].equals(target_activity.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(target_activity, "Please select",
                        target_array, pos, "");

            }
        });
        year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <year_array.length; i++) {
                    if (year_array[i].equals(year.getText().toString())) {
                        pos = i;
                    }
                }
                showYearList(year, "Please select year",
                        year_array, pos);
            }
        });




    save.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if(mGPS.canGetLocation) {
            sendToDatabase();
        }
        else{
            Toast.makeText(Labour_Saving_From.this, "We can not get your location please enable your gps", Toast.LENGTH_SHORT).show();
        }

       }
    });

    }


    public void sendToDatabase(){

        Random r = new Random();
        int randomNumber = r.nextInt(1234567890);

        databaseHandlerNew.AddHarvest_labour_(sharedPreferenceClass.getValue_string("employee_id"),
        sharedPreferenceClass.getValue_string("userid"),
        getIntent().getStringExtra("dist"),
        getIntent().getStringExtra("block"),
         getIntent().getStringExtra("gp"),
         getIntent().getStringExtra("village"),
         String.valueOf(mGPS.getLatitude()),
         String.valueOf(mGPS.getLongitude()),
         monthId,
        year.getText().toString(),
        "623",
        "sombaru",
        "102020100622",
        "ashimamajhi",
        String.valueOf(randomNumber),
        getYesNo(target_activity.getText().toString()),
        getYesNo(training_setting.getText().toString()),
        getYesNo(device_use.getText().toString()),
        demonstration_date.getText().toString(),
        implement_device.getText().toString(),
        present_male.getText().toString(), present_female.getText().toString(),
        farmer_using_male.getText().toString(),
        farmer_using_female.getText().toString()
        );
        Toast.makeText(Labour_Saving_From.this, "Submitted", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(Labour_Saving_From.this,Labour_Saving_FromView.class);
        intent.putExtra("id",String.valueOf(randomNumber));
        startActivity(intent);
        finish();

    }
    private void submit() {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_lst_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject object= null;

                            if (jsonObject.getString("response_status").equals("1")){
                                Toast.makeText(Labour_Saving_From.this, "Submitted", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                            else{
                                Toast.makeText(Labour_Saving_From.this, "Please insert all data", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (i < 3) {
                        Log.e("Retry due to error ", "for time : " + i);
                        i++;
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(Labour_Saving_From.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(Labour_Saving_From.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Password:admin@123
                Map<String, String> params = new HashMap<>();
                params.put("employee_id",sharedPreferenceClass.getValue_string("employee_id"));
                params.put("userid",sharedPreferenceClass.getValue_string("userid"));
                params.put("district_name",getIntent().getStringExtra("dist"));
                params.put("block_name",getIntent().getStringExtra("block"));

                params.put("GP_name",getIntent().getStringExtra("gp"));
                params.put("Village_name",getIntent().getStringExtra("village"));
                params.put("enter_lat", String.valueOf(mGPS.getLatitude()));
                params.put("enter_long", String.valueOf(mGPS.getLongitude()));
                params.put("month_no",monthId);

                params.put("present_year",year.getText().toString());
                params.put("care_hhi_slno","623");
                params.put("care_hhi","102020100622");
                params.put("women_name","ashimamajhi");
                params.put("Spouse","sombaru");
                params.put("your_id_delete_lst_id","78");


                params.put("traget_active_id",getYesNo(target_activity.getText().toString()));
                params.put("class_training_status",getYesNo(training_setting.getText().toString()));
                params.put("device_implement_status",getYesNo(device_use.getText().toString()));




                params.put("demostration_date",demonstration_date.getText().toString());
                params.put("implemant_device_name",implement_device.getText().toString());
                params.put("male_present",present_male.getText().toString());
                params.put("female_present",present_female.getText().toString());
                params.put("farmer_implement_male",farmer_using_male.getText().toString());
                params.put("farmer_implement_female",farmer_using_female.getText().toString());

                //params.put("traget_active_id","2");




                Log.d("params are :", "" + params);

                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


    }

    private String getYesNo(String val){

        if(val.equals("Yes")){
            return "1";
        }
        else{
            return "2";
        }

    }
    private void showCoverageList(final EditText text3, String s3, final String[] coverage, int pos, final String name) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            if(name.endsWith("training_setting"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    present_male.setEnabled(false);
                                    present_male.setText("0");
                                    present_female.setEnabled(false);
                                    present_female.setText("0");
                                }
                                else{
                                    present_male.setEnabled(true);
                                    present_male.setText("");
                                    present_female.setEnabled(true);
                                    present_female.setText("");
                                }
                            }
                            if(name.endsWith("device_use"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    farmer_using_male.setEnabled(false);
                                    farmer_using_male.setText("0");
                                    farmer_using_female.setEnabled(false);
                                    farmer_using_female.setText("0");
                                }
                                else{
                                    farmer_using_male.setEnabled(true);
                                    farmer_using_male.setText("");
                                    farmer_using_female.setEnabled(true);
                                    farmer_using_female.setText("");
                                }
                            }
                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    private void showMonthList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    monthId = String.valueOf(i+1);
                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    private void showYearList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
}
