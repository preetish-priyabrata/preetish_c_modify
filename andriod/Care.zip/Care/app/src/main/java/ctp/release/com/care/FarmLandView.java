package ctp.release.com.care;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import ctp.release.com.care.DTO.FarmlandDTO;
import ctp.release.com.care.DTO.PlusesDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;

/**
 * Created by admin on 09-01-2018.
 */

public class FarmLandView extends AppCompatActivity {
    EditText types,area,new_farmers, demo_plot,continue_farmers,year,month;
    EditText training,seed,fertilizer,pesticides,extension,others;
    EditText seed_quantity,fertilizer_quantity,pesticides_quantity,others_quantity,prod_cons,prod_sale,prod_total,prod_price;
    String [] select_array = {"Yes","No"};
    String [] pluses_array;
    Button save;
    ProgressDialog progressDialog;
    int i=0;
    AlertDialog dialog;
   SharedPreferenceClass sharedPreferenceClass;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    GPSTracker mGPS;
    String monthId ="";
    ArrayList<PlusesDTO> plusedata = new ArrayList<PlusesDTO>();
    ArrayList<String> get_eight;
    boolean[] bol;

    ArrayList<FarmlandDTO> farmlanddata = new ArrayList<FarmlandDTO>();
    DatabaseHandlerNew databaseHandlerNew;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.farmland);
        sharedPreferenceClass = new SharedPreferenceClass(this);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        mGPS = new GPSTracker(FarmLandView.this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        toolbar.setTitle("View");

        progressDialog = new ProgressDialog(this);

        year = (EditText) findViewById(R.id.year);
        month = (EditText) findViewById(R.id.month);
        types = (EditText) findViewById(R.id.type);
        area = (EditText) findViewById(R.id.area);
        new_farmers = (EditText) findViewById(R.id.new_farmer);
        demo_plot = (EditText) findViewById(R.id.demo_plot);
        continue_farmers = (EditText) findViewById(R.id.continued);
        training = (EditText) findViewById(R.id.training);
        seed = (EditText) findViewById(R.id.seed);
        fertilizer = (EditText) findViewById(R.id.fertilize);
        pesticides = (EditText) findViewById(R.id.pesticide);
        extension = (EditText) findViewById(R.id.extension);
        others = (EditText) findViewById(R.id.others);

        seed_quantity = (EditText) findViewById(R.id.seed_quantity);
        fertilizer_quantity = (EditText) findViewById(R.id.fertilizer_quantity);
        pesticides_quantity = (EditText) findViewById(R.id.pesticides_quantity);
        others_quantity = (EditText) findViewById(R.id.others_quantity);
        prod_cons = (EditText) findViewById(R.id.prod_cons);
        prod_sale = (EditText) findViewById(R.id.prod_sale);
        prod_total = (EditText) findViewById(R.id.prod_total);
        prod_price = (EditText) findViewById(R.id.prod_price);

        year.setEnabled(false);
        month.setEnabled(false);
        types.setEnabled(false);
        area.setEnabled(false);
        new_farmers.setEnabled(false);
        demo_plot.setEnabled(false);
        continue_farmers.setEnabled(false);
        training.setEnabled(false);
        seed.setEnabled(false);
        fertilizer.setEnabled(false);
        pesticides.setEnabled(false);
        extension.setEnabled(false);
        others.setEnabled(false);

        seed_quantity.setEnabled(false);
        fertilizer_quantity.setEnabled(false);
        pesticides_quantity.setEnabled(false);
        others_quantity.setEnabled(false);
        prod_cons.setEnabled(false);
        prod_sale.setEnabled(false);
        prod_total.setEnabled(false);
        prod_price.setEnabled(false);


        save = (Button) findViewById(R.id.save_farmland);


        farmlanddata = databaseHandlerNew.getFramlandDataWithID(getIntent().getStringExtra("id"));

        year.setText(farmlanddata.get(0).getPresent_year());
        month.setText(month_array[Integer.valueOf(farmlanddata.get(0).getMonth_no())-1]);
        types.setText(farmlanddata.get(0).getType_crop_pulse());
        area.setText(farmlanddata.get(0).getCultivated_area());
        new_farmers.setText(getYesNo(farmlanddata.get(0).getNew_farmers()));
        demo_plot.setText(getYesNo(farmlanddata.get(0).getDemo_farmers()));
        continue_farmers.setText(getYesNo(farmlanddata.get(0).getContinued_farmer()));
        training.setText(getYesNo(farmlanddata.get(0).getInput_received_training()));
        seed.setText(getYesNo(farmlanddata.get(0).getInput_received_seed()));
        fertilizer.setText(getYesNo(farmlanddata.get(0).getInput_received_fertiliser()));
        pesticides.setText(getYesNo(farmlanddata.get(0).getInput_received_pesticides()));
        extension.setText(getYesNo(farmlanddata.get(0).getInput_received_extension()));
        others.setText(getYesNo(farmlanddata.get(0).getOthers_input()));

        seed_quantity.setText(farmlanddata.get(0).getSeed_qnty());
        fertilizer_quantity.setText(farmlanddata.get(0).getFertiliser_qnty());
        pesticides_quantity.setText(farmlanddata.get(0).getPesticides_qnty());
        others_quantity.setText(farmlanddata.get(0).getOthers_qnty());
        prod_cons.setText(farmlanddata.get(0).getConsumption_production());
        prod_sale.setText(farmlanddata.get(0).getSale_production());
        prod_total.setText(farmlanddata.get(0).getTotal_production());
        prod_price.setText(farmlanddata.get(0).getAverage_price());

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }

    private String getYesNo(String val){

        if(val.equals("1")){
            return "Yes";
        }
        else{
            return "No";
        }

    }
}

