package ctp.release.com.care.adapter;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

import ctp.release.com.care.FarmLand;
import ctp.release.com.care.HHI_Input_Output;
import ctp.release.com.care.R;
import ctp.release.com.care.SHGForm;

/**
 * Created by admin on 10-01-2018.
 */

public class CustomShgAdapter extends RecyclerView.Adapter<CustomShgAdapter.MyViewHolder> {

    private final Activity context;
    ArrayList<HashMap<String, String>> taskdetails;
    ArrayList<String> pluses;
    private int i = 0;
    AlertDialog dialog;
    String select_to_fill = "";
    String village,dist,gp,block;
    String [] select_array = {"SHG tracking"};

    public CustomShgAdapter(Activity context, ArrayList<HashMap<String, String>> taskdetails, ArrayList<String> pluses, String village, String gp, String block, String dist) {
       // this.taskdetails = this.taskdetails;
      //  this.pluses = this.pluses;
        this.context = context;
        this.taskdetails=taskdetails;
        this.pluses=pluses;
        this.village = village;
        this.dist = dist;
        this.gp = gp;
        this.block = block;
    }

    @Override
    public CustomShgAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view1 = LayoutInflater.from(context).inflate(R.layout.custom_shg, parent, false);
        CustomShgAdapter.MyViewHolder holder = new CustomShgAdapter.MyViewHolder(view1);
        return holder;

    }

    @Override
    public void onBindViewHolder(final CustomShgAdapter.MyViewHolder holder, final int position) {
        holder.shg.setText(taskdetails.get(position).get("care_shg_name"));
        holder.village.setText(taskdetails.get(position).get("care_shg_village"));


        holder.editText_shg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(holder.editText_shg.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(holder.editText_shg, "Please select form",
                        select_array, pos);
            }
        });
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(select_to_fill.equals("")){
                    Toast.makeText(context, "Please select a from type", Toast.LENGTH_SHORT).show();
                }
               /* else if(select_to_fill.equals("HHI Input & Output Tracking")){
                    context.startActivity(new Intent(context, SHGForm.class));
                }*/
                else{
                    context.startActivity(new Intent(context, SHGForm.class)
                            .putExtra("village",village)
                            .putExtra("gp",gp)
                            .putExtra("block",block)
                            .putExtra("dist",dist)
                            .putExtra("Pluses",pluses)
                            .putExtra("care_shg_id",taskdetails.get(position).get("care_shg_id"))
                            .putExtra("care_shg_slno",taskdetails.get(position).get("care_shg_slno"))
                            .putExtra("care_shg_name",taskdetails.get(position).get("care_shg_name"))
                            .putExtra("care_shg_village",taskdetails.get(position).get("care_shg_village")));
                }

            }
        });


    }
    private void showCoverageList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    select_to_fill = select_array[i];
                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    @Override
    public int getItemCount() {
        return taskdetails.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView shg, village;
        EditText editText_shg;
        Button button;

        public MyViewHolder(View view1) {
            super(view1);
            shg = (TextView) view1.findViewById(R.id.shg_name);
            village = (TextView) view1.findViewById(R.id.Village);
            editText_shg = (EditText) view1.findViewById(R.id.spinner_shg);
            button= (Button) view1.findViewById(R.id.button_shg);




        }
    }
}