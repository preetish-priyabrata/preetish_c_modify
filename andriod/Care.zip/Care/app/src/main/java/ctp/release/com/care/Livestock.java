package ctp.release.com.care;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

public class Livestock extends AppCompatActivity {
    Toolbar toolbar;
    EditText year,month,training_stock,extension,no_animals,medicine,animals_received_medicine,vaccination,
            no_animals_vaccine,others_specify,animal_present,fodder,area_cultivated,new_farmers,conitued_farmers,extension_support,medicine_name,medicine_quantity,vaccination_name,vaccination_quantity,other_name,other_quantity;
    ProgressDialog progressDialog;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    String [] select_array = {"Yes","No"};
    String monthId ="";
    int i=0;
    Button save_livestock;

    AlertDialog dialog;
    SharedPreferenceClass sharedPreferenceClass;
    GPSTracker mGPS;
    DatabaseHandlerNew databaseHandlerNew;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_livestock);
        progressDialog=new ProgressDialog(this);
        sharedPreferenceClass=new SharedPreferenceClass(this);
        databaseHandlerNew=new DatabaseHandlerNew(this);
        mGPS = new GPSTracker(Livestock.this);
        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);


        training_stock= (EditText) findViewById(R.id.training_stock);
        extension= (EditText) findViewById(R.id.extension);
        no_animals= (EditText) findViewById(R.id.no_animals);
        medicine= (EditText) findViewById(R.id.medicine);
        animals_received_medicine= (EditText) findViewById(R.id.animals_received_medicine);
        vaccination= (EditText) findViewById(R.id.vaccination);
        no_animals_vaccine= (EditText) findViewById(R.id.no_animals_vaccine);
        others_specify= (EditText) findViewById(R.id.others_specify);

        animal_present= (EditText) findViewById(R.id.animal_present);
        fodder= (EditText) findViewById(R.id.fodder);
        area_cultivated= (EditText) findViewById(R.id.area_cultivated);
        new_farmers= (EditText) findViewById(R.id.new_farmers);
        conitued_farmers= (EditText) findViewById(R.id.conitued_farmers);

        extension_support= (EditText) findViewById(R.id.extension_support);
        medicine_name= (EditText) findViewById(R.id.medicine_name);
        medicine_quantity= (EditText) findViewById(R.id.medicine_quantity);
        vaccination_name= (EditText) findViewById(R.id.vaccination_name);
        vaccination_quantity= (EditText) findViewById(R.id.vaccination_quantity);
        other_name= (EditText) findViewById(R.id.other_name);
        other_quantity= (EditText) findViewById(R.id.other_quantity);


        save_livestock= (Button) findViewById(R.id.save_livestock);
        toolbar= (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <month_array.length; i++) {
                    if (month_array[i].equals(month.getText().toString())) {
                        pos = i;
                    }
                }
                showMonthList(month, "Please select month",
                        month_array, pos);

            }
        });

        year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <year_array.length; i++) {
                    if (year_array[i].equals(year.getText().toString())) {
                        pos = i;
                    }
                }
                showMonthList(year, "Please select year",
                        year_array, pos);

            }
        });

        training_stock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(training_stock.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(training_stock, "Please select",
                        select_array, pos, "");

            }
        });
        extension.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(extension.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(extension, "Please select",
                        select_array, pos,"extension");

            }
        });

        medicine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(medicine.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(medicine, "Please select",
                        select_array, pos, "medicine");

            }
        });
        vaccination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(vaccination.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(vaccination, "Please select",
                        select_array, pos, "vaccination");

            }
        });

        others_specify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(others_specify.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(others_specify, "Please select",
                        select_array, pos, "");

            }
        });
        fodder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(fodder.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(fodder, "Please select",
                        select_array, pos, "");

            }
        });
        new_farmers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(new_farmers.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(new_farmers, "Please select",
                        select_array, pos, "new_farmers");

            }
        });
        conitued_farmers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(conitued_farmers.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(conitued_farmers, "Please select",
                        select_array, pos, "conitued_farmers");

            }
        });


        medicine_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Livestock.this,
                        MultipleActivity.class);
                intent.putExtra("title","Quantity provided Medicine");
                startActivityForResult(intent , 1);
            }
        });
        medicine_quantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Livestock.this,
                        MultipleActivity.class);
                intent.putExtra("title","Quantity provided Medicine");
                startActivityForResult(intent , 1);
            }
        });
        vaccination_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Livestock.this,
                        MultipleActivity.class);
                intent.putExtra("title","Quantity provided Vaccination");
                startActivityForResult(intent , 2);
            }
        });
        vaccination_quantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Livestock.this,
                        MultipleActivity.class);
                intent.putExtra("title","Quantity provided Vaccination");
                startActivityForResult(intent , 2);
            }
        });
        other_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Livestock.this,
                        MultipleActivity.class);
                intent.putExtra("title","Quantity provided Others (Specify)");
                startActivityForResult(intent , 3);
            }
        });
        other_quantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Livestock.this,
                        MultipleActivity.class);
                intent.putExtra("title","Quantity provided Others (Specify)");
                startActivityForResult(intent , 3);
            }
        });



        save_livestock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mGPS.canGetLocation) {
                    sendDatabase();
                }
                else{
                    Toast.makeText(Livestock.this, "We can not get your location please enable your gps", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);

            if (requestCode == 1  && resultCode  == 10) {

               medicine_name.setText(data.getStringExtra("value"));
               medicine_quantity.setText(data.getStringExtra("quantity"));
            }
           else if (requestCode == 2  && resultCode  == 10) {

                vaccination_name.setText(data.getStringExtra("value"));
                vaccination_quantity.setText(data.getStringExtra("quantity"));
            }
           else if (requestCode == 3  && resultCode  == 10) {

                other_name.setText(data.getStringExtra("value"));
                other_quantity.setText(data.getStringExtra("quantity"));
            }
        } catch (Exception ex) {
            Toast.makeText(Livestock.this, ex.toString(),
                    Toast.LENGTH_SHORT).show();
        }

    }




    private void sendDatabase() {

        Random r = new Random();
        int randomNumber = r.nextInt(1234567890);

        databaseHandlerNew.AddLivestock( sharedPreferenceClass.getValue_string("employee_id"),
      sharedPreferenceClass.getValue_string("userid"),
      getIntent().getStringExtra("dist"),
       getIntent().getStringExtra("block"),
      getIntent().getStringExtra("gp"),
      getIntent().getStringExtra("village"),
       String.valueOf(mGPS.getLatitude()),
       String.valueOf(mGPS.getLongitude()),
       monthId,
     year.getText().toString(),
     getIntent().getStringExtra("care_hhi_id"),
     getIntent().getStringExtra("care_hhi_id"),
     getIntent().getStringExtra("care_women_farmer"),
     getIntent().getStringExtra("care_spouse_name"),
     String.valueOf(randomNumber),
      getIntent().getStringExtra("status"),
      getYesNo(training_stock.getText().toString()),
      getYesNo(extension.getText().toString()),
      no_animals.getText().toString(),
      getYesNo(medicine.getText().toString()),
      animals_received_medicine.getText().toString(),
      getYesNo(vaccination.getText().toString()),
      no_animals_vaccine.getText().toString(),
      getYesNo(others_specify.getText().toString()),
      "",
      animal_present.getText().toString(),
       getYesNo(fodder.getText().toString()),
      area_cultivated.getText().toString(),
      getYesNo(new_farmers.getText().toString()),
       getYesNo(conitued_farmers.getText().toString()),
       extension_support.getText().toString(),
       medicine_name.getText().toString().replace(",","##"),
       medicine_quantity.getText().toString().replace(",","##"),
       vaccination_name.getText().toString().replace(",","##"),
       vaccination_quantity.getText().toString().replace(",","##"),
       other_name.getText().toString().replace(",","##"),
       other_quantity.getText().toString().replace(",","##"));

        Toast.makeText(Livestock.this, "Submitted", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(Livestock.this,LivestockView.class);
        intent.putExtra("id",String.valueOf(randomNumber));
        startActivity(intent);
        finish();
    }

    private void submit() {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_live_stock_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject object= null;

                            if (jsonObject.getString("response_status").equals("1")){
                                Toast.makeText(Livestock.this, "Submitted", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                            else{
                                Toast.makeText(Livestock.this, "Please insert all data", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (i < 3) {
                        Log.e("Retry due to error ", "for time : " + i);
                        i++;
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(Livestock.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(Livestock.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Password:admin@123
                Map<String, String> params = new HashMap<>();
                params.put("employee_id",sharedPreferenceClass.getValue_string("employee_id"));
                params.put("userid",sharedPreferenceClass.getValue_string("userid"));
                params.put("district_name",getIntent().getStringExtra("dist"));
                params.put("block_name",getIntent().getStringExtra("block"));

                params.put("GP_name",getIntent().getStringExtra("gp"));
                params.put("Village_name",getIntent().getStringExtra("village"));
                params.put("enter_lat", String.valueOf(mGPS.getLatitude()));
                params.put("enter_long", String.valueOf(mGPS.getLongitude()));
                params.put("month_no",monthId);

                params.put("present_year",year.getText().toString());
                params.put("care_hhi_slno",getIntent().getStringExtra("care_hhi_id"));
                params.put("care_hhi",getIntent().getStringExtra("care_hhi_id"));
                params.put("women_name",getIntent().getStringExtra("care_women_farmer"));
                params.put("Spouse",getIntent().getStringExtra("care_spouse_name"));
                params.put("your_id_delete_livestock_id","60");
                params.put("type_insert_live_stock","4");

                params.put("input_training",getYesNo(training_stock.getText().toString()));
                params.put("input_extension_suport",getYesNo(extension.getText().toString()));
                params.put("input_extension_suport_animal_no",no_animals.getText().toString());

                params.put("input_medicine",getYesNo(medicine.getText().toString()));
                params.put("input_medicine_animal_no",animals_received_medicine.getText().toString());
                params.put("input_vaccination",getYesNo(vaccination.getText().toString()));
                params.put("input_vaccination_animal_no",no_animals_vaccine.getText().toString());
                params.put("input_other",others_specify.getText().toString());
                params.put("input_other_detail","");


                params.put("animal_present_no",animal_present.getText().toString());
                params.put("cultivating_fodder",getYesNo(fodder.getText().toString()));
                params.put("cultivated_area_fodder",area_cultivated.getText().toString());
                params.put("new_farmer",getYesNo(new_farmers.getText().toString()));
                params.put("continued_farmer",getYesNo(conitued_farmers.getText().toString()));


                params.put("care_LS_QP_extension_support","1");
                params.put("medicine_name_array","med1###med2###med3###med4");
                params.put("medicine_qnty_array","2ml###3ml###7ml###20ml");
                params.put("vaccination_name_array","");
                params.put("vaccination_qnty_array","");
                params.put("othera_name_array","oth1###oth2");
                params.put("othera_qnty_array","10ml###50ml");




                Log.d("params are :", "" + params);

                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);

    }

    private String getYesNo(String s) {

        if(s.equals("Yes")){
            return "1";
        }
        else{
            return "2";
        }

    }

    private void showYearList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }


    private void showMonthList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);



                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    monthId = String.valueOf(i+1);
                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }

    private void showCommitteeList(final EditText text3, String s3, final String[] coverage, int pos, final String name) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            if(name.endsWith("new_farmers"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    conitued_farmers.setText("Yes");
                                }
                                else{
                                    conitued_farmers.setText("No");
                                }
                            }
                            else if(name.endsWith("conitued_farmers"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    new_farmers.setText("Yes");
                                }
                                else{
                                    new_farmers.setText("No");
                                }
                            }

                            else if(name.endsWith("medicine"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    animals_received_medicine.setText("0");
                                    animals_received_medicine.setEnabled(false);
                                }
                                else{
                                    animals_received_medicine.setText("");
                                    animals_received_medicine.setEnabled(true);
                                }
                            }
                            else if(name.endsWith("extension"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    no_animals.setText("0");
                                    no_animals.setEnabled(false);
                                }
                                else{
                                    no_animals.setText("");
                                    no_animals.setEnabled(true);
                                }
                            }
                            else if(name.endsWith("vaccination"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    no_animals_vaccine.setText("0");
                                    no_animals_vaccine.setEnabled(false);
                                }
                                else{
                                    no_animals_vaccine.setText("");
                                    no_animals_vaccine.setEnabled(true);
                                }
                            }
                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }

}
