package ctp.release.com.care;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import ctp.release.com.care.DTO.PlusesDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;

/**
 * Created by admin on 09-01-2018.
 */

public class FarmLand extends AppCompatActivity {
    EditText types,area,new_farmers, demo_plot,continue_farmers,year,month;
    EditText training,seed,fertilizer,pesticides,extension,others;
DatabaseHandlerNew databaseHandlerNew;
    EditText seed_quantity,fertilizer_quantity,pesticides_quantity,others_quantity,prod_cons,prod_sale,prod_total,prod_price;
    String [] select_array = {"Yes","No"};
    String [] pluses_array;
    Button save;
    ProgressDialog progressDialog;
    int i=0;
    AlertDialog dialog;
   SharedPreferenceClass sharedPreferenceClass;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    GPSTracker mGPS;
    String monthId ="";
    ArrayList<PlusesDTO> plusedata = new ArrayList<PlusesDTO>();
    ArrayList<String> get_eight;
    boolean[] bol;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.farmland);
        sharedPreferenceClass = new SharedPreferenceClass(this);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        mGPS = new GPSTracker(FarmLand.this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        toolbar.setTitle(getIntent().getStringExtra("page"));

        progressDialog=new ProgressDialog(this);
        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);
        types= (EditText) findViewById(R.id.type);
        area= (EditText) findViewById(R.id.area);
        new_farmers= (EditText) findViewById(R.id.new_farmer);
        demo_plot= (EditText) findViewById(R.id.demo_plot);
        continue_farmers= (EditText) findViewById(R.id.continued);
        training= (EditText) findViewById(R.id.training);
        seed= (EditText) findViewById(R.id.seed);
        fertilizer= (EditText) findViewById(R.id.fertilize);
        pesticides= (EditText) findViewById(R.id.pesticide);
        extension= (EditText) findViewById(R.id.extension);
        others= (EditText) findViewById(R.id.others);

        seed_quantity= (EditText) findViewById(R.id.seed_quantity);
        fertilizer_quantity= (EditText) findViewById(R.id.fertilizer_quantity);
        pesticides_quantity= (EditText) findViewById(R.id.pesticides_quantity);
        others_quantity= (EditText) findViewById(R.id.others_quantity);
        prod_cons= (EditText) findViewById(R.id.prod_cons);
        prod_sale= (EditText) findViewById(R.id.prod_sale);
        prod_total= (EditText) findViewById(R.id.prod_total);
        prod_price= (EditText) findViewById(R.id.prod_price);




        save= (Button) findViewById(R.id.save_farmland);


        //ArrayList<String> data = getIntent().getStringArrayListExtra("Pluses");
        plusedata = databaseHandlerNew.getPluses();
        pluses_array = new String[plusedata.size()];
        for (int i =0 ;i<plusedata.size();i++){
            pluses_array[i] = plusedata.get(i).getItem_crop();
        }


        month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <month_array.length; i++) {
                    if (month_array[i].equals(month.getText().toString())) {
                        pos = i;
                    }
                }
                showMonthList(month, "Please select month",
                        month_array, pos);
            }
        });
        year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <year_array.length; i++) {
                    if (year_array[i].equals(year.getText().toString())) {
                        pos = i;
                    }
                }
                showYearList(year, "Please select year",
                        year_array, pos);
            }
        });

        types.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* int pos = -1;
                for (int i = 0; i <pluses_array.length; i++) {
                    if (pluses_array[i].equals(types.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(types, "Please select",
                        pluses_array, pos);)*/



                bol = new boolean[pluses_array.length];
                String[] getValue = types.getText().toString().split(",");

                for(int i=0;i<pluses_array.length;i++){
                    bol[i]= false;
                }

                for(int i=0;i<pluses_array.length;i++){

                    for(int j=0;j<getValue.length;j++){
                        if (pluses_array[i].equals(getValue[j])){
                            bol[i]=true;
                        }

                    }
                }

                showMultipleNum8("Please select pulses", pluses_array,bol);


            }
        });
        new_farmers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(new_farmers.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(new_farmers, "Please select",
                        select_array, pos,"new_farmers");
            }
        });

        demo_plot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(demo_plot.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(demo_plot, "Please select",
                        select_array, pos, "demo_plot");
            }
        });
        continue_farmers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(continue_farmers.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(continue_farmers, "Please select",
                        select_array, pos, "continue_farmers");
            }
        });


        training.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(training.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(training, "Please select",
                        select_array, pos, "");
            }
        });

        seed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(seed.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(seed, "Please select",
                        select_array, pos, "seed");
            }
        });

        fertilizer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(fertilizer.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(fertilizer, "Please select",
                        select_array, pos, "fertilizer");
            }
        });

        pesticides.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(pesticides.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(pesticides, "Please select",
                        select_array, pos, "pesticides");
            }
        });

        extension.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(extension.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(extension, "Please select",
                        select_array, pos, "");
            }
        });

        others.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(others.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(others, "Please select",
                        select_array, pos, "");
            }
        });

    save.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {


        if(mGPS.canGetLocation) {
            submit();
        }
        else{
            Toast.makeText(FarmLand.this, "We can not get your location please enable your gps", Toast.LENGTH_SHORT).show();
        }

       }
    });

    }
    private void submit() {
        Random r = new Random();
        int randomNumber = r.nextInt(1234567890);

        databaseHandlerNew.AddFarmLand(sharedPreferenceClass.getValue_string("employee_id"),
        sharedPreferenceClass.getValue_string("userid"),
        getIntent().getStringExtra("status"),
        types.getText().toString(),
        area.getText().toString(),
        getYesNo(new_farmers.getText().toString()),
        getYesNo(demo_plot.getText().toString()),
        getYesNo(continue_farmers.getText().toString()),
        getYesNo(training.getText().toString()),
        getYesNo(seed.getText().toString()),
        getYesNo(fertilizer.getText().toString()),
        getYesNo(pesticides.getText().toString()),
        getYesNo(extension.getText().toString()), "",
        others_quantity.getText().toString(),
        prod_price.getText().toString(),
        getYesNo(others.getText().toString()),
        seed_quantity.getText().toString(),
        fertilizer_quantity.getText().toString(),
        pesticides_quantity.getText().toString(),
        prod_cons.getText().toString(), prod_sale.getText().toString(),
        prod_total.getText().toString(),
        getIntent().getStringExtra("dist"),
        getIntent().getStringExtra("block"),
        getIntent().getStringExtra("gp"),
        getIntent().getStringExtra("village"),
        String.valueOf(mGPS.getLatitude()),
        String.valueOf(mGPS.getLongitude()),
        monthId, year.getText().toString(), getIntent().getStringExtra("care_hhi_id"),
        getIntent().getStringExtra("care_spouse_name"),
        getIntent().getStringExtra("care_hhi_id"),
        getIntent().getStringExtra("care_women_farmer"),String.valueOf(randomNumber));

        Toast.makeText(FarmLand.this, "Submitted", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(FarmLand.this,FarmLandView.class);
        intent.putExtra("id",String.valueOf(randomNumber));
        startActivity(intent);
        finish();



    }

    private String getYesNo(String val){

        if(val.equals("Yes")){
            return "1";
        }
        else{
            return "2";
        }

    }
    private void showCoverageList(final EditText text3, String s3, final String[] coverage, int pos, final String name) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            if(name.endsWith("new_farmers"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    continue_farmers.setText("Yes");
                                }
                                else{
                                    continue_farmers.setText("No");
                                 }
                            }
                            else if(name.endsWith("continue_farmers"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    new_farmers.setText("Yes");
                                }
                                else{
                                    new_farmers.setText("No");
                                }
                            }
                            else if(name.endsWith("seed"))
                            {
                                if (text3.getText().toString().equals("No")){
                                   seed_quantity.setText("0");
                                    seed_quantity.setEnabled(false);
                                }
                                else{
                                    seed_quantity.setText("");
                                    seed_quantity.setEnabled(true);
                                }
                            }
                            else if(name.endsWith("fertilizer"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    fertilizer_quantity.setText("0");
                                    fertilizer_quantity.setEnabled(false);
                                }
                                else{
                                    fertilizer_quantity.setText("");
                                    fertilizer_quantity.setEnabled(true);
                                }
                            }
                            else if(name.endsWith("pesticides"))
                            {
                                if (text3.getText().toString().equals("No")){
                                    pesticides_quantity.setText("0");
                                    pesticides_quantity.setEnabled(false);
                                }
                                else{
                                    pesticides_quantity.setText("");
                                    pesticides_quantity.setEnabled(true);
                                }
                            }
                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    private void showMonthList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    monthId = String.valueOf(i+1);
                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    private void showYearList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    protected void showMultipleNum8(String title,
                                    final String[] items, boolean[] bol) {
        @SuppressWarnings("rawtypes")


        final ArrayList<Integer> itemsSelected = new ArrayList();
        final ArrayList itemsNoSelected = new ArrayList();

        final ArrayList<String> item_name = new ArrayList<String>();
        get_eight = new ArrayList<String>();



        for(int i=0;i<bol.length;i++){
            if(bol[i]){
                itemsSelected.add(i);
            }
        }


        AlertDialog.Builder builder = new AlertDialog.Builder(FarmLand.this);
        builder.setTitle(title);
        builder.setMultiChoiceItems(items, bol,
                new DialogInterface.OnMultiChoiceClickListener() {
                    @SuppressWarnings("unchecked")
                    @Override
                    public void onClick(DialogInterface dialog,
                                        int selectedItemId, boolean isSelected) {
                        if (isSelected) {
                            itemsSelected.add(selectedItemId);

                        }
                        else if (itemsSelected.contains(selectedItemId)) {
                            itemsSelected.remove(Integer.valueOf(selectedItemId));
                        }
                    }
                })
                .setPositiveButton("Done",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                // Your logic when OK button is clicked

                                for (int i = 0; i < itemsSelected.size(); i++) {



                                    get_eight.add(pluses_array[itemsSelected.get(i)]);



                                }
                                types.setText(arraytoString(get_eight));




                            }
                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        });
        dialog = builder.create();
        dialog.show();

    }

    public static String arraytoString(List<String> language_arr) {
        String ret = "";
        if (language_arr.size() == 0) {
            ret = "";
        } else if (language_arr.size() == 1) {
            ret = language_arr.get(0);
        } else {
            for (int i = 0; i < language_arr.size(); i++) {
                if (i == language_arr.size() - 1) {
                    ret = ret + language_arr.get(i);
                } else {
                    ret = ret + language_arr.get(i) + ",";

                }
            }
        }


        return ret;
    }
}

