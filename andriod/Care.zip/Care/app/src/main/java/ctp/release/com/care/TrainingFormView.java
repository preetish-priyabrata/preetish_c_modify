package ctp.release.com.care;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ctp.release.com.care.DTO.CareDTO;
import ctp.release.com.care.DTO.ThematicDTO;
import ctp.release.com.care.DTO.TrainingFormDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

/**
 * Created by admin on 11-01-2018.
 */

public class TrainingFormView extends AppCompatActivity {
    String [] thematic_intervation = {"HKG","Crop Diversification","LST","Post Harvest Management","poultry","Goatery","Diary","collective strenghtening","bcc"};
    String [] thematic_intervation_key;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    String [] topic_array = {"please select thematic intervation"};
    String [] training_type_array = {"Fair/Mela","Group Interaction/FFS","Street play skit","Demosnstration","Exposure visit","Others(specify)"};
    String [] group_type_array = {"Women SHG","Farmer Group","General Partticipants","Other(Specify)"};
    String [] facilitator_array = {"CRP","MT","CBO","MEO"};

    ArrayList<String> get_eight;
    ArrayList<ThematicDTO> thematicDTOs ;
    ArrayList<CareDTO> careDTOs;
    boolean[] bol;
    EditText year,month,intervation,topics,training_date,time_training,no_participant_male,female_participant,
            covered,repeat_male,repeat_female,repeat_hhs,training_type,group_type,facilitator,external_res,remark_training;
    Button save_training;
    private int mYear, mMonth, mDay, mHour, mMinute;
    int i=0;
    String monthId="",thematic_id = "";
    AlertDialog dialog;
    ProgressDialog progressDialog;
    SharedPreferenceClass sharedPreferenceClass;
    GPSTracker mGPS;
    DatabaseHandlerNew databaseHandlerNew;
    ArrayList<TrainingFormDTO> trainingFormDTOs = new ArrayList<TrainingFormDTO>();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.training_form);
        progressDialog=new ProgressDialog(this);
        sharedPreferenceClass  = new SharedPreferenceClass(this);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        mGPS = new GPSTracker(this);
        thematicDTOs = new ArrayList<ThematicDTO>();
        careDTOs = new ArrayList<CareDTO>();

        thematicDTOs = databaseHandlerNew.getThematic();
        thematic_id = thematicDTOs.get(0).getThematic_key();
        careDTOs = databaseHandlerNew.getCare(thematic_id);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);
        intervation= (EditText) findViewById(R.id.intervation);
        topics= (EditText) findViewById(R.id.topics);
        training_date= (EditText) findViewById(R.id.training_date);
        time_training= (EditText) findViewById(R.id.time_training);
        no_participant_male= (EditText) findViewById(R.id.no_participant_male);
        female_participant= (EditText) findViewById(R.id.female_participant);
        covered= (EditText) findViewById(R.id.covered);
        repeat_male= (EditText) findViewById(R.id.repeat_male);
        repeat_female= (EditText) findViewById(R.id.repeat_female);
        repeat_hhs= (EditText) findViewById(R.id.repeat_hhs);
        training_type= (EditText) findViewById(R.id.training_type);
        group_type= (EditText) findViewById(R.id.group_type);
        facilitator= (EditText) findViewById(R.id.facilitator);
        external_res= (EditText) findViewById(R.id.external_res);
        remark_training= (EditText) findViewById(R.id.remark_training);

        year.setEnabled(false);
        month.setEnabled(false);
        intervation.setEnabled(false);
        topics.setEnabled(false);
        training_date.setEnabled(false);
        time_training.setEnabled(false);
        no_participant_male.setEnabled(false);
        female_participant.setEnabled(false);
        covered.setEnabled(false);
        repeat_male.setEnabled(false);
        repeat_female.setEnabled(false);
        repeat_hhs.setEnabled(false);
        training_type.setEnabled(false);
        group_type.setEnabled(false);
        facilitator.setEnabled(false);
        external_res.setEnabled(false);
        remark_training.setEnabled(false);

        save_training= (Button) findViewById(R.id.save_training);
        save_training.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
finish();
            }
        });

        trainingFormDTOs = databaseHandlerNew.getTraining_form_dataWithId(getIntent().getStringExtra("id"));

        year.setText(trainingFormDTOs.get(0).getPresent_year());
        month.setText((month_array[Integer.valueOf(trainingFormDTOs.get(0).getMonth_no())-1]));
        intervation.setText(trainingFormDTOs.get(0).getThematic_intervention_id());
        topics.setText(trainingFormDTOs.get(0).getTopics_covered());
        training_date.setText(trainingFormDTOs.get(0).getEvent_date());
        time_training.setText(trainingFormDTOs.get(0).getDuration_session());
        no_participant_male.setText(trainingFormDTOs.get(0).getMale_present());
        female_participant.setText(trainingFormDTOs.get(0).getFemale_present());
        covered.setText(trainingFormDTOs.get(0).getHhi_covered());
        repeat_male.setText(trainingFormDTOs.get(0).getMale_repeat());
        repeat_female.setText(trainingFormDTOs.get(0).getFemale_repeat());
        repeat_hhs.setText(trainingFormDTOs.get(0).getHhi_repeat());
        training_type.setText(trainingFormDTOs.get(0).getType_of_training());
        group_type.setText(trainingFormDTOs.get(0).getType_of_group());
        facilitator.setText(trainingFormDTOs.get(0).getTraining_facilitator());
        external_res.setText(trainingFormDTOs.get(0).getExternal_person());
        remark_training.setText(trainingFormDTOs.get(0).getRemark_detail());
    }


}
