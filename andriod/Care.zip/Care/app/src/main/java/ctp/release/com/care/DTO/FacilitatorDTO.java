package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class FacilitatorDTO {
    String facilitator_name;

    public String getFacilitator_name() {
        return facilitator_name;
    }

    public void setFacilitator_name(String facilitator_name) {
        this.facilitator_name = facilitator_name;
    }
}
