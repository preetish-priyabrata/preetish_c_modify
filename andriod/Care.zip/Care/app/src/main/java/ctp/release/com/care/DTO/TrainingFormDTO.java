package ctp.release.com.care.DTO;

/**
 * Created by admin on 18-01-2018.
 */

public class TrainingFormDTO {
    String employee_id;
    String user_id;
    String district_name;
    String block_name;
    String GP_name;
    String Village_name;
    String enter_lat;
    String enter_long;
    String month_no;
    String present_year;
    String your_delete_id;

    String thematic_intervention_id;
    String topics_covered;
    String event_date;
    String duration_session;
    String male_present;
    String female_present;
    String hhi_covered;
    String male_repeat;
    String female_repeat;
    String hhi_repeat;
    String type_of_training;
    String type_of_group;
    String training_facilitator;
    String remark_detail;
    String external_person;


    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getDistrict_name() {
        return district_name;
    }

    public void setDistrict_name(String district_name) {
        this.district_name = district_name;
    }

    public String getBlock_name() {
        return block_name;
    }

    public void setBlock_name(String block_name) {
        this.block_name = block_name;
    }

    public String getGP_name() {
        return GP_name;
    }

    public void setGP_name(String GP_name) {
        this.GP_name = GP_name;
    }

    public String getVillage_name() {
        return Village_name;
    }

    public void setVillage_name(String village_name) {
        Village_name = village_name;
    }

    public String getEnter_lat() {
        return enter_lat;
    }

    public void setEnter_lat(String enter_lat) {
        this.enter_lat = enter_lat;
    }

    public String getEnter_long() {
        return enter_long;
    }

    public void setEnter_long(String enter_long) {
        this.enter_long = enter_long;
    }

    public String getMonth_no() {
        return month_no;
    }

    public void setMonth_no(String month_no) {
        this.month_no = month_no;
    }

    public String getPresent_year() {
        return present_year;
    }

    public void setPresent_year(String present_year) {
        this.present_year = present_year;
    }

    public String getThematic_intervention_id() {
        return thematic_intervention_id;
    }

    public void setThematic_intervention_id(String thematic_intervention_id) {
        this.thematic_intervention_id = thematic_intervention_id;
    }

    public String getTopics_covered() {
        return topics_covered;
    }

    public void setTopics_covered(String topics_covered) {
        this.topics_covered = topics_covered;
    }

    public String getEvent_date() {
        return event_date;
    }

    public void setEvent_date(String event_date) {
        this.event_date = event_date;
    }

    public String getDuration_session() {
        return duration_session;
    }

    public void setDuration_session(String duration_session) {
        this.duration_session = duration_session;
    }

    public String getMale_present() {
        return male_present;
    }

    public void setMale_present(String male_present) {
        this.male_present = male_present;
    }

    public String getFemale_present() {
        return female_present;
    }

    public void setFemale_present(String female_present) {
        this.female_present = female_present;
    }

    public String getHhi_covered() {
        return hhi_covered;
    }

    public void setHhi_covered(String hhi_covered) {
        this.hhi_covered = hhi_covered;
    }

    public String getMale_repeat() {
        return male_repeat;
    }

    public void setMale_repeat(String male_repeat) {
        this.male_repeat = male_repeat;
    }

    public String getFemale_repeat() {
        return female_repeat;
    }

    public void setFemale_repeat(String female_repeat) {
        this.female_repeat = female_repeat;
    }

    public String getHhi_repeat() {
        return hhi_repeat;
    }

    public void setHhi_repeat(String hhi_repeat) {
        this.hhi_repeat = hhi_repeat;
    }

    public String getType_of_training() {
        return type_of_training;
    }

    public void setType_of_training(String type_of_training) {
        this.type_of_training = type_of_training;
    }

    public String getType_of_group() {
        return type_of_group;
    }

    public void setType_of_group(String type_of_group) {
        this.type_of_group = type_of_group;
    }

    public String getTraining_facilitator() {
        return training_facilitator;
    }

    public void setTraining_facilitator(String training_facilitator) {
        this.training_facilitator = training_facilitator;
    }

    public String getRemark_detail() {
        return remark_detail;
    }

    public void setRemark_detail(String remark_detail) {
        this.remark_detail = remark_detail;
    }

    public String getExternal_person() {
        return external_person;
    }

    public void setExternal_person(String external_person) {
        this.external_person = external_person;
    }

    public String getYour_delete_id() {
        return your_delete_id;
    }

    public void setYour_delete_id(String your_delete_id) {
        this.your_delete_id = your_delete_id;
    }
}
