package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class SubjectDTO {
    String subject_id;
    String subject_class;


    public String getSubject_id() {
        return subject_id;
    }

    public void setSubject_id(String subject_id) {
        this.subject_id = subject_id;
    }

    public String getSubject_class() {
        return subject_class;
    }

    public void setSubject_class(String subject_class) {
        this.subject_class = subject_class;
    }
}
