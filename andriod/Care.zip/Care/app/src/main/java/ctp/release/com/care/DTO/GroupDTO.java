package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class GroupDTO {

    String group_name;

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }
}
