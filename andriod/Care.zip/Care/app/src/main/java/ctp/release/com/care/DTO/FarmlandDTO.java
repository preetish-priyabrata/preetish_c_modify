package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class FarmlandDTO {

    private String employee_id;
    private String user_id;
    private String type_form_input;
    private String type_crop_pulse;

     private String cultivated_area;
     private String new_farmers;
     private String demo_farmers;
     private String continued_farmer;
     private String input_received_training;
     private String input_received_seed;
     private String input_received_fertiliser;
     private String input_received_pesticides;
     private String input_received_extension;
     private String specify_Input;
     private String others_qnty;
     private String Average_price;
     private String others_input;
     private String Seed_qnty;
     private String Fertiliser_qnty;
     private String Pesticides_qnty;
     private String Consumption_production;
     private String Sale_production;
     private String Total_production;
     private String district_name;
     private String block_name;
     private String GP_name;
     private String Village_name;
     private String enter_lat;
     private String enter_long;
     private String month_no;
     private String present_year;
     private String care_hhi_slno;
     private String Spouse;
     private String care_hhi;
     private String women_name;
     private String your_id_delete_crop;

    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getType_form_input() {
        return type_form_input;
    }

    public void setType_form_input(String type_form_input) {
        this.type_form_input = type_form_input;
    }

    public String getType_crop_pulse() {
        return type_crop_pulse;
    }

    public void setType_crop_pulse(String type_crop_pulse) {
        this.type_crop_pulse = type_crop_pulse;
    }

    public String getCultivated_area() {
        return cultivated_area;
    }

    public void setCultivated_area(String cultivated_area) {
        this.cultivated_area = cultivated_area;
    }

    public String getNew_farmers() {
        return new_farmers;
    }

    public void setNew_farmers(String new_farmers) {
        this.new_farmers = new_farmers;
    }

    public String getDemo_farmers() {
        return demo_farmers;
    }

    public void setDemo_farmers(String demo_farmers) {
        this.demo_farmers = demo_farmers;
    }

    public String getContinued_farmer() {
        return continued_farmer;
    }

    public void setContinued_farmer(String continued_farmer) {
        this.continued_farmer = continued_farmer;
    }

    public String getInput_received_training() {
        return input_received_training;
    }

    public void setInput_received_training(String input_received_training) {
        this.input_received_training = input_received_training;
    }

    public String getInput_received_seed() {
        return input_received_seed;
    }

    public void setInput_received_seed(String input_received_seed) {
        this.input_received_seed = input_received_seed;
    }

    public String getInput_received_fertiliser() {
        return input_received_fertiliser;
    }

    public void setInput_received_fertiliser(String input_received_fertiliser) {
        this.input_received_fertiliser = input_received_fertiliser;
    }

    public String getInput_received_pesticides() {
        return input_received_pesticides;
    }

    public void setInput_received_pesticides(String input_received_pesticides) {
        this.input_received_pesticides = input_received_pesticides;
    }

    public String getInput_received_extension() {
        return input_received_extension;
    }

    public void setInput_received_extension(String input_received_extension) {
        this.input_received_extension = input_received_extension;
    }

    public String getSpecify_Input() {
        return specify_Input;
    }

    public void setSpecify_Input(String specify_Input) {
        this.specify_Input = specify_Input;
    }

    public String getOthers_qnty() {
        return others_qnty;
    }

    public void setOthers_qnty(String others_qnty) {
        this.others_qnty = others_qnty;
    }

    public String getAverage_price() {
        return Average_price;
    }

    public void setAverage_price(String average_price) {
        Average_price = average_price;
    }

    public String getOthers_input() {
        return others_input;
    }

    public void setOthers_input(String others_input) {
        this.others_input = others_input;
    }

    public String getSeed_qnty() {
        return Seed_qnty;
    }

    public void setSeed_qnty(String seed_qnty) {
        Seed_qnty = seed_qnty;
    }

    public String getFertiliser_qnty() {
        return Fertiliser_qnty;
    }

    public void setFertiliser_qnty(String fertiliser_qnty) {
        Fertiliser_qnty = fertiliser_qnty;
    }

    public String getPesticides_qnty() {
        return Pesticides_qnty;
    }

    public void setPesticides_qnty(String pesticides_qnty) {
        Pesticides_qnty = pesticides_qnty;
    }

    public String getConsumption_production() {
        return Consumption_production;
    }

    public void setConsumption_production(String consumption_production) {
        Consumption_production = consumption_production;
    }

    public String getSale_production() {
        return Sale_production;
    }

    public void setSale_production(String sale_production) {
        Sale_production = sale_production;
    }

    public String getTotal_production() {
        return Total_production;
    }

    public void setTotal_production(String total_production) {
        Total_production = total_production;
    }

    public String getDistrict_name() {
        return district_name;
    }

    public void setDistrict_name(String district_name) {
        this.district_name = district_name;
    }

    public String getBlock_name() {
        return block_name;
    }

    public void setBlock_name(String block_name) {
        this.block_name = block_name;
    }

    public String getGP_name() {
        return GP_name;
    }

    public void setGP_name(String GP_name) {
        this.GP_name = GP_name;
    }

    public String getVillage_name() {
        return Village_name;
    }

    public void setVillage_name(String village_name) {
        Village_name = village_name;
    }

    public String getEnter_lat() {
        return enter_lat;
    }

    public void setEnter_lat(String enter_lat) {
        this.enter_lat = enter_lat;
    }

    public String getEnter_long() {
        return enter_long;
    }

    public void setEnter_long(String enter_long) {
        this.enter_long = enter_long;
    }

    public String getMonth_no() {
        return month_no;
    }

    public void setMonth_no(String month_no) {
        this.month_no = month_no;
    }

    public String getPresent_year() {
        return present_year;
    }

    public void setPresent_year(String present_year) {
        this.present_year = present_year;
    }

    public String getCare_hhi_slno() {
        return care_hhi_slno;
    }

    public void setCare_hhi_slno(String care_hhi_slno) {
        this.care_hhi_slno = care_hhi_slno;
    }

    public String getSpouse() {
        return Spouse;
    }

    public void setSpouse(String spouse) {
        Spouse = spouse;
    }

    public String getCare_hhi() {
        return care_hhi;
    }

    public void setCare_hhi(String care_hhi) {
        this.care_hhi = care_hhi;
    }

    public String getWomen_name() {
        return women_name;
    }

    public void setWomen_name(String women_name) {
        this.women_name = women_name;
    }

    public String getYour_id_delete_crop() {
        return your_id_delete_crop;
    }

    public void setYour_id_delete_crop(String your_id_delete_crop) {
        this.your_id_delete_crop = your_id_delete_crop;
    }
}
