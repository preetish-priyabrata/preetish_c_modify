package ctp.release.com.care.Database;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import java.util.ArrayList;
import java.util.HashMap;

import ctp.release.com.care.DTO.CareDTO;
import ctp.release.com.care.DTO.DemonDTO;
import ctp.release.com.care.DTO.FacilitatorDTO;
import ctp.release.com.care.DTO.FarmlandDTO;
import ctp.release.com.care.DTO.GroupDTO;
import ctp.release.com.care.DTO.HHI_InOut_DTO;
import ctp.release.com.care.DTO.HarvestDTO;
import ctp.release.com.care.DTO.HhidDTO;
import ctp.release.com.care.DTO.LabourDTO;
import ctp.release.com.care.DTO.LivestockDTO;
import ctp.release.com.care.DTO.LocationDTO;
import ctp.release.com.care.DTO.LstDTO;
import ctp.release.com.care.DTO.PhlDTO;
import ctp.release.com.care.DTO.PlusesDTO;
import ctp.release.com.care.DTO.ShgDTO;
import ctp.release.com.care.DTO.ShgFomDTO;
import ctp.release.com.care.DTO.ShgListDTO;
import ctp.release.com.care.DTO.SubjectDTO;
import ctp.release.com.care.DTO.ThematicDTO;
import ctp.release.com.care.DTO.TrainingDTO;
import ctp.release.com.care.DTO.TrainingFormDTO;

public class DatabaseHandlerNew extends SQLiteOpenHelper {
	// Database Version
	private static final int DATABASE_VERSION = 1;
	// Database Name
	private static final String DATABASE_NAME = "Care.db";





	//gudu
	private static final String ID = "id";
	private static final String LOCATION_INFORMATION_TABLE = "location_information_table";

	private static final String CARE_EMPLOYEE_ID = "care_assU_employee_id";
	private static final String HHID_ID = "hhid_id";
	private static final String HHID_SL = "hhid_sl";
	private static final String WOMAN_FARMER = "woman_farmer";
	private static final String SPOUSE_NAME = "spouse_name";


	private static final String SHG_LIST_TABLE = "shg_list_table";
	private static final String CARE_SHG_ID = "care_shg_id";
	private static final String CARE_SHG_SLNO = "care_shg_slno";
	private static final String CARE_SHG_VILLAGE = "care_shg_village";

	private static final String HHID_LIST_TABLE = "hhid_table";
	private static final String USER_ID = "user_id";
	private static final String CARE_DISTRICT_ID = "care_assU_district_id";
	private static final String CARE_BLOCK_ID = "care_assU_block_id";
	private static final String CARE_GP_ID = "care_assU_gp_id";
	private static final String CARE_VILLAGE_ID = "care_assU_village_id";

	private static final String TYPES_OF_PULSES_TABLE="Type_of_pulses";
	private static final String ITEM_CROP="item_crop";

	private static final String THEMATIC_INTERVATION_TABLE="Thematic_Intervention_new";
	private static final String THEMATIC_KEY="Thematic_key";
	private static final String THEMATIC_NAME="Thematic_name";

	private static final String TOPICS_COVERED_TABLE="Topics_Covered";
	private static final String CARE_TRAINING_NAME="care_training_name";
	private static final String CARE_TRAINING_THEMATIC="care_training_thematic";


	private static final String TYPE_OF_GROUP_TABLE="Type_of_group";
	private static final String CARE_GROUP_NAME="care_group_name";

	private static final String TRAINING_FACILITATOR_TABLE="Training_Facilitator";
	private static final String FACILITATOR_NAME="facilitator_name";


	private static final String TRAINING_TYPE_TABLE="Type_of_Training";
	private static final String TRAINING_NAME="care_trng_name";

	private static final String SHG_TYPE_TABLE="Type_of_shg_committee";
	private static final String CARE_COMMON_NAME="care_comm_name";

	private static final String SUBJECT_MATTER_TABLE="subject_matter_class";
	private static final String SUBJECT_ID="id_class";
	private static final String SUBJECT_CLASS="subject_class";

	private static final String SUBJECT_DEMONSTRTOR_TABLE="subject_matter_demonstrator";
	private static final String ID_DEMO="id_demo";
	private static final String SUBJECT_DEMO="subject_demo";


	private static final String PHL_INPUT_PROVIDE_TABLE="phl_Inputs_provided_table";
	private static final String PHL_INPUT_KEY="phl_input_key";
	private static final String PHL_INPUT_NAME="phl_input_name";

	private static final String LAST_TARGET_TABLE="lst_target_table";
	private static final String CARE_SL_NO="Care_slno";
	private static final String CARE_ACTIVITY_NAME="care_activity_name";

	private static final String FARMLAND_TABLE="farmland_table";
	private static final String TYPE_FROM_INPUT="type_form_input";
	private static final String TYPE_CROP_PULSE="type_crop_pulse";


	private static final String CULTIVATED_AREA="cultivated_area";
	private static final String NEW_FARMERS="new_farmers";
	private static final String DEMO_FARMERS="demo_farmers";
	private static final String CONTINUED_FARMER="continued_farmer";
	private static final String INPUT_RECEIVED_TRAINING="input_received_training";
	private static final String INPUT_RECEIVED_SEED="input_received_seed";
	private static final String INPUT_RECEIVED_FERTILISER="input_received_fertiliser";
	private static final String INPUT_RECEIVED_PESTICIDES="input_received_pesticides";
	private static final String INPUT_RECEIVED_EXTENSION="input_received_extension";
	private static final String SPECIFY_INPUT="specify_Input";
	private static final String OTHERS_QNTY="others_qnty";
	private static final String AVERAGE_PRICE="Average_price";
	private static final String OTHERS_INPUT="others_input";
	private static final String SEED_QNTY="Seed_qnty";
	private static final String FERTILSIER_QNTY="Fertiliser_qnty";
	private static final String PESTICIDES_QNTY="Pesticides_qnty";
	private static final String CONSUMPTION_PRODUTION="Consumption_production";
	private static final String SALE_PRODUTION="Sale_production";
	private static final String TOTAL_PRODUCTION="Total_production";
	private static final String DISTRICT_NAME="district_name";
	private static final String BLOCK_NAME="block_name";
	private static final String GP_NAME="GP_name";
	private static final String VILLAGE_NAME="Village_name";
	private static final String ENTER_LAT="enter_lat";
	private static final String ENTER_LONG="enter_long";
	private static final String MONTH_NO="month_no";
	private static final String PRESENT_YEAR="present_year";
	private static final String CARE_HHI_SLNO="care_hhi_slno";
	private static final String SPOUSE="Spouse";
	private static final String CARE_HHI="care_hhi";
	private static final String WOMEN_NAME="women_name";
	private static final String YOUR_ID_DELETE_CROP="your_id_delete_crop";

	private static final String HHI_INPUT_OUTPUT_TABLE ="hhi_input_output_table";
	private static final String DATE_PICKER ="date_picker";
	private static final String ACTIVITY ="activity";
	private static final String SUPPORT ="sipport";
	private static final String PRODUCTION ="production";
	private static final String CONSUMPTION ="consumption";
	private static final String SALE ="sale";
	private static final String REMARK ="remark";

	private static final String HARVEST_LOST_FORM_TABLE ="harvest_lost_form_table";
	private static final String CLASS_TRAINING_STATUS ="class_training_status";
	private static final String CLASS_SUBJECT_MATTER ="class_subject_matter";
	private static final String DEMO_SUBJECT_MATTER ="demo_subject_matter";
	private static final String CARE_IMPLEMENT_STATUS ="care_implements_status";
	private static final String CARE_FARMER_PARCTICING ="care_farmer_parcticing";
	private static final String CLASS_MALE_PRESENT ="class_male_present";
	private static final String CLASS_FEMALE_PRESENT ="class_female_present";
	private static final String DEMO_MALE_PRESENT ="demo_male_present";
	private static final String DEMO_FEMALE_PRESENT ="demo_female_present";

	private static final String INPUT_PROVIDED_ID ="inputs_provided_id";
	private static final String DEMO_TRAINING_STATUS ="demo_training_status";

	private static final String HARVEST_LABOUR_TABLE ="harvest_labour_table";
	private static final String TARGET_ACTIVE_ID ="traget_active_id";
	private static final String DEVICE_IMPLEMENT_STATUS ="device_implement_status";
	private static final String DEMONSTRATION_DATE ="demostration_date";
	private static final String IMPLEMENT_DEVICE_NAME ="implemant_device_name";
	private static final String MALE_PRESENT ="male_present";
	private static final String FEMALE_PRESNT ="female_present";
	private static final String FARMER_IMPLEMENTS_MALE ="farmer_implement_male";
	private static final String FARMER_IMPLEMENTS_FEMALE ="farmer_implement_female";


	private static final String SHG_FORM_TABLE ="shg_form_table";
	private static final String MEETING ="Meeting";
	private static final String CASH ="Cash";
	private static final String INDIVIDUAL ="Individual";
	private static final String GROUP ="Group_name";
	private static final String SAVING ="Saving";
	private static final String MONTHLY_STATUS ="Monthly_status";
	private static final String LINKAGE_EXTERNAL_CREDIT ="Linkage_external_credit";
	private static final String NO_OF_MEMBER ="no_of_member";
	private static final String LAST_EVENT_DATE ="last_event_date";
	private static final String MEMBER_PRESENT_MONTH_MEETING ="member_present_month_meeting";
	private static final String BANK_LINKED ="Bank_linked";
	private static final String LINKAGES_TECHNICAL_SUPPORT ="linkages_technical_support";
	private static final String COMMITTEE_NO_LINKED ="committee_no_linked";
	private static final String COMMITTEE_NAME ="committee_name";
	private static final String LINKAGES_MARKET ="linkages_market";
	private static final String CARE_SHG_NAME ="care_shg_name";

	private static final String ACCESS_AGRI ="accessed_agri";
	private static final String WHAT_SERVICE ="what_service";
	private static final String MSP_FAQ ="msp_faq";
	private static final String WHAT_TOPIC ="what_topic";
	private static final String DISCUSSED_AGRI ="discussed_agriculture";
	private static final String WHAT_AGRI ="what_agriculture";
	private static final String PURPOSE_LINKAGE ="purpose_linkage";
	private static final String TOPIC_NUTRITION ="topic_nutrition";

	private static final String TRAINING_FORM_TABLE ="training_form_table";
	private static final String THEMATIC_INTERVATION_ID ="thematic_intervention_id";
	private static final String TOPICS_COVERED ="topics_covered";
	private static final String EVENT_DATE ="event_date";
	private static final String DURATION_SESSION ="duration_session";
	private static final String MALE_PRESNT ="male_present";
	private static final String FEMALE_PRESENT ="female_present";
	private static final String HHI_COVERED ="hhi_covered";
	private static final String MALE_REPEAT ="male_repeat";
	private static final String FEMALE_REPEAT ="female_repeat";
	private static final String HHI_REPEAT ="hhi_repeat";
	private static final String TYPE_OF_TRAINING ="type_of_training";
	private static final String TYPE_OF_GROUP ="type_of_group";
	private static final String TRAINING_FACILITATOR ="training_facilitator";
	private static final String REMARK_DETAIL ="remark_detail";
	private static final String EXTERNAL_PERSON ="external_person";

	private static final String LIVESTOCK_TABLE ="livestock_table";
	private static final String YOUR_ID_DELETE_LIVESTOCK_ID ="your_id_delete_livestock_id";
	private static final String TYPE_INSERT_LIVE_STOCK ="type_insert_live_stock";
	private static final String INPUT_TRAINING ="input_training";
	private static final String INPUT_EXTENSION_SUPPORT ="input_extension_suport";
	private static final String INPUT_EXTENSION_SUPPORT_ANIMAL_NO ="input_extension_suport_animal_no";
	private static final String INPUT_MEDICINE ="input_medicine";
	private static final String INPUT_MEDICINE_ANIMAL_NO ="input_medicine_animal_no";
	private static final String INPUT_VACCINATION ="input_vaccination";
	private static final String INPUT_VACCINATION_ANIMAL_NO ="input_vaccination_animal_no";
	private static final String INPUT_OTHER ="input_other";
	private static final String INPUT_OTHER_DETAIL ="input_other_detail";
	private static final String ANIMAL_PRESENT_NO ="animal_present_no";
	private static final String CULTIVATING_FODDER ="cultivating_fodder";
	private static final String CULTIVATED_AREA_FODDER ="cultivated_area_fodder";

	private static final String NEW_FARMER ="new_farmer";


	private static final String CARE_LS_QP_EXTENSION_SUPPORT ="care_LS_QP_extension_support";
	private static final String MEDICINE_NAME_ARRAY ="medicine_name_array";
	private static final String MEDICINE_QNTY_ARRAY ="medicine_qnty_array";
	private static final String VACCINATION_NAME_ARRAY ="vaccination_name_array";
	private static final String VACCINATION_QNTY_ARRAY ="vaccination_qnty_array";
	private static final String OTHER_NAME_ARRAY ="othera_name_array";
	private static final String OTHER_QNTY_ARRAY ="othera_qnty_array";










	public DatabaseHandlerNew(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {



		String CREATE_LOCATION_TABLE = "CREATE TABLE " + LOCATION_INFORMATION_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_EMPLOYEE_ID + " TEXT,"
				+ CARE_DISTRICT_ID + " TEXT,"
				+ CARE_BLOCK_ID + " TEXT,"
				+ CARE_GP_ID + " TEXT,"
				+ CARE_VILLAGE_ID + " TEXT)";

		db.execSQL(CREATE_LOCATION_TABLE);

		String CREATE_HHID_TABLE = "CREATE TABLE " + HHID_LIST_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ HHID_ID + " TEXT,"
				+ HHID_SL + " TEXT,"
				+ WOMAN_FARMER + " TEXT,"
				+ SPOUSE_NAME + " TEXT,"
				+ VILLAGE_NAME + " TEXT)";

		db.execSQL(CREATE_HHID_TABLE);

		String CREATE_SHG_LIST_TABLE = "CREATE TABLE " + SHG_LIST_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_SHG_ID + " TEXT,"
				+ CARE_SHG_SLNO + " TEXT,"
				+ CARE_SHG_NAME + " TEXT,"
				+ CARE_SHG_VILLAGE + " TEXT)";

		db.execSQL(CREATE_SHG_LIST_TABLE);

		String CREATE_PULSES_TABLE = "CREATE TABLE " + TYPES_OF_PULSES_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ ITEM_CROP + " TEXT)";


		db.execSQL(CREATE_PULSES_TABLE);

		String CREATE_THEMATIC_INTERVATION_TABLE = "CREATE TABLE " + THEMATIC_INTERVATION_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ THEMATIC_KEY + " TEXT,"
				+ THEMATIC_NAME + " TEXT)";

		db.execSQL(CREATE_THEMATIC_INTERVATION_TABLE);

		String CREATE_TOPICS_COVERED_TABLE = "CREATE TABLE " + TOPICS_COVERED_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_TRAINING_NAME + " TEXT,"
				+ CARE_TRAINING_THEMATIC + " TEXT)";

		db.execSQL(CREATE_TOPICS_COVERED_TABLE);

		String CREATE_GROUP_TYPE_TABLE = "CREATE TABLE " + TYPE_OF_GROUP_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_GROUP_NAME + " TEXT)";

		db.execSQL(CREATE_GROUP_TYPE_TABLE);

		String CREATE_FACILITATOR_TABLE = "CREATE TABLE " + TRAINING_FACILITATOR_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

				+ FACILITATOR_NAME + " TEXT)";

		db.execSQL(CREATE_FACILITATOR_TABLE);

		String CREATE_TRAINING_TABLE = "CREATE TABLE " + TRAINING_TYPE_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

				+ TRAINING_NAME + " TEXT)";


		db.execSQL(CREATE_TRAINING_TABLE);

		String CREATE_SHG_TABLE = "CREATE TABLE " + SHG_TYPE_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_COMMON_NAME + " TEXT)";

		db.execSQL(CREATE_SHG_TABLE);

		String CREATE_SUBJET_MATTER_TABLE = "CREATE TABLE " + SUBJECT_MATTER_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ SUBJECT_ID + " TEXT,"
				+ SUBJECT_CLASS + " TEXT)";

		db.execSQL(CREATE_SUBJET_MATTER_TABLE);

		String CREATE_SUBJECT_DEMONSTRATION_TABLE = "CREATE TABLE " + SUBJECT_DEMONSTRTOR_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ ID_DEMO + " TEXT,"
				+ SUBJECT_DEMO + " TEXT)";

		db.execSQL(CREATE_SUBJECT_DEMONSTRATION_TABLE);

		String CREATE_PHL_INPUT_PROVIDE_TABLE = "CREATE TABLE " + PHL_INPUT_PROVIDE_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ PHL_INPUT_KEY + " TEXT,"
				+ PHL_INPUT_NAME + " TEXT)";

		db.execSQL(CREATE_PHL_INPUT_PROVIDE_TABLE);

		String CREATE_LST_TABLE = "CREATE TABLE " + LAST_TARGET_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_SL_NO + " TEXT,"
				+ CARE_ACTIVITY_NAME + " TEXT)";

		db.execSQL(CREATE_LST_TABLE);


		String CREATE_FARMLAND_TABLE = "CREATE TABLE " + FARMLAND_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_EMPLOYEE_ID + " TEXT,"
				+ USER_ID + " TEXT,"
				+ TYPE_FROM_INPUT + " TEXT,"
				+ TYPE_CROP_PULSE + " TEXT,"
				+ CULTIVATED_AREA + " TEXT,"
				+ NEW_FARMERS + " TEXT,"
				+ DEMO_FARMERS + " TEXT,"
				+ CONTINUED_FARMER + " TEXT,"
				+ INPUT_RECEIVED_TRAINING + " TEXT,"
				+ INPUT_RECEIVED_SEED + " TEXT,"
				+ INPUT_RECEIVED_FERTILISER + " TEXT,"
				+ INPUT_RECEIVED_PESTICIDES + " TEXT,"
				+ INPUT_RECEIVED_EXTENSION + " TEXT,"
				+ SPECIFY_INPUT + " TEXT,"
				+ OTHERS_QNTY + " TEXT,"
				+ AVERAGE_PRICE + " TEXT,"
				+ OTHERS_INPUT + " TEXT,"
				+ SEED_QNTY + " TEXT,"
				+ FERTILSIER_QNTY + " TEXT,"
				+ PESTICIDES_QNTY + " TEXT,"
				+ CONSUMPTION_PRODUTION + " TEXT,"
				+ SALE_PRODUTION + " TEXT,"
				+ TOTAL_PRODUCTION + " TEXT,"
				+ DISTRICT_NAME + " TEXT,"
				+ BLOCK_NAME + " TEXT,"
				+ GP_NAME + " TEXT,"
				+ VILLAGE_NAME + " TEXT,"
				+ ENTER_LAT + " TEXT,"
				+ ENTER_LONG + " TEXT,"
				+ MONTH_NO + " TEXT,"
				+ PRESENT_YEAR + " TEXT,"
				+ CARE_HHI_SLNO + " TEXT,"
				+ SPOUSE + " TEXT,"
				+ CARE_HHI + " TEXT,"
				+ WOMEN_NAME + " TEXT,"
				+ YOUR_ID_DELETE_CROP + " TEXT)";

		db.execSQL(CREATE_FARMLAND_TABLE);

	String CREATE_HHI_INOUT_TABLE = "CREATE TABLE " + HHI_INPUT_OUTPUT_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
			+ CARE_EMPLOYEE_ID + " TEXT,"
			+ USER_ID + " TEXT,"
			+ DISTRICT_NAME + " TEXT,"
			+ BLOCK_NAME + " TEXT,"
			+ GP_NAME + " TEXT,"
			+ VILLAGE_NAME + " TEXT,"
			+ ENTER_LAT + " TEXT,"
			+ ENTER_LONG + " TEXT,"
			+ MONTH_NO + " TEXT,"
			+ PRESENT_YEAR + " TEXT,"
			+ CARE_HHI_SLNO + " TEXT,"
			+ SPOUSE + " TEXT,"
			+ CARE_HHI + " TEXT,"
			+ WOMEN_NAME + " TEXT,"
			+ YOUR_ID_DELETE_CROP + " TEXT,"
			+ DATE_PICKER + " TEXT,"
			+ ACTIVITY + " TEXT,"
			+ SUPPORT + " TEXT,"
			+ PRODUCTION + " TEXT,"
			+ CONSUMPTION + " TEXT,"
			+ SALE + " TEXT,"
			+ REMARK + " TEXT)";

	db.execSQL(CREATE_HHI_INOUT_TABLE);


		String CREATE_HARVEST_TABLE = "CREATE TABLE " + HARVEST_LOST_FORM_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_EMPLOYEE_ID + " TEXT,"
				+ USER_ID + " TEXT,"
				+ DISTRICT_NAME + " TEXT,"
				+ BLOCK_NAME + " TEXT,"
				+ GP_NAME + " TEXT,"
				+ VILLAGE_NAME + " TEXT,"
				+ ENTER_LAT + " TEXT,"
				+ ENTER_LONG + " TEXT,"
				+ MONTH_NO + " TEXT,"
				+ PRESENT_YEAR + " TEXT,"
				+ CARE_HHI_SLNO + " TEXT,"
				+ SPOUSE + " TEXT,"
				+ CARE_HHI + " TEXT,"
				+ WOMEN_NAME + " TEXT,"
				+ YOUR_ID_DELETE_CROP + " TEXT,"
				+ CLASS_TRAINING_STATUS + " TEXT,"
				+ CLASS_SUBJECT_MATTER + " TEXT,"
				+ DEMO_SUBJECT_MATTER + " TEXT,"
				+ CARE_IMPLEMENT_STATUS + " TEXT,"
				+ CARE_FARMER_PARCTICING + " TEXT,"
				+ CLASS_MALE_PRESENT + " TEXT,"
				+ CLASS_FEMALE_PRESENT + " TEXT,"
				+ DEMO_MALE_PRESENT + " TEXT,"
				+ DEMO_FEMALE_PRESENT + " TEXT,"
				+ INPUT_PROVIDED_ID + " TEXT,"
				+ DEMO_TRAINING_STATUS + " TEXT)";

		db.execSQL(CREATE_HARVEST_TABLE);

		String CREATE_LABOUR_TABLE = "CREATE TABLE " + HARVEST_LABOUR_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_EMPLOYEE_ID + " TEXT,"
				+ USER_ID + " TEXT,"
				+ DISTRICT_NAME + " TEXT,"
				+ BLOCK_NAME + " TEXT,"
				+ GP_NAME + " TEXT,"
				+ VILLAGE_NAME + " TEXT,"
				+ ENTER_LAT + " TEXT,"
				+ ENTER_LONG + " TEXT,"
				+ MONTH_NO + " TEXT,"
				+ PRESENT_YEAR + " TEXT,"
				+ CARE_HHI_SLNO + " TEXT,"
				+ SPOUSE + " TEXT,"
				+ CARE_HHI + " TEXT,"
				+ WOMEN_NAME + " TEXT,"
				+ YOUR_ID_DELETE_CROP + " TEXT,"
				+ TARGET_ACTIVE_ID + " TEXT,"
				+ CLASS_TRAINING_STATUS + " TEXT,"
				+ DEVICE_IMPLEMENT_STATUS + " TEXT,"
				+ DEMONSTRATION_DATE + " TEXT,"
				+ IMPLEMENT_DEVICE_NAME + " TEXT,"
				+ MALE_PRESENT + " TEXT,"
				+ FEMALE_PRESNT+ " TEXT,"
				+ FARMER_IMPLEMENTS_MALE+ " TEXT,"
				+ FARMER_IMPLEMENTS_FEMALE + " TEXT)";

		db.execSQL(CREATE_LABOUR_TABLE);

		String CREATE_SHG_FORM_TABLE = "CREATE TABLE " + SHG_FORM_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_EMPLOYEE_ID + " TEXT,"
				+ USER_ID + " TEXT,"
				+ DISTRICT_NAME + " TEXT,"
				+ BLOCK_NAME + " TEXT,"
				+ GP_NAME + " TEXT,"
				+ VILLAGE_NAME + " TEXT,"
				+ ENTER_LAT + " TEXT,"
				+ ENTER_LONG + " TEXT,"
				+ MONTH_NO + " TEXT,"
				+ PRESENT_YEAR + " TEXT,"
				+ CARE_HHI_SLNO + " TEXT,"
				+ CARE_HHI + " TEXT,"
				+ CARE_SHG_NAME + " TEXT,"
				+ YOUR_ID_DELETE_CROP + " TEXT,"
				+ MEETING + " TEXT,"
				+ CASH + " TEXT,"
				+ INDIVIDUAL + " TEXT,"
				+ GROUP + " TEXT,"
				+ SAVING + " TEXT,"
				+ MONTHLY_STATUS + " TEXT,"
				+ LINKAGE_EXTERNAL_CREDIT+ " TEXT,"
				+ NO_OF_MEMBER+ " TEXT,"
				+ LAST_EVENT_DATE+ " TEXT,"
				+ MEMBER_PRESENT_MONTH_MEETING+ " TEXT,"
				+ BANK_LINKED + " TEXT,"
				+ LINKAGES_MARKET + " TEXT,"
				+ LINKAGES_TECHNICAL_SUPPORT + " TEXT,"
				+ COMMITTEE_NO_LINKED + " TEXT,"
				+ COMMITTEE_NAME + " TEXT,"
				+ ACCESS_AGRI + " TEXT,"
				+ WHAT_SERVICE + " TEXT,"
				+ MSP_FAQ + " TEXT,"
				+ WHAT_TOPIC + " TEXT,"
				+ DISCUSSED_AGRI + " TEXT,"
				+ WHAT_AGRI + " TEXT,"
				+ PURPOSE_LINKAGE + " TEXT,"
				+ TOPIC_NUTRITION + " TEXT)";


		db.execSQL(CREATE_SHG_FORM_TABLE);

		String CREATE_TRAIINING_FORM_TABLE = "CREATE TABLE " + TRAINING_FORM_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_EMPLOYEE_ID + " TEXT,"
				+ USER_ID + " TEXT,"
				+ DISTRICT_NAME + " TEXT,"
				+ BLOCK_NAME + " TEXT,"
				+ GP_NAME + " TEXT,"
				+ VILLAGE_NAME + " TEXT,"
				+ ENTER_LAT + " TEXT,"
				+ ENTER_LONG + " TEXT,"
				+ MONTH_NO + " TEXT,"
				+ PRESENT_YEAR + " TEXT,"
				+ YOUR_ID_DELETE_CROP + " TEXT,"
				+ THEMATIC_INTERVATION_ID + " TEXT,"
				+ TOPICS_COVERED + " TEXT,"
				+ EVENT_DATE + " TEXT,"
				+ DURATION_SESSION + " TEXT,"
				+ MALE_PRESENT + " TEXT,"
				+ FEMALE_PRESNT + " TEXT,"
				+ HHI_COVERED+ " TEXT,"
				+ MALE_REPEAT+ " TEXT,"
				+ FEMALE_REPEAT+ " TEXT,"
				+ HHI_REPEAT+ " TEXT,"
				+ TYPE_OF_TRAINING+ " TEXT,"
				+ TYPE_OF_GROUP+ " TEXT,"
				+ TRAINING_FACILITATOR+ " TEXT,"
				+ REMARK_DETAIL+ " TEXT,"
				+ EXTERNAL_PERSON + " TEXT)";

		db.execSQL(CREATE_TRAIINING_FORM_TABLE);

		String CREATE_LIVESTOCK_TABLE = "CREATE TABLE " + LIVESTOCK_TABLE + "("+ ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ CARE_EMPLOYEE_ID + " TEXT,"
				+ USER_ID + " TEXT,"
				+ DISTRICT_NAME + " TEXT,"
				+ BLOCK_NAME + " TEXT,"
				+ GP_NAME + " TEXT,"
				+ VILLAGE_NAME + " TEXT,"
				+ ENTER_LAT + " TEXT,"
				+ ENTER_LONG + " TEXT,"
				+ MONTH_NO + " TEXT,"
				+ PRESENT_YEAR + " TEXT,"
				+ CARE_HHI_SLNO + " TEXT,"
				+ SPOUSE + " TEXT,"
				+ CARE_HHI + " TEXT,"
				+ WOMEN_NAME + " TEXT,"
				+ YOUR_ID_DELETE_LIVESTOCK_ID + " TEXT,"
				+ TYPE_INSERT_LIVE_STOCK + " TEXT,"

				+ INPUT_TRAINING + " TEXT,"
				+ INPUT_EXTENSION_SUPPORT + " TEXT,"
				+ INPUT_EXTENSION_SUPPORT_ANIMAL_NO+ " TEXT,"
				+ INPUT_MEDICINE + " TEXT,"
				+ INPUT_MEDICINE_ANIMAL_NO+ " TEXT,"
				+ INPUT_VACCINATION+ " TEXT,"
				+ INPUT_VACCINATION_ANIMAL_NO+ " TEXT,"
				+ INPUT_OTHER+ " TEXT,"
				+ INPUT_OTHER_DETAIL+ " TEXT,"
				+ ANIMAL_PRESENT_NO+ " TEXT,"
				+ CULTIVATING_FODDER+ " TEXT,"
				+ CULTIVATED_AREA_FODDER+ " TEXT,"

				+ NEW_FARMER + " TEXT,"
				+ CONTINUED_FARMER + " TEXT,"
				+ CARE_LS_QP_EXTENSION_SUPPORT + " TEXT,"

				+ MEDICINE_NAME_ARRAY+ " TEXT,"
				+ MEDICINE_QNTY_ARRAY+ " TEXT,"
				+ VACCINATION_NAME_ARRAY+ " TEXT,"
				+ VACCINATION_QNTY_ARRAY+ " TEXT,"
				+ OTHER_NAME_ARRAY+ " TEXT,"
				+ OTHER_QNTY_ARRAY + " TEXT)";

		db.execSQL(CREATE_LIVESTOCK_TABLE);
	}

	// Upgrading database
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS " + LOCATION_INFORMATION_TABLE);


		// Create tables again
		onCreate(db);
	}




	public void AddLocationInfromation(String care_assU_employee_id,
			String care_assU_district_id,
			String care_assU_block_id,
			String care_assU_gp_id,
			String care_assU_village_id) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(CARE_EMPLOYEE_ID, care_assU_employee_id);
		values.put(CARE_DISTRICT_ID, care_assU_district_id);
		values.put(CARE_BLOCK_ID, care_assU_block_id);
		values.put(CARE_GP_ID, care_assU_gp_id);
		values.put(CARE_VILLAGE_ID, care_assU_village_id);

		db.insert(LOCATION_INFORMATION_TABLE, null, values);
	}

	public void AddHHIData(String hhid,
									   String hhidsl,
									   String woman_farmer,
									   String spouse_name,String village_name) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(HHID_ID, hhid);
		values.put(HHID_SL, hhidsl);
		values.put(WOMAN_FARMER, woman_farmer);
		values.put(SPOUSE_NAME, spouse_name);
		values.put(VILLAGE_NAME, village_name);

		db.insert(HHID_LIST_TABLE, null, values);
	}
	public void AddShg_List_Data(String care_shg_id,
						   String care_shg_slno,
						   String care_shg_name,
						   String care_shg_village) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(CARE_SHG_ID, care_shg_id);
		values.put(CARE_SHG_SLNO, care_shg_slno);
		values.put(CARE_SHG_NAME, care_shg_name);
		values.put(CARE_SHG_VILLAGE, care_shg_village);


		db.insert(SHG_LIST_TABLE, null, values);
	}
	public void AddPluses(String pluses) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(ITEM_CROP, pluses);


		db.insert(TYPES_OF_PULSES_TABLE, null, values);
	}
	public void AddThematic(String thematic_key,String thematic_name) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(THEMATIC_KEY, thematic_key);
		values.put(THEMATIC_NAME, thematic_name);


		db.insert(THEMATIC_INTERVATION_TABLE, null, values);
	}

	public void AddTopivCover(String care_training_name,String care_training_thematic) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(CARE_TRAINING_NAME, care_training_name);
		values.put(CARE_TRAINING_THEMATIC, care_training_thematic);


		db.insert(TOPICS_COVERED_TABLE, null, values);
	}
	public void AddGroup(String group_name) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(CARE_GROUP_NAME, group_name);


		db.insert(TYPE_OF_GROUP_TABLE, null, values);
	}
	public void AddFacilitator(String facilitator_name) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(FACILITATOR_NAME, facilitator_name);


		db.insert(TRAINING_FACILITATOR_TABLE, null, values);
	}
	public void AddTrainingType(String training_type) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(TRAINING_NAME, training_type);


		db.insert(TRAINING_TYPE_TABLE, null, values);
	}
	public void AddShgType(String care_name) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(CARE_COMMON_NAME, care_name);


		db.insert(SHG_TYPE_TABLE, null, values);
	}
	public void AddSubject(String subject_id,String subject_class) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(SUBJECT_ID, subject_id);
		values.put(SUBJECT_CLASS, subject_class);


		db.insert(SUBJECT_MATTER_TABLE, null, values);
	}
	public void AddDemon(String id_demo,String subject_demo) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(ID_DEMO, id_demo);
		values.put(SUBJECT_DEMO, subject_demo);


		db.insert(SUBJECT_DEMONSTRTOR_TABLE, null, values);
	}
	public void AddPhl(String phl_key,String phl_name) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(PHL_INPUT_KEY, phl_key);
		values.put(PHL_INPUT_NAME, phl_name);


		db.insert(PHL_INPUT_PROVIDE_TABLE, null, values);
	}
	public void AddLST(String care_sl_no,String care_activity_name) {

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(CARE_SL_NO, care_sl_no);
		values.put(CARE_ACTIVITY_NAME, care_activity_name);


		db.insert(LAST_TARGET_TABLE, null, values);
	}

	public void AddFarmLand( String employee_id,
						   String user_id,
						   String type_form_input,
						   String type_crop_pulse,
			 String cultivated_area,
			 String new_farmers,
			 String demo_farmers,
			 String continued_farmer,
			 String input_received_training,
			 String input_received_seed,
			 String input_received_fertiliser,
			 String input_received_pesticides,
			 String input_received_extension,
			 String specify_Input,
			 String others_qnty,
			 String Average_price,
			 String others_input,
			 String Seed_qnty,
			 String Fertiliser_qnty,
			 String Pesticides_qnty,
			 String Consumption_production,
			 String Sale_production,
			 String Total_production,
			 String district_name,
			 String block_name,
			 String GP_name,
			 String Village_name,
			 String enter_lat,
			 String enter_long,
			 String month_no,
			 String present_year,
			 String care_hhi_slno,
			 String Spouse,
			 String care_hhi,
			 String women_name,
			 String your_id_delete_crop)
	{

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		        values.put(CARE_EMPLOYEE_ID, employee_id);
		        values.put(USER_ID, user_id);
		        values.put(TYPE_FROM_INPUT , type_form_input);
				values.put( TYPE_CROP_PULSE , type_crop_pulse);
		        values.put(CULTIVATED_AREA , cultivated_area);
				values.put( NEW_FARMERS , new_farmers);
				values.put( DEMO_FARMERS , demo_farmers);
				values.put( CONTINUED_FARMER , continued_farmer);
				values.put( INPUT_RECEIVED_TRAINING , input_received_training);
				values.put( INPUT_RECEIVED_SEED , input_received_seed);
				values.put( INPUT_RECEIVED_FERTILISER , input_received_fertiliser);
				values.put( INPUT_RECEIVED_PESTICIDES , input_received_pesticides);
				values.put( INPUT_RECEIVED_EXTENSION , input_received_extension);
				values.put( SPECIFY_INPUT , specify_Input);
				values.put( OTHERS_QNTY , others_qnty);
				values.put( AVERAGE_PRICE , Average_price);
				values.put( OTHERS_INPUT , others_input);
				values.put( SEED_QNTY , Seed_qnty);
				values.put( FERTILSIER_QNTY , Fertiliser_qnty);
				values.put( PESTICIDES_QNTY , Pesticides_qnty);
				values.put( CONSUMPTION_PRODUTION , Consumption_production);
				values.put( SALE_PRODUTION , Sale_production);
				values.put( TOTAL_PRODUCTION , Total_production);
				values.put( DISTRICT_NAME , district_name);
				values.put( BLOCK_NAME , block_name);
				values.put( GP_NAME , GP_name);
				values.put( VILLAGE_NAME , Village_name);
				values.put( ENTER_LAT , enter_lat);
				values.put( ENTER_LONG , enter_long);
				values.put( MONTH_NO , month_no);
				values.put( PRESENT_YEAR , present_year);
				values.put( CARE_HHI_SLNO , care_hhi_slno);
				values.put( SPOUSE , Spouse);
				values.put( CARE_HHI , care_hhi);
				values.put( WOMEN_NAME , women_name);
				values.put( YOUR_ID_DELETE_CROP , your_id_delete_crop);


		db.insert(FARMLAND_TABLE, null, values);
	}
	public void AddHarvest_loss_( String employee_id,
							 String user_id,
							 String district_name,
							 String block_name,
							 String GP_name,
							 String Village_name,
							 String enter_lat,
							 String enter_long,
							 String month_no,
							 String present_year,
							 String care_hhi_slno,
							 String Spouse,
							 String care_hhi,
							 String women_name,
							 String your_id_delete_phl_id,
							 String class_training_status,
							 String class_subject_matter,
	String demo_subject_matter,
	String care_implements_status,
	String care_farmer_parcticing,
	String class_male_present,
	String class_female_present,
	String demo_male_present,
	String demo_female_present,
	String inputs_provided_id,
	String demo_training_status)
	{

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(CARE_EMPLOYEE_ID, employee_id);
		values.put(USER_ID, user_id);
		values.put( DISTRICT_NAME , district_name);
		values.put( BLOCK_NAME , block_name);
		values.put( GP_NAME , GP_name);
		values.put( VILLAGE_NAME , Village_name);
		values.put( ENTER_LAT , enter_lat);
		values.put( ENTER_LONG , enter_long);
		values.put( MONTH_NO , month_no);
		values.put( PRESENT_YEAR , present_year);
		values.put( CARE_HHI_SLNO , care_hhi_slno);
		values.put( SPOUSE , Spouse);
		values.put( CARE_HHI , care_hhi);
		values.put( WOMEN_NAME , women_name);
		values.put( YOUR_ID_DELETE_CROP , your_id_delete_phl_id);

		values.put( CLASS_TRAINING_STATUS,class_training_status);
				values.put( CLASS_SUBJECT_MATTER,class_subject_matter);
				values.put( DEMO_SUBJECT_MATTER,demo_subject_matter);
				values.put( CARE_IMPLEMENT_STATUS,care_implements_status);
				values.put( CARE_FARMER_PARCTICING,care_farmer_parcticing);
				values.put( CLASS_MALE_PRESENT,class_male_present);
				values.put( CLASS_FEMALE_PRESENT,class_female_present);
				values.put( DEMO_MALE_PRESENT,demo_male_present);
				values.put( DEMO_FEMALE_PRESENT,demo_female_present);
				values.put( INPUT_PROVIDED_ID,inputs_provided_id);
				values.put( DEMO_TRAINING_STATUS,demo_training_status);


		db.insert(HARVEST_LOST_FORM_TABLE, null, values);;
	}



	public void AddHHI_Input_Output( String employee_id,
									 String user_id,
									 String district_name,
									 String block_name,
									 String GP_name,
									 String Village_name,
									 String enter_lat,
									 String enter_long,
									 String month_no,
									 String present_year,
									 String care_hhi_slno,
									 String Spouse,
									 String care_hhi,
									 String women_name,
									 String your_id_delete_crop,
									 String date_picker,
									 String activity,
									 String support,
									 String production,
									 String consumption,
									 String sale,
									 String remark

	)
	{

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(CARE_EMPLOYEE_ID, employee_id);
		values.put(USER_ID, user_id);
		values.put( DISTRICT_NAME , district_name);
		values.put( BLOCK_NAME , block_name);
		values.put( GP_NAME , GP_name);
		values.put( VILLAGE_NAME , Village_name);
		values.put( ENTER_LAT , enter_lat);
		values.put( ENTER_LONG , enter_long);
		values.put( MONTH_NO , month_no);
		values.put( PRESENT_YEAR , present_year);
		values.put( CARE_HHI_SLNO , care_hhi_slno);
		values.put( SPOUSE , Spouse);
		values.put( CARE_HHI , care_hhi);
		values.put( WOMEN_NAME , women_name);
		values.put( YOUR_ID_DELETE_CROP , your_id_delete_crop);

		values.put( DATE_PICKER , date_picker);
		values.put( ACTIVITY , activity);
		values.put( SUPPORT , support);
		values.put( PRODUCTION , production);
		values.put( CONSUMPTION , consumption);
		values.put( SALE , sale);
		values.put( REMARK , remark);


		db.insert(HHI_INPUT_OUTPUT_TABLE, null, values);
	}

	public void AddHarvest_labour_( String employee_id,
								  String user_id,
								  String district_name,
								  String block_name,
								  String GP_name,
								  String Village_name,
								  String enter_lat,
								  String enter_long,
								  String month_no,
								  String present_year,
								  String care_hhi_slno,
								  String Spouse,
								  String care_hhi,
								  String women_name,
								  String your_id_delete_phl_id,
									String traget_active_id,
	String class_training_status,
	String device_implement_status,
	String demostration_date,
	String implemant_device_name,
	String male_present,
	String female_present,
	String farmer_implement_male,
	String farmer_implement_female)

	{

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(CARE_EMPLOYEE_ID, employee_id);
		values.put(USER_ID, user_id);
		values.put( DISTRICT_NAME , district_name);
		values.put( BLOCK_NAME , block_name);
		values.put( GP_NAME , GP_name);
		values.put( VILLAGE_NAME , Village_name);
		values.put( ENTER_LAT , enter_lat);
		values.put( ENTER_LONG , enter_long);
		values.put( MONTH_NO , month_no);
		values.put( PRESENT_YEAR , present_year);
		values.put( CARE_HHI_SLNO , care_hhi_slno);
		values.put( SPOUSE , Spouse);
		values.put( CARE_HHI , care_hhi);
		values.put( WOMEN_NAME , women_name);
		values.put( YOUR_ID_DELETE_CROP , your_id_delete_phl_id);


		values.put( TARGET_ACTIVE_ID , traget_active_id );
		values.put( CLASS_TRAINING_STATUS ,class_training_status );
		values.put( DEVICE_IMPLEMENT_STATUS ,device_implement_status );
		values.put( DEMONSTRATION_DATE ,demostration_date );
		values.put( IMPLEMENT_DEVICE_NAME ,implemant_device_name );
		values.put( MALE_PRESENT , male_present);
		values.put( FEMALE_PRESNT ,female_present );
		values.put( FARMER_IMPLEMENTS_MALE ,farmer_implement_male );
		values.put( FARMER_IMPLEMENTS_FEMALE ,farmer_implement_female );



		db.insert(HARVEST_LABOUR_TABLE, null, values);;
	}

	public void AddShg_Form( String employee_id,
									String user_id,
									String district_name,
									String block_name,
									String GP_name,
									String Village_name,
									String enter_lat,
									String enter_long,
									String month_no,
									String present_year,
									String care_hhi_slno,
									String care_hhi,
							        String care_shg_name,
							        String your_delete_id,
									String Meeting,
									String Cash,
									String Individual,
									String Group,
									String Saving,
									String Monthly_status,
									String Linkage_external_credit,
									String no_of_member,
									String last_event_date,
									String member_present_month_meeting,
									String Bank_linked,
									String linkages_market,
									String linkages_technical_support,
									String committee_no_linked,
									String committee_name,
							 String accessed_agri,
							 String what_service,
							 String msp_faq,
							 String what_topic,
							 String discussed_agriculture,
							 String what_agriculture,
							 String purpose_linkage,
							 String topic_nutrition
									)

	{

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();
		values.put(CARE_EMPLOYEE_ID, employee_id);
		values.put(USER_ID, user_id);
		values.put( DISTRICT_NAME , district_name);
		values.put( BLOCK_NAME , block_name);
		values.put( GP_NAME , GP_name);
		values.put( VILLAGE_NAME , Village_name);
		values.put( ENTER_LAT , enter_lat);
		values.put( ENTER_LONG , enter_long);
		values.put( MONTH_NO , month_no);
		values.put( PRESENT_YEAR , present_year);
		values.put( CARE_HHI_SLNO , care_hhi_slno);
		values.put( CARE_HHI , care_hhi);
		values.put( CARE_SHG_NAME ,care_shg_name );
		values.put( YOUR_ID_DELETE_CROP ,your_delete_id);
		values.put( MEETING , Meeting );
		values.put( CASH ,Cash );
		values.put( INDIVIDUAL ,Individual );
		values.put( GROUP ,Group );
		values.put( SAVING ,Saving );
		values.put( MONTHLY_STATUS , Monthly_status);
		values.put( LINKAGE_EXTERNAL_CREDIT ,Linkage_external_credit );
		values.put( NO_OF_MEMBER ,no_of_member );
		values.put( LAST_EVENT_DATE ,last_event_date );
		values.put( MEMBER_PRESENT_MONTH_MEETING ,member_present_month_meeting );
		values.put( BANK_LINKED ,Bank_linked );
		values.put( LINKAGES_MARKET ,linkages_market );
		values.put( LINKAGES_TECHNICAL_SUPPORT ,linkages_technical_support );
		values.put( COMMITTEE_NO_LINKED ,committee_no_linked );
		values.put( COMMITTEE_NAME ,committee_name );
		values.put( ACCESS_AGRI ,accessed_agri );
		values.put( WHAT_SERVICE ,what_service );
		values.put( MSP_FAQ ,msp_faq );
		values.put( WHAT_TOPIC ,what_topic );
		values.put( DISCUSSED_AGRI ,discussed_agriculture );
		values.put( WHAT_AGRI ,what_agriculture );
		values.put( PURPOSE_LINKAGE ,purpose_linkage );
		values.put( TOPIC_NUTRITION ,topic_nutrition );

		db.insert(SHG_FORM_TABLE, null, values);}

	public void AddTraining_Form( String employee_id,
							 String user_id,
							 String district_name,
							 String block_name,
							 String GP_name,
							 String Village_name,
							 String enter_lat,
							 String enter_long,
							 String month_no,
							 String present_year,
							 String your_delete,
							 String thematic_intervention_id,
							 String topics_covered,
							 String event_date,
							 String duration_session,
							 String male_present,
							 String female_present,
							 String hhi_covered,
							 String male_repeat,
							 String female_repeat,
							 String hhi_repeat,
							 String type_of_training,
							 String type_of_group,
							 String training_facilitator,
							 String remark_detail,
							 String external_person)
	{

		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(CARE_EMPLOYEE_ID,employee_id);
		values.put(USER_ID,user_id);
		values.put(DISTRICT_NAME,district_name);
		values.put(BLOCK_NAME, block_name);
		values.put(GP_NAME, GP_name);
		values.put(VILLAGE_NAME ,Village_name);
		values.put(ENTER_LAT ,enter_lat);
		values.put(ENTER_LONG ,enter_long);
		values.put(MONTH_NO,month_no);
		values.put(PRESENT_YEAR,present_year);
		values.put(YOUR_ID_DELETE_CROP,your_delete);
		values.put(THEMATIC_INTERVATION_ID , thematic_intervention_id);
		values.put(TOPICS_COVERED ,topics_covered);
		values.put(EVENT_DATE ,event_date);
		values.put(DURATION_SESSION ,duration_session);
		values.put(MALE_PRESENT ,male_present);
		values.put(FEMALE_PRESENT ,female_present);
		values.put(HHI_COVERED ,hhi_covered);
		values.put(MALE_REPEAT ,male_repeat);
		values.put(FEMALE_REPEAT ,female_repeat);
		values.put(HHI_REPEAT ,hhi_repeat);
		values.put(TYPE_OF_TRAINING ,type_of_training );
		values.put(TYPE_OF_GROUP ,type_of_group );
		values.put(TRAINING_FACILITATOR ,training_facilitator);
		values.put(REMARK_DETAIL ,remark_detail);
		values.put(EXTERNAL_PERSON ,external_person);
		db.insert(TRAINING_FORM_TABLE, null, values);
	}


	public void AddLivestock( String employee_id,
									 String user_id,
									 String district_name,
									 String block_name,
									 String GP_name,
									 String Village_name,
									 String enter_lat,
									 String enter_long,
									 String month_no,
									 String present_year,
									 String care_hhi_slno,
									 String Spouse,
									 String care_hhi,
									 String women_name,
									 String your_id_delete_livestock_id,
									 String type_insert_live_stock,
									 String input_training,
									 String input_extension_suport,
							  String input_extension_suport_animal_no,

							  String input_medicine,
							  String input_medicine_animal_no,
							  String input_vaccination,
							  String input_vaccination_animal_no,
							  String input_other,
							  String input_other_detail,


							  String animal_present_no,
							  String cultivating_fodder,
							         String cultivated_area_fodder,
									 String new_farmer,
									 String continued_farmer,
							         String care_LS_QP_extension_support,
							         String medicine_name_array,
							         String medicine_qnty_array,
							         String vaccination_name_array,
							         String vaccination_qnty_array,
							         String othera_name_array,
							         String othera_qnty_array

	)
	{

		SQLiteDatabase db = this.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put(CARE_EMPLOYEE_ID, employee_id);
		values.put(USER_ID, user_id);
		values.put( DISTRICT_NAME , district_name);
		values.put( BLOCK_NAME , block_name);
		values.put( GP_NAME , GP_name);
		values.put( VILLAGE_NAME , Village_name);
		values.put( ENTER_LAT , enter_lat);
		values.put( ENTER_LONG , enter_long);
		values.put( MONTH_NO , month_no);
		values.put( PRESENT_YEAR , present_year);
		values.put( CARE_HHI_SLNO , care_hhi_slno);
		values.put( SPOUSE , Spouse);
		values.put( CARE_HHI , care_hhi);
		values.put( WOMEN_NAME , women_name);
		values.put( YOUR_ID_DELETE_LIVESTOCK_ID , your_id_delete_livestock_id);

		values.put( TYPE_INSERT_LIVE_STOCK , type_insert_live_stock);
		values.put( INPUT_TRAINING , input_training);
		values.put( INPUT_EXTENSION_SUPPORT , input_extension_suport);
		values.put( INPUT_EXTENSION_SUPPORT_ANIMAL_NO , input_extension_suport_animal_no);
		values.put( INPUT_MEDICINE , input_medicine);
		values.put( INPUT_MEDICINE_ANIMAL_NO , input_medicine_animal_no);
		values.put( INPUT_VACCINATION , input_vaccination);
		values.put( INPUT_VACCINATION_ANIMAL_NO , input_vaccination_animal_no);

		values.put( INPUT_OTHER , input_vaccination_animal_no);
		values.put( INPUT_OTHER_DETAIL , input_vaccination_animal_no);
		values.put( ANIMAL_PRESENT_NO , animal_present_no);

		values.put( CULTIVATING_FODDER , cultivating_fodder);
		values.put( CULTIVATED_AREA_FODDER , cultivated_area_fodder);
		values.put( NEW_FARMER , new_farmer);
		values.put( CONTINUED_FARMER , continued_farmer);

		values.put( CARE_LS_QP_EXTENSION_SUPPORT , care_LS_QP_extension_support);
		values.put( MEDICINE_NAME_ARRAY , medicine_name_array);
		values.put( MEDICINE_QNTY_ARRAY , medicine_qnty_array);
		values.put( VACCINATION_NAME_ARRAY , vaccination_name_array);
		values.put( VACCINATION_QNTY_ARRAY , vaccination_qnty_array);
		values.put( OTHER_NAME_ARRAY , othera_name_array);
		values.put( OTHER_QNTY_ARRAY , othera_qnty_array);





		db.insert(LIVESTOCK_TABLE, null, values);
	}

	public ArrayList<LocationDTO> getUserData() {
		ArrayList<LocationDTO> Productlist = new ArrayList<LocationDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + LOCATION_INFORMATION_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				LocationDTO productdto = new LocationDTO();

				productdto.setCare_assU_employee_id(cursor.getString(1));
				productdto.setCare_assU_district_id(cursor.getString(2));
				productdto.setCare_assU_block_id(cursor.getString(3));
				productdto.setCare_assU_gp_id(cursor.getString(4));
				productdto.setCare_assU_village_id(cursor.getString(5));

				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}

	public ArrayList<FarmlandDTO> getFramlandData() {
		ArrayList<FarmlandDTO> Productlist = new ArrayList<FarmlandDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + FARMLAND_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				FarmlandDTO productdto = new FarmlandDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setType_form_input(cursor.getString(3));
				productdto.setType_crop_pulse(cursor.getString(4));
				productdto.setCultivated_area(cursor.getString(5));
				productdto.setNew_farmers(cursor.getString(6));
				productdto.setDemo_farmers(cursor.getString(7));
				productdto.setContinued_farmer(cursor.getString(8));
				productdto.setInput_received_training(cursor.getString(9));
				productdto.setInput_received_seed(cursor.getString(10));
				productdto.setInput_received_fertiliser(cursor.getString(11));
				productdto.setInput_received_pesticides(cursor.getString(12));
				productdto.setInput_received_extension(cursor.getString(13));
				productdto.setSpecify_Input(cursor.getString(14));
				productdto.setOthers_qnty(cursor.getString(15));
				productdto.setAverage_price(cursor.getString(16));
				productdto.setOthers_input(cursor.getString(17));
				productdto.setSeed_qnty(cursor.getString(18));
				productdto.setFertiliser_qnty(cursor.getString(19));
				productdto.setPesticides_qnty(cursor.getString(20));
				productdto.setConsumption_production(cursor.getString(21));
				productdto.setSale_production(cursor.getString(22));
				productdto.setTotal_production(cursor.getString(23));
				productdto.setDistrict_name(cursor.getString(24));
				productdto.setBlock_name(cursor.getString(25));
				productdto.setGP_name(cursor.getString(26));
				productdto.setVillage_name(cursor.getString(27));
				productdto.setEnter_lat(cursor.getString(28));
				productdto.setEnter_long(cursor.getString(29));
				productdto.setMonth_no(cursor.getString(30));
				productdto.setPresent_year(cursor.getString(31));
				productdto.setCare_hhi_slno(cursor.getString(32));
				productdto.setSpouse(cursor.getString(33));
				productdto.setCare_hhi(cursor.getString(34));
				productdto.setWomen_name(cursor.getString(35));
				productdto.setYour_id_delete_crop(cursor.getString(36));







				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<FarmlandDTO> getFramlandDataWithID(String id) {
		ArrayList<FarmlandDTO> Productlist = new ArrayList<FarmlandDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + FARMLAND_TABLE + " WHERE "+ YOUR_ID_DELETE_CROP + "= '"+id+"'" ;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				FarmlandDTO productdto = new FarmlandDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setType_form_input(cursor.getString(3));
				productdto.setType_crop_pulse(cursor.getString(4));
				productdto.setCultivated_area(cursor.getString(5));
				productdto.setNew_farmers(cursor.getString(6));
				productdto.setDemo_farmers(cursor.getString(7));
				productdto.setContinued_farmer(cursor.getString(8));
				productdto.setInput_received_training(cursor.getString(9));
				productdto.setInput_received_seed(cursor.getString(10));
				productdto.setInput_received_fertiliser(cursor.getString(11));
				productdto.setInput_received_pesticides(cursor.getString(12));
				productdto.setInput_received_extension(cursor.getString(13));
				productdto.setSpecify_Input(cursor.getString(14));
				productdto.setOthers_qnty(cursor.getString(15));
				productdto.setAverage_price(cursor.getString(16));
				productdto.setOthers_input(cursor.getString(17));
				productdto.setSeed_qnty(cursor.getString(18));
				productdto.setFertiliser_qnty(cursor.getString(19));
				productdto.setPesticides_qnty(cursor.getString(20));
				productdto.setConsumption_production(cursor.getString(21));
				productdto.setSale_production(cursor.getString(22));
				productdto.setTotal_production(cursor.getString(23));
				productdto.setDistrict_name(cursor.getString(24));
				productdto.setBlock_name(cursor.getString(25));
				productdto.setGP_name(cursor.getString(26));
				productdto.setVillage_name(cursor.getString(27));
				productdto.setEnter_lat(cursor.getString(28));
				productdto.setEnter_long(cursor.getString(29));
				productdto.setMonth_no(cursor.getString(30));
				productdto.setPresent_year(cursor.getString(31));
				productdto.setCare_hhi_slno(cursor.getString(32));
				productdto.setSpouse(cursor.getString(33));
				productdto.setCare_hhi(cursor.getString(34));
				productdto.setWomen_name(cursor.getString(35));
				productdto.setYour_id_delete_crop(cursor.getString(36));







				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}

	public ArrayList<HHI_InOut_DTO> getHHI_InOut_Data() {
		ArrayList<HHI_InOut_DTO> Productlist = new ArrayList<HHI_InOut_DTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + HHI_INPUT_OUTPUT_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				HHI_InOut_DTO productdto = new HHI_InOut_DTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setCare_hhi_slno(cursor.getString(11));
				productdto.setSpouse(cursor.getString(12));
				productdto.setCare_hhi(cursor.getString(13));
				productdto.setWomen_name(cursor.getString(14));
				productdto.setYour_id_delete_crop(cursor.getString(15));

				productdto.setDate_picker(cursor.getString(16));
				productdto.setActivity(cursor.getString(17));
				productdto.setSupport(cursor.getString(18));
				productdto.setProduction(cursor.getString(19));
				productdto.setConsumption(cursor.getString(20));
				productdto.setSale(cursor.getString(21));
				productdto.setRemark(cursor.getString(22));


				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<HHI_InOut_DTO> getHHI_InOut_DataWithID(String id) {
		ArrayList<HHI_InOut_DTO> Productlist = new ArrayList<HHI_InOut_DTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + HHI_INPUT_OUTPUT_TABLE + " WHERE "+ YOUR_ID_DELETE_CROP + "= '"+id+"'" ;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				HHI_InOut_DTO productdto = new HHI_InOut_DTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setCare_hhi_slno(cursor.getString(11));
				productdto.setSpouse(cursor.getString(12));
				productdto.setCare_hhi(cursor.getString(13));
				productdto.setWomen_name(cursor.getString(14));
				productdto.setYour_id_delete_crop(cursor.getString(15));

				productdto.setDate_picker(cursor.getString(16));
				productdto.setActivity(cursor.getString(17));
				productdto.setSupport(cursor.getString(18));
				productdto.setProduction(cursor.getString(19));
				productdto.setConsumption(cursor.getString(20));
				productdto.setSale(cursor.getString(21));
				productdto.setRemark(cursor.getString(22));


				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<LivestockDTO> getLivestock_data() {
		ArrayList<LivestockDTO> Productlist = new ArrayList<LivestockDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + LIVESTOCK_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				LivestockDTO productdto = new LivestockDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setCare_hhi_slno(cursor.getString(11));
				productdto.setSpouse(cursor.getString(12));
				productdto.setCare_hhi(cursor.getString(13));
				productdto.setWomen_name(cursor.getString(14));
				productdto.setYour_id_delete_livestock_id(cursor.getString(15));

				productdto.setType_insert_live_stock(cursor.getString(16));
				productdto.setInput_training(cursor.getString(17));
				productdto.setInput_extension_suport(cursor.getString(18));
				productdto.setInput_extension_suport_animal_no(cursor.getString(19));
				productdto.setInput_medicine(cursor.getString(20));
				productdto.setInput_medicine_animal_no(cursor.getString(21));
				productdto.setInput_vaccination(cursor.getString(22));
				productdto.setInput_vaccination_animal_no(cursor.getString(23));
				productdto.setInput_other(cursor.getString(24));
				productdto.setInput_other_detail(cursor.getString(25));
				productdto.setAnimal_present_no(cursor.getString(26));

				productdto.setCultivating_fodder(cursor.getString(27));
				productdto.setCultivated_area_fodder(cursor.getString(28));
				productdto.setNew_farmer(cursor.getString(29));
				productdto.setContinued_farmer(cursor.getString(30));

				productdto.setCare_LS_QP_extension_support(cursor.getString(31));
				productdto.setMedicine_name_array(cursor.getString(32));
				productdto.setMedicine_qnty_array(cursor.getString(33));
				productdto.setVaccination_name_array(cursor.getString(34));
				productdto.setVaccination_qnty_array(cursor.getString(35));
				productdto.setOthera_name_array(cursor.getString(36));
				productdto.setOthera_qnty_array(cursor.getString(37));







				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<LivestockDTO> getLivestock_dataWithID(String id) {
		ArrayList<LivestockDTO> Productlist = new ArrayList<LivestockDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + LIVESTOCK_TABLE + " WHERE "+ YOUR_ID_DELETE_LIVESTOCK_ID + "= '"+id+"'" ;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				LivestockDTO productdto = new LivestockDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setCare_hhi_slno(cursor.getString(11));
				productdto.setSpouse(cursor.getString(12));
				productdto.setCare_hhi(cursor.getString(13));
				productdto.setWomen_name(cursor.getString(14));
				productdto.setYour_id_delete_livestock_id(cursor.getString(15));

				productdto.setType_insert_live_stock(cursor.getString(16));
				productdto.setInput_training(cursor.getString(17));
				productdto.setInput_extension_suport(cursor.getString(18));
				productdto.setInput_extension_suport_animal_no(cursor.getString(19));
				productdto.setInput_medicine(cursor.getString(20));
				productdto.setInput_medicine_animal_no(cursor.getString(21));
				productdto.setInput_vaccination(cursor.getString(22));
				productdto.setInput_vaccination_animal_no(cursor.getString(23));
				productdto.setInput_other(cursor.getString(24));
				productdto.setInput_other_detail(cursor.getString(25));
				productdto.setAnimal_present_no(cursor.getString(26));

				productdto.setCultivating_fodder(cursor.getString(27));
				productdto.setCultivated_area_fodder(cursor.getString(28));
				productdto.setNew_farmer(cursor.getString(29));
				productdto.setContinued_farmer(cursor.getString(30));

				productdto.setCare_LS_QP_extension_support(cursor.getString(31));
				productdto.setMedicine_name_array(cursor.getString(32));
				productdto.setMedicine_qnty_array(cursor.getString(33));
				productdto.setVaccination_name_array(cursor.getString(34));
				productdto.setVaccination_qnty_array(cursor.getString(35));
				productdto.setOthera_name_array(cursor.getString(36));
				productdto.setOthera_qnty_array(cursor.getString(37));







				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<HarvestDTO> getHarvest_Data() {
		ArrayList<HarvestDTO> Productlist = new ArrayList<HarvestDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + HARVEST_LOST_FORM_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				HarvestDTO productdto = new HarvestDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setCare_hhi_slno(cursor.getString(11));
				productdto.setSpouse(cursor.getString(12));
				productdto.setCare_hhi(cursor.getString(13));
				productdto.setWomen_name(cursor.getString(14));
				productdto.setYour_id_delete_phl_id(cursor.getString(15));

				productdto.setClass_training_status(cursor.getString(16));
				productdto.setClass_subject_matter(cursor.getString(17));
				productdto.setDemo_subject_matter(cursor.getString(18));
				productdto.setCare_implements_status(cursor.getString(19));
				productdto.setCare_farmer_parcticing(cursor.getString(20));
				productdto.setClass_male_present(cursor.getString(21));
				productdto.setClass_female_present(cursor.getString(22));
				productdto.setDemo_male_present(cursor.getString(23));
				productdto.setDemo_female_present(cursor.getString(24));
				productdto.setInputs_provided_id(cursor.getString(25));
				productdto.setDemo_training_status(cursor.getString(26));







				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<HarvestDTO> getHarvest_DataWithID(String id) {
		ArrayList<HarvestDTO> Productlist = new ArrayList<HarvestDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + HARVEST_LOST_FORM_TABLE + " WHERE "+ YOUR_ID_DELETE_CROP + "= '"+id+"'" ;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				HarvestDTO productdto = new HarvestDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setCare_hhi_slno(cursor.getString(11));
				productdto.setSpouse(cursor.getString(12));
				productdto.setCare_hhi(cursor.getString(13));
				productdto.setWomen_name(cursor.getString(14));
				productdto.setYour_id_delete_phl_id(cursor.getString(15));

				productdto.setClass_training_status(cursor.getString(16));
				productdto.setClass_subject_matter(cursor.getString(17));
				productdto.setDemo_subject_matter(cursor.getString(18));
				productdto.setCare_implements_status(cursor.getString(19));
				productdto.setCare_farmer_parcticing(cursor.getString(20));
				productdto.setClass_male_present(cursor.getString(21));
				productdto.setClass_female_present(cursor.getString(22));
				productdto.setDemo_male_present(cursor.getString(23));
				productdto.setDemo_female_present(cursor.getString(24));
				productdto.setInputs_provided_id(cursor.getString(25));
				productdto.setDemo_training_status(cursor.getString(26));







				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<LabourDTO> getLabou_Data() {
		ArrayList<LabourDTO> Productlist = new ArrayList<LabourDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + HARVEST_LABOUR_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				LabourDTO productdto = new LabourDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setCare_hhi_slno(cursor.getString(11));
				productdto.setSpouse(cursor.getString(12));
				productdto.setCare_hhi(cursor.getString(13));
				productdto.setWomen_name(cursor.getString(14));
				productdto.setYour_id_delete_phl_id(cursor.getString(15));

				productdto.setClass_training_status(cursor.getString(16));
				productdto.setTraget_active_id(cursor.getString(17));
				productdto.setDevice_implement_status(cursor.getString(18));
				productdto.setDemostration_date(cursor.getString(19));
				productdto.setImplemant_device_name(cursor.getString(20));
				productdto.setMale_present(cursor.getString(21));
				productdto.setFemale_present(cursor.getString(22));
				productdto.setFarmer_implement_male(cursor.getString(23));
				productdto.setFarmer_implement_female(cursor.getString(24));








				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<LabourDTO> getLabou_DataWithID(String id) {
		ArrayList<LabourDTO> Productlist = new ArrayList<LabourDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + HARVEST_LABOUR_TABLE + " WHERE "+ YOUR_ID_DELETE_CROP + "= '"+id+"'" ;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				LabourDTO productdto = new LabourDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setCare_hhi_slno(cursor.getString(11));
				productdto.setSpouse(cursor.getString(12));
				productdto.setCare_hhi(cursor.getString(13));
				productdto.setWomen_name(cursor.getString(14));
				productdto.setYour_id_delete_phl_id(cursor.getString(15));

				productdto.setClass_training_status(cursor.getString(16));
				productdto.setTraget_active_id(cursor.getString(17));
				productdto.setDevice_implement_status(cursor.getString(18));
				productdto.setDemostration_date(cursor.getString(19));
				productdto.setImplemant_device_name(cursor.getString(20));
				productdto.setMale_present(cursor.getString(21));
				productdto.setFemale_present(cursor.getString(22));
				productdto.setFarmer_implement_male(cursor.getString(23));
				productdto.setFarmer_implement_female(cursor.getString(24));








				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<ShgFomDTO> getShg_form_data() {
		ArrayList<ShgFomDTO> Productlist = new ArrayList<ShgFomDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + SHG_FORM_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				ShgFomDTO productdto = new ShgFomDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setCare_hhi_slno(cursor.getString(11));
				productdto.setCare_hhi(cursor.getString(12));
				productdto.setYour_delete_id(cursor.getString(13));



				productdto.setMeeting(cursor.getString(14));
				productdto.setCash(cursor.getString(15));
				productdto.setIndividual(cursor.getString(16));
				productdto.setGroup(cursor.getString(17));
				productdto.setSaving(cursor.getString(18));
				productdto.setMonthly_status(cursor.getString(19));
				productdto.setLinkage_external_credit(cursor.getString(20));
				productdto.setNo_of_member(cursor.getString(21));
				productdto.setLast_event_date(cursor.getString(22));
				productdto.setMember_present_month_meeting(cursor.getString(23));
				productdto.setBank_linked(cursor.getString(24));
				productdto.setLinkages_market(cursor.getString(25));
				productdto.setLinkages_technical_support(cursor.getString(26));
				productdto.setCommittee_no_linked(cursor.getString(27));
				productdto.setCommittee_name(cursor.getString(27));
				productdto.setCare_shg_name(cursor.getString(28));

				productdto.setAccessed_agri(cursor.getString(29));
				productdto.setWhat_service(cursor.getString(30));
				productdto.setMsp_faq(cursor.getString(31));
				productdto.setWhat_topic(cursor.getString(32));
				productdto.setDiscussed_agriculture(cursor.getString(33));
				productdto.setWhat_agriculture(cursor.getString(34));
				productdto.setPurpose_linkage(cursor.getString(35));
				productdto.setTopic_nutrition(cursor.getString(36));



				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<ShgFomDTO> getShg_form_dataWithID(String id) {
		ArrayList<ShgFomDTO> Productlist = new ArrayList<ShgFomDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + SHG_FORM_TABLE + " WHERE "+ YOUR_ID_DELETE_CROP + "= '"+id+"'" ;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				ShgFomDTO productdto = new ShgFomDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setCare_hhi_slno(cursor.getString(11));
				productdto.setCare_hhi(cursor.getString(12));
				productdto.setCare_shg_name(cursor.getString(13));
				productdto.setYour_delete_id(cursor.getString(14));



				productdto.setMeeting(cursor.getString(15));
				productdto.setCash(cursor.getString(16));
				productdto.setIndividual(cursor.getString(17));
				productdto.setGroup(cursor.getString(18));
				productdto.setSaving(cursor.getString(19));
				productdto.setMonthly_status(cursor.getString(20));
				productdto.setLinkage_external_credit(cursor.getString(21));
				productdto.setNo_of_member(cursor.getString(22));
				productdto.setLast_event_date(cursor.getString(23));
				productdto.setMember_present_month_meeting(cursor.getString(24));
				productdto.setBank_linked(cursor.getString(25));
				productdto.setLinkages_market(cursor.getString(26));
				productdto.setLinkages_technical_support(cursor.getString(27));
				productdto.setCommittee_no_linked(cursor.getString(28));
				productdto.setCommittee_name(cursor.getString(29));


				productdto.setAccessed_agri(cursor.getString(30));
				productdto.setWhat_service(cursor.getString(31));
				productdto.setMsp_faq(cursor.getString(32));
				productdto.setWhat_topic(cursor.getString(33));
				productdto.setDiscussed_agriculture(cursor.getString(34));
				productdto.setWhat_agriculture(cursor.getString(35));
				productdto.setPurpose_linkage(cursor.getString(36));
				productdto.setTopic_nutrition(cursor.getString(37));



				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}

	public ArrayList<TrainingFormDTO> getTraining_form_data() {
		ArrayList<TrainingFormDTO> Productlist = new ArrayList<TrainingFormDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + TRAINING_FORM_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				TrainingFormDTO productdto = new TrainingFormDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setYour_delete_id(cursor.getString(11));
				productdto.setThematic_intervention_id(cursor.getString(12));
				productdto.setTopics_covered(cursor.getString(13));
				productdto.setEvent_date(cursor.getString(14));
				productdto.setDuration_session(cursor.getString(15));
				productdto.setMale_present(cursor.getString(16));
				productdto.setFemale_present(cursor.getString(17));
				productdto.setHhi_covered(cursor.getString(18));
				productdto.setMale_repeat(cursor.getString(19));
				productdto.setFemale_repeat(cursor.getString(20));
				productdto.setHhi_repeat(cursor.getString(21));
				productdto.setType_of_training(cursor.getString(22));
				productdto.setType_of_group(cursor.getString(23));
				productdto.setTraining_facilitator(cursor.getString(24));
				productdto.setRemark_detail(cursor.getString(25));
				productdto.setExternal_person(cursor.getString(26));




				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<TrainingFormDTO> getTraining_form_dataWithId(String id) {
		ArrayList<TrainingFormDTO> Productlist = new ArrayList<TrainingFormDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + TRAINING_FORM_TABLE + " WHERE "+ YOUR_ID_DELETE_CROP + "= '"+id+"'" ;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				TrainingFormDTO productdto = new TrainingFormDTO();

				productdto.setEmployee_id(cursor.getString(1));
				productdto.setUser_id(cursor.getString(2));
				productdto.setDistrict_name(cursor.getString(3));
				productdto.setBlock_name(cursor.getString(4));
				productdto.setGP_name(cursor.getString(5));
				productdto.setVillage_name(cursor.getString(6));
				productdto.setEnter_lat(cursor.getString(7));
				productdto.setEnter_long(cursor.getString(8));
				productdto.setMonth_no(cursor.getString(9));
				productdto.setPresent_year(cursor.getString(10));
				productdto.setYour_delete_id(cursor.getString(11));
				productdto.setThematic_intervention_id(cursor.getString(12));
				productdto.setTopics_covered(cursor.getString(13));
				productdto.setEvent_date(cursor.getString(14));
				productdto.setDuration_session(cursor.getString(15));
				productdto.setMale_present(cursor.getString(16));
				productdto.setFemale_present(cursor.getString(17));
				productdto.setHhi_covered(cursor.getString(18));
				productdto.setMale_repeat(cursor.getString(19));
				productdto.setFemale_repeat(cursor.getString(20));
				productdto.setHhi_repeat(cursor.getString(21));
				productdto.setType_of_training(cursor.getString(22));
				productdto.setType_of_group(cursor.getString(23));
				productdto.setTraining_facilitator(cursor.getString(24));
				productdto.setRemark_detail(cursor.getString(25));
				productdto.setExternal_person(cursor.getString(26));




				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<HhidDTO> getHHIdata(String village) {
		ArrayList<HhidDTO> Productlist = new ArrayList<HhidDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + HHID_LIST_TABLE + " WHERE "+ VILLAGE_NAME + "= '"+village+"'" ;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				HhidDTO productdto = new HhidDTO();

				productdto.setHhid(cursor.getString(1));
				productdto.setHhidsl(cursor.getString(2));
				productdto.setWoman_farmer(cursor.getString(3));
				productdto.setSpouse_name(cursor.getString(4));


				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}


	public ArrayList<ShgListDTO> getSHGListData(String village) {
		ArrayList<ShgListDTO> Productlist = new ArrayList<ShgListDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + SHG_LIST_TABLE + " WHERE "+ CARE_SHG_VILLAGE + "='"+village+"'" ;;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				ShgListDTO productdto = new ShgListDTO();

				productdto.setCare_shg_id(cursor.getString(1));
				productdto.setCare_shg_slno(cursor.getString(2));
				productdto.setCare_shg_name(cursor.getString(3));
				productdto.setCare_shg_village(cursor.getString(4));


				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}

	public ArrayList<PlusesDTO> getPluses() {
		ArrayList<PlusesDTO> Productlist = new ArrayList<PlusesDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + TYPES_OF_PULSES_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				PlusesDTO productdto = new PlusesDTO();

				productdto.setItem_crop(cursor.getString(1));


				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}

	public ArrayList<CareDTO> getCare(String thematic_id) {
		ArrayList<CareDTO> Productlist = new ArrayList<CareDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + TOPICS_COVERED_TABLE + " WHERE "+ CARE_TRAINING_THEMATIC + "= '"+thematic_id+"'" ;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				CareDTO productdto = new CareDTO();

				productdto.setCare_training_name(cursor.getString(1));
				productdto.setCare_training_thematic(cursor.getString(2));


				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}

	public ArrayList<ThematicDTO> getThematic() {
		ArrayList<ThematicDTO> Productlist = new ArrayList<ThematicDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + THEMATIC_INTERVATION_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				ThematicDTO productdto = new ThematicDTO();

				productdto.setThematic_key(cursor.getString(1));
				productdto.setThematic_name(cursor.getString(2));


				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<GroupDTO> getGroup() {
		ArrayList<GroupDTO> Productlist = new ArrayList<GroupDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + TYPE_OF_GROUP_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				GroupDTO productdto = new GroupDTO();

				productdto.setGroup_name(cursor.getString(1));



				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}

	public ArrayList<FacilitatorDTO> getFacilitator() {
		ArrayList<FacilitatorDTO> Productlist = new ArrayList<FacilitatorDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + TRAINING_FACILITATOR_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				FacilitatorDTO productdto = new FacilitatorDTO();

				productdto.setFacilitator_name(cursor.getString(1));

				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<TrainingDTO> getTrainingType() {
		ArrayList<TrainingDTO> Productlist = new ArrayList<TrainingDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + TRAINING_TYPE_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				TrainingDTO productdto = new TrainingDTO();

				productdto.setTraining_type(cursor.getString(1));

				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}


	public ArrayList<ShgDTO> getSHG() {
		ArrayList<ShgDTO> Productlist = new ArrayList<ShgDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + SHG_TYPE_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				ShgDTO productdto = new ShgDTO();

				productdto.setCare_name(cursor.getString(1));



				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<SubjectDTO> getSubjectMatter() {
		ArrayList<SubjectDTO> Productlist = new ArrayList<SubjectDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + SUBJECT_MATTER_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				SubjectDTO productdto = new SubjectDTO();

				productdto.setSubject_id(cursor.getString(1));
				productdto.setSubject_class(cursor.getString(2));



				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<DemonDTO> getSubjectDemon() {
		ArrayList<DemonDTO> Productlist = new ArrayList<DemonDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + SUBJECT_DEMONSTRTOR_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				DemonDTO productdto = new DemonDTO();

				productdto.setId_demo(cursor.getString(1));
				productdto.setSubject_demo(cursor.getString(2));



				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	public ArrayList<PhlDTO> getPhlInput() {
		ArrayList<PhlDTO> Productlist = new ArrayList<PhlDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + PHL_INPUT_PROVIDE_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				PhlDTO productdto = new PhlDTO();

				productdto.setPhl_key(cursor.getString(1));
				productdto.setPhl_name(cursor.getString(2));



				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}

	public ArrayList<LstDTO> getLstData() {
		ArrayList<LstDTO> Productlist = new ArrayList<LstDTO>();
		// Select All Query
		String selectQuery = "SELECT * FROM " + LAST_TARGET_TABLE;

		//"select * from med_his where med like ''"

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				LstDTO productdto = new LstDTO();

				productdto.setCare_sl_no(cursor.getString(1));
				productdto.setCare_activity_name(cursor.getString(2));


				Productlist.add(productdto);

			} while (cursor.moveToNext());
		}
		// return product list
		return Productlist;
	}
	/**
	 * Delete new request
	 */
	public void DeleteNewRequest() {
			SQLiteDatabase db = this.getWritableDatabase();
			db.delete(LOCATION_INFORMATION_TABLE,null, null);
			db.close();
		}
	public void DeleteThematic() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(THEMATIC_INTERVATION_TABLE,null, null);
		db.close();
	}
	public void DeleteCare() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(TOPICS_COVERED_TABLE,null, null);
		db.close();
	}
	public void DeleteFarmland() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(FARMLAND_TABLE,null, null);
		db.close();
	}
	public void DeleteTraining() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(TRAINING_FORM_TABLE,null, null);
		db.close();
	}
	public void DeleteShgFrom() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(SHG_FORM_TABLE,null, null);
		db.close();
	}

	public void DeleteLivestock() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(LIVESTOCK_TABLE,null, null);
		db.close();
	}
	public void DeleteHarvestLost() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(HARVEST_LOST_FORM_TABLE,null, null);
		db.close();
	}
	public void DeleteLabour() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(HARVEST_LABOUR_TABLE,null, null);
		db.close();
	}
	public void DeleteHHI() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(HHI_INPUT_OUTPUT_TABLE,null, null);
		db.close();
	}

/*	public boolean doesExistSupport(String job_id){
		boolean check = false;

		//Cursor cur = db.query(SUPPORT_TABLE, null,JOB_ID+"=?"+" AND "+JOB_STATUS+"=?", new String[]{job_id,"idle"}, null, null, null);

		String countQuery = "SELECT * FROM " + SUPPORT_TABLE + " WHERE "+ JOB_ID + "=" + "'"+job_id+"'"+" AND "+JOB_STATUS + "=" + "'idle'";
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cur = db.rawQuery(countQuery, null);

		try {
			if(cur!=null){
				if(cur.getCount()>0)
					check = true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		cur.close();
		db.close();
		return check;
	}


	public boolean doesUnderSupport(String job_id){
		boolean check = false;
		//SQLiteDatabase db = this.getReadableDatabase();
		//Cursor cur = db.query(SUPPORT_TABLE, null,JOB_ID+"=?"+" AND "+JOB_STATUS+"=?", new String[]{job_id,"under_process"}, null, null, null);
		String countQuery = "SELECT * FROM " + SUPPORT_TABLE + " WHERE "+ JOB_ID + "=" +"'"+job_id+"'"+" AND "+JOB_STATUS + "=" + "'under_process'";
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cur = db.rawQuery(countQuery, null);

		try {
			if(cur!=null){
				if(cur.getCount()>0)
					check = true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		cur.close();
		db.close();
		return check;
	}


	public void UpDateNewRequest(String job_id, String job_description, String send_date, String _price) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(JOB_DESCRIPTION, job_description);
		values.put(JOB_STATUS, "under_process");
		values.put(ESTIMATED_DATE, send_date);
		values.put(ESTIMATED_PRICE, _price);
		values.put(UPDATE_STATUS, "no");
		// updating row
		//System.out.println("AAA" + product.getQuantity() + "xgfggdfxgdf"+ product.getItemserialno());
		 db.update(SUPPORT_TABLE, values, JOB_ID + "=?", new String[]{job_id});

	}


	public int getUserCount(String s, String s1) {
		String countQuery = "SELECT * FROM " + LOGIN_TABLE + " WHERE "+ USER_ID + "= '"+s+"'"+" AND "+PASSWORD + "= '"+s1+"'";
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(countQuery, null);
		return cursor.getCount();
	}*/

	public int getHHICount(String village) {
		String countQuery = "SELECT * FROM " + HHID_LIST_TABLE + " WHERE "+ VILLAGE_NAME + "= '"+village+"'" ;
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(countQuery, null);
		return cursor.getCount();
	}
	public int getSghCount(String village) {
		String countQuery = "SELECT * FROM " + SHG_LIST_TABLE + " WHERE "+ CARE_SHG_VILLAGE + "= '"+village+"'" ;
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(countQuery, null);
		return cursor.getCount();
	}
	public int getLocationCount() {
		String countQuery = "SELECT * FROM " + LOCATION_INFORMATION_TABLE ;
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(countQuery, null);
		return cursor.getCount();
	}
	public int getPluseCount() {
		String countQuery = "SELECT * FROM " + TYPES_OF_PULSES_TABLE ;
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(countQuery, null);
		return cursor.getCount();
	}
}
