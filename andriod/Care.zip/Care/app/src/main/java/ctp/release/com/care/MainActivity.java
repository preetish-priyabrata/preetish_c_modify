package ctp.release.com.care;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import ctp.release.com.care.DTO.FarmlandDTO;
import ctp.release.com.care.DTO.HHI_InOut_DTO;
import ctp.release.com.care.DTO.HarvestDTO;
import ctp.release.com.care.DTO.LabourDTO;
import ctp.release.com.care.DTO.LivestockDTO;
import ctp.release.com.care.DTO.LocationDTO;
import ctp.release.com.care.DTO.ShgFomDTO;
import ctp.release.com.care.DTO.TrainingFormDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

public class MainActivity extends AppCompatActivity {
    Button newData,shg,training,sync,hhisync,harvest,labour,shg_form,training_form,livestock;
    TextView name;
    SharedPreferenceClass sharedPreferenceClass;
    ProgressDialog progressDialog;
    DatabaseHandlerNew databaseHandlerNew;
    int i=0;
    ArrayList<FarmlandDTO> farmlanddata = new ArrayList<FarmlandDTO>();
    ArrayList<HHI_InOut_DTO> hhi_inOut_dtos = new ArrayList<HHI_InOut_DTO>();
    ArrayList<HarvestDTO> harvestDTOs = new ArrayList<HarvestDTO>();
    ArrayList<LabourDTO> labourDTOs = new ArrayList<LabourDTO>();
    ArrayList<ShgFomDTO> shgFormDTOs = new ArrayList<ShgFomDTO>();
    ArrayList<TrainingFormDTO> trainingFormDTOs = new ArrayList<TrainingFormDTO>();
    ArrayList<LivestockDTO> livestockDTOs = new ArrayList<LivestockDTO>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressDialog=new ProgressDialog(this);
        sharedPreferenceClass = new SharedPreferenceClass(this);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        name = (TextView) findViewById(R.id.name);
        newData= (Button) findViewById(R.id.new_data);
        shg= (Button) findViewById(R.id.shg);
        sync= (Button) findViewById(R.id.sync);
        hhisync= (Button) findViewById(R.id.hhisync);
        training= (Button) findViewById(R.id.training);
        harvest= (Button) findViewById(R.id.harvest);
        labour= (Button) findViewById(R.id.labour);
        shg_form= (Button) findViewById(R.id.shg_form);
        training_form= (Button) findViewById(R.id.training_form);
        livestock= (Button) findViewById(R.id.livestock);





        name.setText("Welcome " + sharedPreferenceClass.getValue_string("user_name"));
        newData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,HhidList.class));

            }
        });
        training.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,TrainingReport.class));
            }
        });
        shg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,ShgReport.class));
            }
        });
        sync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                farmlanddata = databaseHandlerNew.getFramlandData();

                for(int i=0;i<farmlanddata.size();i++){
                    sendDataToServer(farmlanddata.get(i),i,farmlanddata.size());
                }

            }
        });
        hhisync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                hhi_inOut_dtos = databaseHandlerNew.getHHI_InOut_Data();

                for(int i=0;i<hhi_inOut_dtos.size();i++){
                    sendHhiDataToServer(hhi_inOut_dtos.get(i),i,hhi_inOut_dtos.size());
                }

            }
        });
        harvest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                harvestDTOs = databaseHandlerNew.getHarvest_Data();

                for(int i=0;i<harvestDTOs.size();i++){
                    sendHarvestDataToServer(harvestDTOs.get(i),i,harvestDTOs.size());
                }

            }
        });

        labour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                labourDTOs = databaseHandlerNew.getLabou_Data();

                for(int i=0;i<labourDTOs.size();i++){
                    sendLabourDataToServer(labourDTOs.get(i),i,labourDTOs.size());
                }

            }
        });

        shg_form.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                shgFormDTOs = databaseHandlerNew.getShg_form_data();

                for(int i=0;i<shgFormDTOs.size();i++){
                    sendShgFormToServer(shgFormDTOs.get(i),i,shgFormDTOs.size());
                }

            }
        });

        training_form.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                trainingFormDTOs = databaseHandlerNew.getTraining_form_data();

                for(int i=0;i<trainingFormDTOs.size();i++){
                    sendTrainingFormToServer(trainingFormDTOs.get(i),i,trainingFormDTOs.size());
                }

            }
        });

        livestock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                livestockDTOs = databaseHandlerNew.getLivestock_data();

                for(int i=0;i<livestockDTOs.size();i++){
                    sendLivestockToServer(livestockDTOs.get(i),i,livestockDTOs.size());
                }

            }
        });


if (databaseHandlerNew.getPluseCount()>0){

}
        else{
    getUserInfo();
        }


    }

    private void sendLivestockToServer(final LivestockDTO livestockDTO, final int con, final int size) {
        {
            progressDialog.show();
            progressDialog.setMessage("Loading...");
            String tag_json_req = "user_login";
            StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                    "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_live_stock_info/format/json",
                    new com.android.volley.Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            progressDialog.dismiss();

                            try {
                                Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                                JSONObject jsonObject = new JSONObject(response);
                                JSONObject object= null;

                                if (jsonObject.getString("response_status").equals("1")){

                                    if(con == size-1){
                                        databaseHandlerNew.DeleteLivestock();
                                    }
                                    Toast.makeText(MainActivity.this, "Submitted", Toast.LENGTH_SHORT).show();

                                }
                                else{
                                    Toast.makeText(MainActivity.this, "Please insert all data", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (error.getMessage() == null) {
                        if (i < 3) {
                            Log.e("Retry due to error ", "for time : " + i);
                            i++;
                        } else  {
                            progressDialog.dismiss();
                            Toast.makeText(MainActivity.this, "Check your network connection.",
                                    Toast.LENGTH_LONG).show();
                        }
                    } else
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {


                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    // Password:admin@123
                    Map<String, String> params = new HashMap<>();
                    params.put("employee_id",livestockDTO.getEmployee_id());
                    params.put("userid",livestockDTO.getUser_id());
                    params.put("district_name",livestockDTO.getDistrict_name());
                    params.put("block_name",livestockDTO.getBlock_name());

                    params.put("GP_name",livestockDTO.getGP_name());
                    params.put("Village_name",livestockDTO.getVillage_name());
                    params.put("enter_lat", livestockDTO.getEnter_lat());
                    params.put("enter_long", livestockDTO.getEnter_long());
                    params.put("month_no",livestockDTO.getMonth_no());

                    params.put("present_year",livestockDTO.getPresent_year());
                    params.put("care_hhi_slno",livestockDTO.getCare_hhi_slno());
                    params.put("care_hhi",livestockDTO.getCare_hhi());
                    params.put("women_name",livestockDTO.getWomen_name());
                    params.put("Spouse",livestockDTO.getSpouse());
                    params.put("your_id_delete_livestock_id",livestockDTO.getYour_id_delete_livestock_id());
                    params.put("type_insert_live_stock",livestockDTO.getType_insert_live_stock());

                    params.put("input_training",livestockDTO.getInput_training());
                    params.put("input_extension_suport",livestockDTO.getInput_extension_suport());
                    params.put("input_extension_suport_animal_no",livestockDTO.getInput_extension_suport_animal_no());

                    params.put("input_medicine",livestockDTO.getInput_medicine());
                    params.put("input_medicine_animal_no",livestockDTO.getInput_medicine_animal_no());
                    params.put("input_vaccination",livestockDTO.getInput_vaccination());
                    params.put("input_vaccination_animal_no",livestockDTO.getInput_vaccination_animal_no());
                    params.put("input_other",livestockDTO.getInput_other());
                    params.put("input_other_detail",livestockDTO.getInput_other_detail());
                    params.put("input_other_animal_no","4");


                    params.put("animal_present_no",livestockDTO.getAnimal_present_no());
                    params.put("cultivating_fodder",livestockDTO.getCultivating_fodder());
                    params.put("cultivated_area_fodder",livestockDTO.getCultivated_area_fodder());
                    params.put("new_farmer",livestockDTO.getNew_farmer());
                    params.put("continued_farmer",livestockDTO.getContinued_farmer());


                    params.put("care_LS_QP_extension_support",livestockDTO.getCare_LS_QP_extension_support());
                    params.put("medicine_name_array",livestockDTO.getMedicine_name_array());
                    params.put("medicine_qnty_array",livestockDTO.getMedicine_qnty_array());
                    params.put("vaccination_name_array",livestockDTO.getVaccination_name_array());
                    params.put("vaccination_qnty_array",livestockDTO.getVaccination_qnty_array());
                    params.put("othera_name_array",livestockDTO.getOthera_name_array());
                    params.put("othera_qnty_array",livestockDTO.getOthera_qnty_array());




                    Log.d("params are :", "" + params);

                    return params;
                }
            };
            data.setRetryPolicy(new
                    DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);

        }
    }

    private void sendTrainingFormToServer(final TrainingFormDTO trainingFormDTO, final int con, final int size) {
        {
            progressDialog.show();
            progressDialog.setMessage("Loading...");
            String tag_json_req = "user_login";
            StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                    "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_training_info/format/json",
                    new com.android.volley.Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            progressDialog.dismiss();

                            try {
                                Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                                JSONObject jsonObject = new JSONObject(response);
                                JSONObject object= null;

                                if (jsonObject.getString("response_status").equals("1")){
                                    Toast.makeText(MainActivity.this, "Submitted", Toast.LENGTH_SHORT).show();

                                    if(con == size-1){
                                        databaseHandlerNew.DeleteTraining();
                                    }


                                }
                                else{
                                    Toast.makeText(MainActivity.this, "Please insert all data", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (error.getMessage() == null) {
                        if (MainActivity.this.i < 3) {
                            Log.e("Retry due to error ", "for time : " + MainActivity.this.i);
                            MainActivity.this.i++;
                        } else  {
                            progressDialog.dismiss();
                            Toast.makeText(MainActivity.this, "Check your network connection.",
                                    Toast.LENGTH_LONG).show();
                        }
                    } else
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {


                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    // Password:admin@123
                    Map<String, String> params = new HashMap<>();
                    params.put("employee_id",trainingFormDTO.getEmployee_id());
                    params.put("userid",trainingFormDTO.getUser_id());
                    params.put("district_name",trainingFormDTO.getDistrict_name());
                    params.put("block_name",trainingFormDTO.getBlock_name());
                    params.put("GP_name",trainingFormDTO.getGP_name());
                    params.put("Village_name",trainingFormDTO.getVillage_name());
                    params.put("enter_lat", trainingFormDTO.getEnter_lat());
                    params.put("enter_long", trainingFormDTO.getEnter_long());
                    params.put("month_no",trainingFormDTO.getMonth_no());
                    params.put("present_year",trainingFormDTO.getPresent_year());
                    params.put("your_id_delete_training_id",trainingFormDTO.getYour_delete_id());
                    params.put("thematic_intervention_id",trainingFormDTO.getThematic_intervention_id());
                    params.put("topics_covered",trainingFormDTO.getTopics_covered());
                    params.put("event_date",trainingFormDTO.getEvent_date());
                    params.put("duration_session",trainingFormDTO.getDuration_session());
                    params.put("male_present",trainingFormDTO.getMale_present());
                    params.put("female_present",trainingFormDTO.getFemale_present());
                    params.put("hhi_covered",trainingFormDTO.getHhi_covered());
                    params.put("male_repeat",trainingFormDTO.getMale_repeat());
                    params.put("female_repeat",trainingFormDTO.getFemale_repeat());
                    params.put("hhi_repeat",trainingFormDTO.getHhi_repeat());
                    params.put("type_of_training",trainingFormDTO.getType_of_training());
                    params.put("type_of_group",trainingFormDTO.getType_of_group());
                    params.put("training_facilitator",trainingFormDTO.getTraining_facilitator());
                    params.put("remark_detail",trainingFormDTO.getRemark_detail());
                    params.put("external_person",trainingFormDTO.getExternal_person());









                    Log.d("params are :", "" + params);

                    return params;
                }
            };
            data.setRetryPolicy(new
                    DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


        }
    }

    private void sendShgFormToServer(final ShgFomDTO shgFomDTO, final int con, final int size) {
        {
            progressDialog.show();
            progressDialog.setMessage("Loading...");
            String tag_json_req = "user_login";
            StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                    "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_shg_info/format/json",
                    new com.android.volley.Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            progressDialog.dismiss();

                            try {
                                Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                                JSONObject jsonObject = new JSONObject(response);
                                JSONObject object= null;

                                if (jsonObject.getString("response_status").equals("1")){
                                    Toast.makeText(MainActivity.this, "Submitted", Toast.LENGTH_SHORT).show();
                                    if(con == size-1){
                                        databaseHandlerNew.DeleteShgFrom();
                                    }
                                }
                                else{
                                    Toast.makeText(MainActivity.this, "Please insert all data", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (error.getMessage() == null) {
                        if (MainActivity.this.i < 3) {
                            Log.e("Retry due to error ", "for time : " + MainActivity.this.i);
                            MainActivity.this.i++;
                        } else  {
                            progressDialog.dismiss();
                            Toast.makeText(MainActivity.this, "Check your network connection.",
                                    Toast.LENGTH_LONG).show();
                        }
                    } else
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {


                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    // Password:admin@123
                    Map<String, String> params = new HashMap<>();
                    params.put("employee_id",shgFomDTO.getEmployee_id());
                    params.put("userid",shgFomDTO.getUser_id());
                    params.put("district_name",shgFomDTO.getDistrict_name());
                    params.put("block_name",shgFomDTO.getBlock_name());

                    params.put("GP_name",shgFomDTO.getGP_name());
                    params.put("Village_name",shgFomDTO.getVillage_name());
                    params.put("enter_lat", shgFomDTO.getEnter_lat());
                    params.put("enter_long", shgFomDTO.getEnter_long());
                    params.put("month_no",shgFomDTO.getMonth_no());

                    params.put("present_year",shgFomDTO.getPresent_year());
                    params.put("care_shg_slno",shgFomDTO.getCare_hhi_slno());
                    params.put("care_shg_id",shgFomDTO.getCare_hhi());


                    params.put("Meeting",shgFomDTO.getMeeting());
                    params.put("Cash",shgFomDTO.getCash());
                    params.put("Individual",shgFomDTO.getIndividual());
                    params.put("Group",shgFomDTO.getGroup());
                    params.put("Saving",shgFomDTO.getSaving());
                    params.put("Monthly_status",shgFomDTO.getMonthly_status());
                    params.put("Linkage_external_credit",shgFomDTO.getLinkage_external_credit());


                    params.put("no_of_member",shgFomDTO.getNo_of_member());
                    params.put("last_event_date",shgFomDTO.getLast_event_date());
                    params.put("member_present_month_meeting",shgFomDTO.getMember_present_month_meeting());
                    params.put("Bank_linked",shgFomDTO.getBank_linked());
                    params.put("linkages_market",shgFomDTO.getLinkages_market());
                    params.put("linkages_technical_support",shgFomDTO.getLinkages_technical_support());
                    params.put("committee_no_linked",shgFomDTO.getCommittee_no_linked());
                    params.put("committee_name",shgFomDTO.getCommittee_name());
                    params.put("care_shg_name",shgFomDTO.getCare_shg_name());

                    params.put("shg_field_new1",shgFomDTO.getPurpose_linkage());
                    params.put("shg_field_new2",shgFomDTO.getTopic_nutrition());
                    params.put("shg_field_new3",shgFomDTO.getAccessed_agri());
                    params.put("shg_field_new4",shgFomDTO.getWhat_service());
                    params.put("shg_field_new5",shgFomDTO.getMsp_faq());
                    params.put("shg_field_new6",shgFomDTO.getWhat_topic());
                    params.put("shg_field_new7",shgFomDTO.getDiscussed_agriculture());
                    params.put("shg_field_new8",shgFomDTO.getWhat_agriculture());




                    Log.d("params are :", "" + params);

                    return params;
                }
            };
            data.setRetryPolicy(new
                    DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


        }
    }

    private void sendLabourDataToServer(final LabourDTO labourDTO, final int con, final int size) {
        {
            progressDialog.show();
            progressDialog.setMessage("Loading...");
            String tag_json_req = "user_login";
            StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                    "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_lst_info/format/json",
                    new com.android.volley.Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            progressDialog.dismiss();

                            try {
                                Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                                JSONObject jsonObject = new JSONObject(response);
                                JSONObject object= null;

                                if (jsonObject.getString("response_status").equals("1")){
                                    Toast.makeText(MainActivity.this, "Submitted", Toast.LENGTH_SHORT).show();
                                    if(con == size-1){
                                        databaseHandlerNew.DeleteLabour();
                                    }
                                }
                                else{
                                    Toast.makeText(MainActivity.this, "Please insert all data", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (error.getMessage() == null) {
                        if (MainActivity.this.i < 3) {
                            Log.e("Retry due to error ", "for time : " + MainActivity.this.i);
                            MainActivity.this.i++;
                        } else  {
                            progressDialog.dismiss();
                            Toast.makeText(MainActivity.this, "Check your network connection.",
                                    Toast.LENGTH_LONG).show();
                        }
                    } else
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {


                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    // Password:admin@123
                    Map<String, String> params = new HashMap<>();
                    params.put("employee_id",labourDTO.getEmployee_id());
                    params.put("userid",labourDTO.getUser_id());
                    params.put("district_name",labourDTO.getDistrict_name());
                    params.put("block_name",labourDTO.getBlock_name());

                    params.put("GP_name",labourDTO.getGP_name());
                    params.put("Village_name",labourDTO.getVillage_name());
                    params.put("enter_lat", labourDTO.getEnter_lat());
                    params.put("enter_long", labourDTO.getEnter_long());
                    params.put("month_no",labourDTO.getMonth_no());

                    params.put("present_year",labourDTO.getPresent_year());
                    params.put("care_hhi_slno",labourDTO.getCare_hhi_slno());
                    params.put("care_hhi",labourDTO.getCare_hhi());
                    params.put("women_name",labourDTO.getWomen_name());
                    params.put("Spouse",labourDTO.getSpouse());
                    params.put("your_id_delete_phl_id",labourDTO.getYour_id_delete_phl_id());


                    params.put("traget_active_id",labourDTO.getTraget_active_id());
                    params.put("class_training_status",labourDTO.getClass_training_status());
                    params.put("device_implement_status",labourDTO.getDevice_implement_status());




                    params.put("demostration_date",labourDTO.getDemostration_date());
                    params.put("implemant_device_name",labourDTO.getImplemant_device_name());
                    params.put("male_present",labourDTO.getMale_present());
                    params.put("female_present",labourDTO.getFemale_present());
                    params.put("farmer_implement_male",labourDTO.getFarmer_implement_male());
                    params.put("farmer_implement_female",labourDTO.getFarmer_implement_female());

                    //params.put("traget_active_id","2");




                    Log.d("params are :", "" + params);

                    return params;
                }
            };
            data.setRetryPolicy(new
                    DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


        }
    }

    private void sendHarvestDataToServer(final HarvestDTO harvestDTO, final int con, final int size) {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_phl_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject object= null;

                            if (jsonObject.getString("response_status").equals("1")){
                                Toast.makeText(MainActivity.this, "Submitted", Toast.LENGTH_SHORT).show();
                                if(con == size-1){
                                    databaseHandlerNew.DeleteHarvestLost();
                                }
                            }
                            else{
                                Toast.makeText(MainActivity.this, "Please insert all data", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (MainActivity.this.i < 3) {
                        Log.e("Retry due to error ", "for time : " + MainActivity.this.i);
                        MainActivity.this.i++;
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(MainActivity.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Password:admin@123
                Map<String, String> params = new HashMap<>();
                params.put("employee_id",harvestDTO.getEmployee_id());
                params.put("userid",harvestDTO.getUser_id());
                params.put("district_name",harvestDTO.getDistrict_name());
                params.put("block_name",harvestDTO.getBlock_name());

                params.put("GP_name",harvestDTO.getGP_name());
                params.put("Village_name",harvestDTO.getVillage_name());
                params.put("enter_lat", harvestDTO.getEnter_lat());
                params.put("enter_long", harvestDTO.getEnter_long());
                params.put("month_no",harvestDTO.getMonth_no());

                params.put("present_year",harvestDTO.getPresent_year());
                params.put("care_hhi_slno",harvestDTO.getCare_hhi_slno());
                params.put("care_hhi",harvestDTO.getCare_hhi());
                params.put("women_name",harvestDTO.getWomen_name());
                params.put("Spouse",harvestDTO.getSpouse());
                params.put("your_id_delete_phl_id",harvestDTO.getYour_id_delete_phl_id());


                params.put("class_training_status",harvestDTO.getClass_training_status());
                params.put("class_subject_matter",harvestDTO.getClass_subject_matter());
                params.put("demo_subject_matter",harvestDTO.getDemo_subject_matter());
                params.put("care_implements_status",harvestDTO.getCare_implements_status());
                params.put("care_farmer_parcticing",harvestDTO.getCare_farmer_parcticing());



                params.put("class_male_present",harvestDTO.getClass_male_present());
                params.put("class_female_present",harvestDTO.getClass_female_present());
                params.put("demo_male_present",harvestDTO.getDemo_male_present());
                params.put("demo_female_present",harvestDTO.getDemo_female_present());
                params.put("inputs_provided_id",harvestDTO.getInputs_provided_id());
                params.put("demo_training_status",harvestDTO.getDemo_training_status());




                Log.d("params are :", "" + params);

                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


    }

    private void sendHhiDataToServer(final HHI_InOut_DTO hhi_inOut_dto, final int con, final int size) {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_hhi_in_out_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject object= null;

                            if (jsonObject.getString("response_status").equals("1")){
                                Toast.makeText(MainActivity.this, "HHI Submitted", Toast.LENGTH_SHORT).show();
                                if(con == size-1){
                                    databaseHandlerNew.DeleteHHI();
                                }
                            }
                            else{
                                Toast.makeText(MainActivity.this, "Login Unsuccessful,Try again", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (MainActivity.this.i < 3) {
                        Log.e("Retry due to error ", "for time : " + MainActivity.this.i);
                        MainActivity.this.i++;
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(MainActivity.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Password:admin@123
                Map<String, String> params = new HashMap<>();
                params.put("employee_id",hhi_inOut_dto.getEmployee_id());
                params.put("userid",hhi_inOut_dto.getUser_id());
                params.put("district_name",hhi_inOut_dto.getDistrict_name());
                params.put("block_name",hhi_inOut_dto.getBlock_name());
                params.put("GP_name",hhi_inOut_dto.getGP_name());
                params.put("Village_name",hhi_inOut_dto.getVillage_name());


                params.put("enter_lat", hhi_inOut_dto.getEnter_lat());
                params.put("enter_long",hhi_inOut_dto.getEnter_long());





                params.put("month_no",hhi_inOut_dto.getMonth_no());
                params.put("present_year",hhi_inOut_dto.getPresent_year());
                params.put("care_hhi_slno",hhi_inOut_dto.getCare_hhi_slno());
                params.put("Spouse",hhi_inOut_dto.getSpouse());
                params.put("care_hhi",hhi_inOut_dto.getCare_hhi());
                params.put("women_name",hhi_inOut_dto.getWomen_name());


                params.put("your_id_delete_in_out","60");
                params.put("datepicker",hhi_inOut_dto.getDate_picker());
                params.put("activity",hhi_inOut_dto.getActivity());
                params.put("support",hhi_inOut_dto.getSupport());

                params.put("production",hhi_inOut_dto.getProduction());
                params.put("consumption",hhi_inOut_dto.getConsumption());
                params.put("sale",hhi_inOut_dto.getSale());
                params.put("remarks",hhi_inOut_dto.getRemark());





                Log.d("params are :", "" + params);

                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


    }

    private void sendDataToServer(final FarmlandDTO farmlandDTO, final int con, final int size) {
         progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_hhi_crop_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                           



                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject object= null;

                            if (jsonObject.getString("response_status").equals("1")){
                                Toast.makeText(MainActivity.this, "Framland Submitted", Toast.LENGTH_SHORT).show();

                                if(con == size-1){
                                    databaseHandlerNew.DeleteFarmland();
                                }

                            }
                            else{
                                Toast.makeText(MainActivity.this, "Login Unsuccessful,Try again", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (MainActivity.this.i < 3) {
                        Log.e("Retry due to error ", "for time : " + MainActivity.this.i);
                        MainActivity.this.i++;
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(MainActivity.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Password:admin@123



                Map<String, String> params = new HashMap<>();
                
                
                params.put("employee_id",farmlandDTO.getEmployee_id());
                params.put("userid",farmlandDTO.getUser_id());
                params.put("type_form_input",farmlandDTO.getType_form_input());
                params.put("type_crop_pulse", farmlandDTO.getType_crop_pulse());
                params.put("cultivated_area",farmlandDTO.getCultivated_area());
                params.put("new_farmers",farmlandDTO.getNew_farmers());
                params.put("demo_farmers",farmlandDTO.getDemo_farmers());
                params.put("continued_farmer",farmlandDTO.getContinued_farmer());
                params.put("input_received_training",farmlandDTO.getInput_received_training());
                params.put("input_received_seed",farmlandDTO.getInput_received_seed());
                params.put("input_received_fertiliser",farmlandDTO.getInput_received_fertiliser());
                params.put("input_received_pesticides",farmlandDTO.getInput_received_pesticides());
                params.put("input_received_extension",farmlandDTO.getInput_received_extension());

                params.put("specify_Input",farmlandDTO.getSpecify_Input());
                params.put("others_qnty",farmlandDTO.getOthers_qnty());
                params.put("Average_price",farmlandDTO.getAverage_price());

                params.put("others_input",farmlandDTO.getOthers_input());
                params.put("Seed_qnty",farmlandDTO.getSeed_qnty());
                params.put("Fertiliser_qnty",farmlandDTO.getFertiliser_qnty());
                params.put("Pesticides_qnty",farmlandDTO.getPesticides_qnty());

                params.put("Consumption_production",farmlandDTO.getConsumption_production());
                params.put("Sale_production",farmlandDTO.getSale_production());
                params.put("Total_production",farmlandDTO.getTotal_production());
                params.put("district_name",farmlandDTO.getDistrict_name());
                params.put("block_name",farmlandDTO.getBlock_name());
                params.put("GP_name",farmlandDTO.getGP_name());
                params.put("Village_name",farmlandDTO.getVillage_name());

              
                    params.put("enter_lat", farmlandDTO.getEnter_lat());
                    params.put("enter_long",farmlandDTO.getEnter_long());


                


                params.put("month_no",farmlandDTO.getMonth_no());
                params.put("present_year",farmlandDTO.getPresent_year());
                params.put("care_hhi_slno",farmlandDTO.getCare_hhi_slno());
                params.put("Spouse",farmlandDTO.getSpouse());
                params.put("care_hhi",farmlandDTO.getCare_hhi());
                params.put("women_name",farmlandDTO.getWomen_name());
                params.put("your_id_delete_crop",farmlandDTO.getYour_id_delete_crop());

                Log.d("params are :", "" + params);

                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);
    }

    private void getUserInfo() {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_assigned_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            JSONObject jsonObject = new JSONObject(response);

                            JSONArray jsonArray = jsonObject.getJSONArray("Type_of_pulses");
                            JSONArray village = jsonObject.getJSONArray("location_information");

                            //Training moudle
                            JSONObject training_module = jsonObject.getJSONObject("training_module");

                            JSONObject thematic_information = training_module.getJSONObject("thematic_information");
                            JSONArray Thematic_Intervention_new = thematic_information.getJSONArray("Thematic_Intervention_new");
                            JSONArray Topics_Covered = thematic_information.getJSONArray("Topics_Covered");


                            JSONArray Type_of_group = training_module.getJSONArray("Type_of_group");
                            JSONArray Training_Facilitator = training_module.getJSONArray("Training_Facilitator");
                            JSONArray Type_of_Training = training_module.getJSONArray("Type_of_Training");

                            //SHG moudle
                            JSONObject shg_module = jsonObject.getJSONObject("shg_module");
                            JSONArray Type_of_shg_committee = shg_module.getJSONArray("Type_of_shg_committee");


                            //PHL moudle
                            JSONObject phl_module = jsonObject.getJSONObject("phl_module");
                            JSONArray subject_matter_class = phl_module.getJSONArray("subject_matter_class");
                            JSONArray subject_matter_demonstrator = phl_module.getJSONArray("subject_matter_demonstrator");
                            JSONArray phl_Inputs_provided = phl_module.getJSONArray("phl_Inputs_provided");

                            //lst moudle
                            JSONObject lst_module = jsonObject.getJSONObject("lst_module");
                            JSONArray lst_target = lst_module.getJSONArray("lst_target");


                            if (jsonArray.length() > 0) {



                                for (int j=0;j<jsonArray.length();j++){
                                    JSONObject object = jsonArray.getJSONObject(j);

                                    databaseHandlerNew.AddPluses(object.getString("item_crop"));

                                }

                                  databaseHandlerNew.DeleteNewRequest();
                                for (int j=0;j<village.length();j++){
                                    JSONObject object = village.getJSONObject(j);

                                    databaseHandlerNew.AddLocationInfromation(object.getString("care_assU_employee_id"),object.getString("care_assU_district_id"),object.getString("care_assU_block_id"),object.getString("care_assU_gp_id"),object.getString("care_assU_village_id"));

                                }
                                databaseHandlerNew.DeleteThematic();
                                for (int j=0;j<Thematic_Intervention_new.length();j++){
                                    JSONObject object = Thematic_Intervention_new.getJSONObject(j);

                                    databaseHandlerNew.AddThematic(object.getString("Thematic_key"),object.getString("Thematic_name"));

                                }
                                databaseHandlerNew.DeleteCare();
                                for (int j=0;j<Topics_Covered.length();j++){
                                    JSONObject object = Topics_Covered.getJSONObject(j);

                                    databaseHandlerNew.AddTopivCover(object.getString("care_training_name"),object.getString("care_training_thematic"));

                                }
                                for (int j=0;j<Type_of_group.length();j++){
                                    JSONObject object = Type_of_group.getJSONObject(j);

                                    databaseHandlerNew.AddGroup(object.getString("care_group_name"));

                                }
                                for (int j=0;j<Training_Facilitator.length();j++){


                                    databaseHandlerNew.AddFacilitator(Training_Facilitator.getString(j));

                                }
                                for (int j=0;j<Type_of_Training.length();j++){


                                    JSONObject object = Type_of_Training.getJSONObject(j);

                                    databaseHandlerNew.AddTrainingType(object.getString("care_trng_name"));

                                }
                                for (int j=0;j<Type_of_shg_committee.length();j++){


                                    JSONObject object = Type_of_shg_committee.getJSONObject(j);

                                    databaseHandlerNew.AddShgType(object.getString("care_comm_name"));

                                }

                                for (int j=0;j<subject_matter_class.length();j++){


                                    JSONObject object = subject_matter_class.getJSONObject(j);

                                    databaseHandlerNew.AddSubject(object.getString("id_class"),object.getString("subject_class"));

                                }

                                for (int j=0;j<subject_matter_demonstrator.length();j++){


                                    JSONObject object = subject_matter_demonstrator.getJSONObject(j);

                                    databaseHandlerNew.AddDemon(object.getString("id_demo"),object.getString("subject_demo"));

                                }

                                for (int j=0;j<phl_Inputs_provided.length();j++){


                                    JSONObject object = phl_Inputs_provided.getJSONObject(j);

                                    databaseHandlerNew.AddPhl(object.getString("phl_input_key"),object.getString("phl_input_name"));

                                }

                                for (int j=0;j<lst_target.length();j++){


                                    JSONObject object = lst_target.getJSONObject(j);

                                    databaseHandlerNew.AddLST(object.getString("Care_slno"),object.getString("care_activity_name"));

                                }
                            }
                            else{

                                Toast.makeText(MainActivity.this, "No Data for this search",
                                        Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (i < 3) {
                        Log.e("Retry due to error ", "for time : " + i);
                        i++;
                        getUserInfo();
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(MainActivity.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {



                Map<String, String> params = new HashMap<>();
                params.put("employee_id",sharedPreferenceClass.getValue_string("employee_id"));
                params.put("userid",sharedPreferenceClass.getValue_string("userid"));



                Log.d("params are :", "" + params);
                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);
    }
}
