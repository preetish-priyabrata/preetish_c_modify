package ctp.release.com.care.DTO;

/**
 * Created by admin on 24-01-2018.
 */

public class LivestockDTO {
    String employee_id;
    String user_id;
    String district_name;
    String block_name;
    String GP_name;
    String Village_name;
    String enter_lat;
    String enter_long;
    String month_no;
    String present_year;
    String care_hhi_slno;
    String Spouse;
    String care_hhi;
    String women_name;
    String your_id_delete_livestock_id;
    String type_insert_live_stock;
    String input_training;
    String input_extension_suport;
    String input_extension_suport_animal_no;

    String input_medicine;
    String input_medicine_animal_no;
    String input_vaccination;
    String input_vaccination_animal_no;
    String input_other;
    String input_other_detail;


    String animal_present_no;
    String cultivating_fodder;
    String cultivated_area_fodder;
    String new_farmer;



    String continued_farmer;
    String care_LS_QP_extension_support;
    String medicine_name_array;
    String medicine_qnty_array;
    String vaccination_name_array;



    String vaccination_qnty_array;
    String othera_name_array;
    String othera_qnty_array;

    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getDistrict_name() {
        return district_name;
    }

    public void setDistrict_name(String district_name) {
        this.district_name = district_name;
    }

    public String getBlock_name() {
        return block_name;
    }

    public void setBlock_name(String block_name) {
        this.block_name = block_name;
    }

    public String getGP_name() {
        return GP_name;
    }

    public void setGP_name(String GP_name) {
        this.GP_name = GP_name;
    }

    public String getVillage_name() {
        return Village_name;
    }

    public void setVillage_name(String village_name) {
        Village_name = village_name;
    }

    public String getEnter_lat() {
        return enter_lat;
    }

    public void setEnter_lat(String enter_lat) {
        this.enter_lat = enter_lat;
    }

    public String getEnter_long() {
        return enter_long;
    }

    public void setEnter_long(String enter_long) {
        this.enter_long = enter_long;
    }

    public String getMonth_no() {
        return month_no;
    }

    public void setMonth_no(String month_no) {
        this.month_no = month_no;
    }

    public String getPresent_year() {
        return present_year;
    }

    public void setPresent_year(String present_year) {
        this.present_year = present_year;
    }

    public String getCare_hhi_slno() {
        return care_hhi_slno;
    }

    public void setCare_hhi_slno(String care_hhi_slno) {
        this.care_hhi_slno = care_hhi_slno;
    }

    public String getSpouse() {
        return Spouse;
    }

    public void setSpouse(String spouse) {
        Spouse = spouse;
    }

    public String getCare_hhi() {
        return care_hhi;
    }

    public void setCare_hhi(String care_hhi) {
        this.care_hhi = care_hhi;
    }

    public String getWomen_name() {
        return women_name;
    }

    public void setWomen_name(String women_name) {
        this.women_name = women_name;
    }

    public String getYour_id_delete_livestock_id() {
        return your_id_delete_livestock_id;
    }

    public void setYour_id_delete_livestock_id(String your_id_delete_livestock_id) {
        this.your_id_delete_livestock_id = your_id_delete_livestock_id;
    }

    public String getType_insert_live_stock() {
        return type_insert_live_stock;
    }

    public void setType_insert_live_stock(String type_insert_live_stock) {
        this.type_insert_live_stock = type_insert_live_stock;
    }

    public String getInput_training() {
        return input_training;
    }

    public void setInput_training(String input_training) {
        this.input_training = input_training;
    }

    public String getInput_extension_suport() {
        return input_extension_suport;
    }

    public void setInput_extension_suport(String input_extension_suport) {
        this.input_extension_suport = input_extension_suport;
    }

    public String getInput_extension_suport_animal_no() {
        return input_extension_suport_animal_no;
    }

    public void setInput_extension_suport_animal_no(String input_extension_suport_animal_no) {
        this.input_extension_suport_animal_no = input_extension_suport_animal_no;
    }

    public String getInput_medicine() {
        return input_medicine;
    }

    public void setInput_medicine(String input_medicine) {
        this.input_medicine = input_medicine;
    }

    public String getInput_medicine_animal_no() {
        return input_medicine_animal_no;
    }

    public void setInput_medicine_animal_no(String input_medicine_animal_no) {
        this.input_medicine_animal_no = input_medicine_animal_no;
    }

    public String getInput_vaccination() {
        return input_vaccination;
    }

    public void setInput_vaccination(String input_vaccination) {
        this.input_vaccination = input_vaccination;
    }

    public String getInput_vaccination_animal_no() {
        return input_vaccination_animal_no;
    }

    public void setInput_vaccination_animal_no(String input_vaccination_animal_no) {
        this.input_vaccination_animal_no = input_vaccination_animal_no;
    }

    public String getInput_other() {
        return input_other;
    }

    public void setInput_other(String input_other) {
        this.input_other = input_other;
    }

    public String getInput_other_detail() {
        return input_other_detail;
    }

    public void setInput_other_detail(String input_other_detail) {
        this.input_other_detail = input_other_detail;
    }

    public String getAnimal_present_no() {
        return animal_present_no;
    }

    public void setAnimal_present_no(String animal_present_no) {
        this.animal_present_no = animal_present_no;
    }

    public String getCultivating_fodder() {
        return cultivating_fodder;
    }

    public void setCultivating_fodder(String cultivating_fodder) {
        this.cultivating_fodder = cultivating_fodder;
    }

    public String getCultivated_area_fodder() {
        return cultivated_area_fodder;
    }

    public void setCultivated_area_fodder(String cultivated_area_fodder) {
        this.cultivated_area_fodder = cultivated_area_fodder;
    }

    public String getNew_farmer() {
        return new_farmer;
    }

    public void setNew_farmer(String new_farmer) {
        this.new_farmer = new_farmer;
    }

    public String getContinued_farmer() {
        return continued_farmer;
    }

    public void setContinued_farmer(String continued_farmer) {
        this.continued_farmer = continued_farmer;
    }

    public String getCare_LS_QP_extension_support() {
        return care_LS_QP_extension_support;
    }

    public void setCare_LS_QP_extension_support(String care_LS_QP_extension_support) {
        this.care_LS_QP_extension_support = care_LS_QP_extension_support;
    }

    public String getMedicine_name_array() {
        return medicine_name_array;
    }

    public void setMedicine_name_array(String medicine_name_array) {
        this.medicine_name_array = medicine_name_array;
    }

    public String getMedicine_qnty_array() {
        return medicine_qnty_array;
    }

    public void setMedicine_qnty_array(String medicine_qnty_array) {
        this.medicine_qnty_array = medicine_qnty_array;
    }

    public String getVaccination_name_array() {
        return vaccination_name_array;
    }

    public void setVaccination_name_array(String vaccination_name_array) {
        this.vaccination_name_array = vaccination_name_array;
    }
    public String getVaccination_qnty_array() {
        return vaccination_qnty_array;
    }

    public void setVaccination_qnty_array(String vaccination_qnty_array) {
        this.vaccination_qnty_array = vaccination_qnty_array;
    }

    public String getOthera_name_array() {
        return othera_name_array;
    }

    public void setOthera_name_array(String othera_name_array) {
        this.othera_name_array = othera_name_array;
    }

    public String getOthera_qnty_array() {
        return othera_qnty_array;
    }

    public void setOthera_qnty_array(String othera_qnty_array) {
        this.othera_qnty_array = othera_qnty_array;
    }
}
