package ctp.release.com.care;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

public class SHGForm extends AppCompatActivity {
    EditText saving_passbook,passbook, gr_passbook,year,month,member_committee,committee_name,nutrition;
    EditText total_members,last_meet_date, member_presence,meeting_register,cash_book,linkage_credit,bank,member_linkage,technical_support;
    EditText purpose_linkage,topic_nutrition,accessed_agri,what_service,msp_faq,what_topic,discussed_agriculture,what_agriculture;
    private int mYear, mMonth, mDay, mHour, mMinute;
    SharedPreferenceClass sharedPreferenceClass;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    String [] committee_array = {"SMC","Health","Water&sanitations","PanchayatRaj","Ward Member","Forest Rights committee","ASHA","AWW","Other CRP"};
    String [] select_array = {"Yes","No"};
    String monthId ="";
    Button save;
    ProgressDialog progressDialog;
    int i=0;
    AlertDialog dialog;
    GPSTracker mGPS;
    DatabaseHandlerNew databaseHandlerNew;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shgform);
        sharedPreferenceClass  = new SharedPreferenceClass(this);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        mGPS = new GPSTracker(SHGForm.this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        progressDialog=new ProgressDialog(this);
        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);

        last_meet_date= (EditText) findViewById(R.id.last_meet_date);
        total_members= (EditText) findViewById(R.id.total_members);
        member_presence= (EditText) findViewById(R.id.member_presence);
        meeting_register= (EditText) findViewById(R.id.meeting_register);

        cash_book= (EditText) findViewById(R.id.cash_book);
        linkage_credit= (EditText) findViewById(R.id.linkage_credit);
        bank= (EditText) findViewById(R.id.bank);
        member_linkage= (EditText) findViewById(R.id.member_linkage);
        technical_support= (EditText) findViewById(R.id.technical_support);
        saving_passbook= (EditText) findViewById(R.id.saving_passbook);
        passbook= (EditText) findViewById(R.id.passbook);
        gr_passbook= (EditText) findViewById(R.id.gr_passbook);
        member_committee= (EditText) findViewById(R.id.member_committee);
        committee_name= (EditText) findViewById(R.id.committee_name);
        nutrition= (EditText) findViewById(R.id.nutrition);

        purpose_linkage= (EditText) findViewById(R.id.purpose_linkage);
        topic_nutrition= (EditText) findViewById(R.id.topic_nutrition);
        accessed_agri= (EditText) findViewById(R.id.accessed_agri);
        what_service= (EditText) findViewById(R.id.what_service);
        msp_faq= (EditText) findViewById(R.id.msp_faq);
        what_topic= (EditText) findViewById(R.id.what_topic);
        discussed_agriculture= (EditText) findViewById(R.id.discussed_agriculture);
        what_agriculture= (EditText) findViewById(R.id.what_agriculture);

        meeting_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(meeting_register.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(meeting_register, "Please select",
                        select_array, pos, "");
            }
        });

        cash_book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(cash_book.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(cash_book, "Please select",
                        select_array, pos, "");

            }
        });

        passbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(passbook.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(passbook, "Please select",
                        select_array, pos, "");
            }
        });

        gr_passbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(gr_passbook.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(gr_passbook, "Please select",
                        select_array, pos, "");
            }
        });

        saving_passbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(saving_passbook.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(saving_passbook, "Please select",
                        select_array, pos, "");
            }
        });

        nutrition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(nutrition.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(nutrition, "Please select",
                        select_array, pos, "");
            }
        });

        linkage_credit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(linkage_credit.getText().toString())) {
                        pos = i;
                    }
                }
                showCommitteeList(linkage_credit, "Please select",
                        select_array, pos, "");
            }
        });

        committee_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i =0; i<committee_array.length; i++){
                    if (committee_array[i].equals(committee_name.getText().toString())){
                        pos = i;
                    }
                }
                showCommitteeList(committee_name, "Please select committee",
                        committee_array, pos, "");
            }
        });

        purpose_linkage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i =0; i<select_array.length; i++){
                    if (select_array[i].equals(purpose_linkage.getText().toString())){
                        pos = i;
                    }
                }
                showCommitteeList(purpose_linkage, "Please select",
                        select_array, pos,"purpose_linkage");
            }
        });
        topic_nutrition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i =0; i<select_array.length; i++){
                    if (select_array[i].equals(topic_nutrition.getText().toString())){
                        pos = i;
                    }
                }
                showCommitteeList(topic_nutrition, "Please select",
                        select_array, pos,"topic_nutrition");
            }
        });
        accessed_agri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i =0; i<select_array.length; i++){
                    if (select_array[i].equals(accessed_agri.getText().toString())){
                        pos = i;
                    }
                }
                showCommitteeList(accessed_agri, "Please select",
                        select_array, pos,"accessed_agri");
            }
        });
        msp_faq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i =0; i<select_array.length; i++){
                    if (select_array[i].equals(msp_faq.getText().toString())){
                        pos = i;
                    }
                }
                showCommitteeList(msp_faq, "Please select",
                        select_array, pos, "msp_faq");
            }
        });
        discussed_agriculture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i =0; i<select_array.length; i++){
                    if (select_array[i].equals(discussed_agriculture.getText().toString())){
                        pos = i;
                    }
                }
                showCommitteeList(discussed_agriculture, "Please select",
                        select_array, pos, "discussed_agriculture");
            }
        });

        month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <month_array.length; i++) {
                    if (month_array[i].equals(month.getText().toString())) {
                        pos = i;
                    }
                }
                showMonthList(month, "Please select month",
                        month_array, pos);
            }
        });
        year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <year_array.length; i++) {
                    if (year_array[i].equals(year.getText().toString())) {
                        pos = i;
                    }
                }
                showYearList(year, "Please select year",
                        year_array, pos);
            }
        });

        last_meet_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get Current Date
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(SHGForm.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                last_meet_date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

        save= (Button) findViewById(R.id.save_farmland);




        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mGPS.canGetLocation) {
                    sendDatabase();
                }
                else{
                    Toast.makeText(SHGForm.this, "We can not get your location please enable your gps", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    private void sendDatabase() {
        Random r = new Random();
        int randomNumber = r.nextInt(1234567890);

        databaseHandlerNew.AddShg_Form( sharedPreferenceClass.getValue_string("employee_id"),
       sharedPreferenceClass.getValue_string("userid"),
        getIntent().getStringExtra("dist"),
        getIntent().getStringExtra("block"),

        getIntent().getStringExtra("gp"),
        getIntent().getStringExtra("village"),
         String.valueOf(mGPS.getLatitude()),
         String.valueOf(mGPS.getLongitude()),
        monthId,

        year.getText().toString(),
        getIntent().getStringExtra("care_shg_slno"),
        getIntent().getStringExtra("care_shg_id"),
        getIntent().getStringExtra("care_shg_name"),
        String.valueOf(randomNumber),

        getYesNo(meeting_register.getText().toString()),
        getYesNo(cash_book.getText().toString()),
        getYesNo(passbook.getText().toString()),
        getYesNo(gr_passbook.getText().toString()),
        getYesNo(saving_passbook.getText().toString()),
        getYesNo(nutrition.getText().toString()),
        getYesNo(linkage_credit.getText().toString()),
        total_members.getText().toString(),
        last_meet_date.getText().toString(),
        member_presence.getText().toString(),
        bank.getText().toString(),
        member_linkage.getText().toString(),
        technical_support.getText().toString(),
        member_committee.getText().toString(),
        committee_name.getText().toString(),
                getYesNo(accessed_agri.getText().toString()),
                what_service.getText().toString(),
                getYesNo(msp_faq.getText().toString()),
                what_topic.getText().toString(),
                getYesNo(discussed_agriculture.getText().toString()),
                what_agriculture.getText().toString(),
                getYesNo(purpose_linkage.getText().toString()),
                getYesNo(topic_nutrition.getText().toString()));

        Toast.makeText(SHGForm.this, "Submitted", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(SHGForm.this,SHGFormView.class);
        intent.putExtra("id",String.valueOf(randomNumber));
        startActivity(intent);
        finish();
    }

    private void showCommitteeList(final EditText text3, String s3, final String[] coverage, int pos, final String name) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            if(name.endsWith("accessed_agri"))
                            {
                                if (text3.getText().toString().equals("Yes")){
                                    what_service.setText("");
                                    what_service.setEnabled(true);
                                }
                                else{
                                    what_service.setText("");
                                    what_service.setEnabled(false);
                                }
                            }
                            else if(name.endsWith("msp_faq"))
                            {
                                if (text3.getText().toString().equals("Yes")){
                                    what_topic.setText("");
                                    what_topic.setEnabled(true);
                                }
                                else{
                                    what_topic.setText("");
                                    what_topic.setEnabled(false);
                                }
                            }
                            else if(name.endsWith("discussed_agriculture"))
                            {
                                if (text3.getText().toString().equals("Yes")){
                                    what_agriculture.setText("");
                                    what_agriculture.setEnabled(true);
                                }
                                else{
                                    what_agriculture.setText("");
                                    what_agriculture.setEnabled(false);
                                }
                            }

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }


    private void submit() {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_shg_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject object= null;

                            if (jsonObject.getString("response_status").equals("1")){
                                Toast.makeText(SHGForm.this, "Submitted", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                            else{
                                Toast.makeText(SHGForm.this, "Please insert all data", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (i < 3) {
                        Log.e("Retry due to error ", "for time : " + i);
                        i++;
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(SHGForm.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(SHGForm.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Password:admin@123
                Map<String, String> params = new HashMap<>();
                params.put("employee_id",sharedPreferenceClass.getValue_string("employee_id"));
                params.put("userid",sharedPreferenceClass.getValue_string("userid"));
                params.put("district_name",getIntent().getStringExtra("dist"));
                params.put("block_name",getIntent().getStringExtra("block"));

                params.put("GP_name",getIntent().getStringExtra("gp"));
                params.put("Village_name",getIntent().getStringExtra("village"));
                params.put("enter_lat", String.valueOf(mGPS.getLatitude()));
                params.put("enter_long", String.valueOf(mGPS.getLongitude()));
                params.put("month_no",monthId);

                params.put("present_year",year.getText().toString());
                params.put("care_shg_slno",getIntent().getStringExtra("care_shg_slno"));
                params.put("care_shg_id",getIntent().getStringExtra("care_shg_id"));
                params.put("care_shg_name",getIntent().getStringExtra("care_shg_name"));
                params.put("your_id_delete_shg_id","1");

                params.put("Meeting",getYesNo(meeting_register.getText().toString()));
                params.put("Cash",getYesNo(cash_book.getText().toString()));
                params.put("Individual",getYesNo(passbook.getText().toString()));
                params.put("Group",getYesNo(gr_passbook.getText().toString()));
                params.put("Saving",getYesNo(saving_passbook.getText().toString()));
                params.put("Monthly_status",getYesNo(nutrition.getText().toString()));
                params.put("Linkage_external_credit",getYesNo(linkage_credit.getText().toString()));


                params.put("no_of_member",total_members.getText().toString());
                params.put("last_event_date",last_meet_date.getText().toString());
                params.put("member_present_month_meeting",member_presence.getText().toString());
                params.put("Bank_linked",bank.getText().toString());
                params.put("linkages_market",member_linkage.getText().toString());
                params.put("linkages_technical_support",technical_support.getText().toString());
                params.put("committee_no_linked",member_committee.getText().toString());
                params.put("committee_name",committee_name.getText().toString());





                Log.d("params are :", "" + params);

                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


    }

    private String getYesNo(String s) {

        if(s.equals("Yes")){
            return "1";
        }
        else{
            return "2";
        }

    }


    private void showMonthList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    monthId = String.valueOf(i+1);
                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    private void showYearList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }

}
