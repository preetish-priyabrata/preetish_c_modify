package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class LocationDTO {

    private String care_assU_employee_id;
    private String care_assU_district_id;
    private String care_assU_block_id;
    private String care_assU_gp_id;
    private String care_assU_village_id;

    public String getCare_assU_employee_id() {
        return care_assU_employee_id;
    }

    public void setCare_assU_employee_id(String care_assU_employee_id) {
        this.care_assU_employee_id = care_assU_employee_id;
    }

    public String getCare_assU_district_id() {
        return care_assU_district_id;
    }

    public void setCare_assU_district_id(String care_assU_district_id) {
        this.care_assU_district_id = care_assU_district_id;
    }

    public String getCare_assU_block_id() {
        return care_assU_block_id;
    }

    public void setCare_assU_block_id(String care_assU_block_id) {
        this.care_assU_block_id = care_assU_block_id;
    }

    public String getCare_assU_gp_id() {
        return care_assU_gp_id;
    }

    public void setCare_assU_gp_id(String care_assU_gp_id) {
        this.care_assU_gp_id = care_assU_gp_id;
    }

    public String getCare_assU_village_id() {
        return care_assU_village_id;
    }

    public void setCare_assU_village_id(String care_assU_village_id) {
        this.care_assU_village_id = care_assU_village_id;
    }
}
