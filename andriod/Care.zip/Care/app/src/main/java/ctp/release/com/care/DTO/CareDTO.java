package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class CareDTO {
    String care_training_name;
    String care_training_thematic;

    public String getCare_training_name() {
        return care_training_name;
    }

    public void setCare_training_name(String care_training_name) {
        this.care_training_name = care_training_name;
    }

    public String getCare_training_thematic() {
        return care_training_thematic;
    }

    public void setCare_training_thematic(String care_training_thematic) {
        this.care_training_thematic = care_training_thematic;
    }
}
