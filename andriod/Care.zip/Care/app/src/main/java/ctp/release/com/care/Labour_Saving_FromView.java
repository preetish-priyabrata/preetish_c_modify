package ctp.release.com.care;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import ctp.release.com.care.DTO.LabourDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

/**
 * Created by admin on 09-01-2018.
 */

public class Labour_Saving_FromView extends AppCompatActivity {
    EditText year,month;
    EditText implement_device,target_activity,training_setting,demonstration_date,present_male,present_female,device_use,farmer_using_male,farmer_using_female;
    String [] select_array = {"Yes","No"};
    Button save;
    ProgressDialog progressDialog;
    int i=0;
    AlertDialog dialog;
SharedPreferenceClass sharedPreferenceClass;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    private int mYear, mMonth, mDay, mHour, mMinute;
    String monthId ="";
    GPSTracker mGPS;
    DatabaseHandlerNew databaseHandlerNew;
    ArrayList<LabourDTO> labourDTOs = new ArrayList<LabourDTO>();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.labour_saving);
        databaseHandlerNew=new DatabaseHandlerNew(this);
        sharedPreferenceClass = new SharedPreferenceClass(this);
        mGPS = new GPSTracker(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        progressDialog=new ProgressDialog(this);

        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);
        implement_device= (EditText) findViewById(R.id.implement_device);
        target_activity= (EditText) findViewById(R.id.target_activity);
        training_setting= (EditText) findViewById(R.id.training_setting);
        demonstration_date= (EditText) findViewById(R.id.demonstration_date);
        present_male= (EditText) findViewById(R.id.present_male);
        present_female= (EditText) findViewById(R.id.present_female);
        device_use= (EditText) findViewById(R.id.device_use);
        farmer_using_male= (EditText) findViewById(R.id.farmer_using_male);
        farmer_using_female= (EditText) findViewById(R.id.farmer_using_female);




        save= (Button) findViewById(R.id.save_farmland);


        year.setEnabled(false);
        month.setEnabled(false);
        implement_device.setEnabled(false);
        target_activity.setEnabled(false);
        training_setting.setEnabled(false);
        demonstration_date.setEnabled(false);
        present_male.setEnabled(false);
        present_female.setEnabled(false);
        device_use.setEnabled(false);
        farmer_using_male.setEnabled(false);
        farmer_using_female.setEnabled(false);

        labourDTOs = databaseHandlerNew.getLabou_DataWithID(getIntent().getStringExtra("id"));

        year.setText(labourDTOs.get(0).getPresent_year());
        month.setText((month_array[Integer.valueOf(labourDTOs.get(0).getMonth_no())-1]));
        implement_device.setText(labourDTOs.get(0).getImplemant_device_name());
        target_activity.setText(getYesNo(labourDTOs.get(0).getTraget_active_id()));
        training_setting.setText(getYesNo(labourDTOs.get(0).getClass_training_status()));
        demonstration_date.setText(labourDTOs.get(0).getDemostration_date());
        present_male.setText(labourDTOs.get(0).getMale_present());
        present_female.setText(labourDTOs.get(0).getFemale_present());
        device_use.setText(getYesNo(labourDTOs.get(0).getDevice_implement_status()));
        farmer_using_male.setText(labourDTOs.get(0).getFarmer_implement_male());
        farmer_using_female.setText(labourDTOs.get(0).getFarmer_implement_female());


    save.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

finish();
       }
    });

    }

    private String getYesNo(String val){

        if(val.equals("1")){
            return "Yes";
        }
        else{
            return "No";
        }

    }

}
