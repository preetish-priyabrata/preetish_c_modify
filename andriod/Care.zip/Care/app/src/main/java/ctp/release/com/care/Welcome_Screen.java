package ctp.release.com.care;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import ctp.release.com.care.others.SharedPreferenceClass;

/**
 * Created by admin on 26-02-2017.
 */

public class Welcome_Screen extends AppCompatActivity {
    Handler handler=new Handler();
    SharedPreferenceClass sharedPreferenceClass;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_screen);
        sharedPreferenceClass = new SharedPreferenceClass(this);

        handler.postDelayed(new Runnable() {

            @Override
            public void run() {


if(sharedPreferenceClass.getValue_string("isLogin").equals("true")) {

    Intent intent = new Intent();
    intent.setClass(Welcome_Screen.this, MainActivity.class);
    startActivity(intent);
    finish();
     }
else{
    Intent intent = new Intent();
    intent.setClass(Welcome_Screen.this, Login_Page.class);
    startActivity(intent);
    finish();
}

            }
        }, 3000);


    }
}