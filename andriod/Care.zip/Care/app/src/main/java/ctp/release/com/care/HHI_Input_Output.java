package ctp.release.com.care;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import ctp.release.com.care.DTO.ThematicDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

/**
 * Created by admin on 09-01-2018.
 */

public class HHI_Input_Output extends AppCompatActivity {
    String [] thematic_intervation = {"HKG","Crop Diversification","LST","Post Harvest Management","poultry","Goatery","Diary","collective strenghtening","bcc"};
    String [] thematic_intervation_key;
    EditText date,activity, support,year,month;
    EditText production,consumption, sale,remark,signature;
    private int mYear, mMonth, mDay, mHour, mMinute;
SharedPreferenceClass sharedPreferenceClass;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    ArrayList<ThematicDTO> thematicDTOs ;
    String monthId ="",thematic_id = "";;
    GPSTracker mGPS;
    Button save;
    ProgressDialog progressDialog;
    int i=0;
    AlertDialog dialog;
    DatabaseHandlerNew databaseHandlerNew;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hhi_input_output);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        thematicDTOs = new ArrayList<ThematicDTO>();
        sharedPreferenceClass  = new SharedPreferenceClass(this);
        mGPS = new GPSTracker(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        progressDialog=new ProgressDialog(this);
        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);

        date= (EditText) findViewById(R.id.date);
        activity= (EditText) findViewById(R.id.activity);
        support= (EditText) findViewById(R.id.support);
        production= (EditText) findViewById(R.id.production);

        consumption= (EditText) findViewById(R.id.consumption);
        sale= (EditText) findViewById(R.id.sale);
        remark= (EditText) findViewById(R.id.remark);
        signature= (EditText) findViewById(R.id.signature);

        thematicDTOs = databaseHandlerNew.getThematic();

        month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <month_array.length; i++) {
                    if (month_array[i].equals(month.getText().toString())) {
                        pos = i;
                    }
                }
                showMonthList(month, "Please select month",
                        month_array, pos);
            }
        });
        year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <year_array.length; i++) {
                    if (year_array[i].equals(year.getText().toString())) {
                        pos = i;
                    }
                }
                showYearList(year, "Please select year",
                        year_array, pos);
            }
        });

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get Current Date
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(HHI_Input_Output.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

        thematic_intervation = new String[thematicDTOs.size()];
        thematic_intervation_key = new String[thematicDTOs.size()];
        for(int i=0;i<thematicDTOs.size();i++){
            thematic_intervation[i] = thematicDTOs.get(i).getThematic_name();
            thematic_intervation_key[i] = thematicDTOs.get(i).getThematic_key();
        }

        activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <thematic_intervation.length; i++) {
                    if (thematic_intervation[i].equals(activity.getText().toString())) {
                        pos = i;
                    }
                }
                showThematicList(activity, "Please select thematic innervation",
                        thematic_intervation, pos);
            }
        });


        save= (Button) findViewById(R.id.save_farmland);




    save.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if(mGPS.canGetLocation) {
            saveData();
        }
        else{
            Toast.makeText(HHI_Input_Output.this, "We can not get your location please enable your gps", Toast.LENGTH_SHORT).show();
        }

       }
    });

    }

    private void saveData() {
        Random r = new Random();
        int randomNumber = r.nextInt(1234567890);

        databaseHandlerNew.AddHHI_Input_Output(
        sharedPreferenceClass.getValue_string("employee_id"),
        sharedPreferenceClass.getValue_string("userid"),
        getIntent().getStringExtra("dist"),
        getIntent().getStringExtra("block"),
        getIntent().getStringExtra("gp"),
        getIntent().getStringExtra("village"),
        String.valueOf(mGPS.getLatitude()),
        String.valueOf(mGPS.getLongitude()),
        monthId,
        year.getText().toString(),
        getIntent().getStringExtra("care_hhi_id"),
        getIntent().getStringExtra("care_spouse_name"),
        getIntent().getStringExtra("care_hhi_id"),
        getIntent().getStringExtra("care_women_farmer"),
        String.valueOf(randomNumber),
        date.getText().toString(),
        thematic_id,
        support.getText().toString(),
        production.getText().toString(),
        consumption.getText().toString(),
        sale.getText().toString(),
        remark.getText().toString());

        Toast.makeText(HHI_Input_Output.this, "Submitted", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(HHI_Input_Output.this,HHI_Input_OutputView.class);
        intent.putExtra("id",String.valueOf(randomNumber));
        startActivity(intent);
        finish();
    }



    private void submit() {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_hhi_in_out_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject object= null;

                            if (jsonObject.getString("response_status").equals("1")){
                                Toast.makeText(HHI_Input_Output.this, "Submitted", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                            else{
                                Toast.makeText(HHI_Input_Output.this, "Login Unsuccessful,Try again", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (i < 3) {
                        Log.e("Retry due to error ", "for time : " + i);
                        i++;
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(HHI_Input_Output.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(HHI_Input_Output.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Password:admin@123
                Map<String, String> params = new HashMap<>();
                params.put("employee_id",sharedPreferenceClass.getValue_string("employee_id"));
                params.put("userid",sharedPreferenceClass.getValue_string("userid"));
                params.put("district_name",getIntent().getStringExtra("dist"));
                params.put("block_name",getIntent().getStringExtra("block"));

                params.put("GP_name",getIntent().getStringExtra("gp"));
                params.put("Village_name",getIntent().getStringExtra("village"));
                params.put("enter_lat", String.valueOf(mGPS.getLatitude()));
                params.put("enter_long", String.valueOf(mGPS.getLongitude()));
                params.put("month_no",monthId);

                params.put("present_year",year.getText().toString());
                params.put("care_hhi_slno",getIntent().getStringExtra("care_hhi_id"));
                params.put("Spouse",getIntent().getStringExtra("care_spouse_name"));
                params.put("care_hhi",getIntent().getStringExtra("care_hhi_id"));
                params.put("women_name",getIntent().getStringExtra("care_women_farmer"));

                params.put("your_id_delete_in_out","60");
                params.put("datepicker",date.getText().toString());
                params.put("activity",activity.getText().toString());
                params.put("support",support.getText().toString());

                params.put("production",production.getText().toString());
                params.put("consumption",consumption.getText().toString());
                params.put("sale",sale.getText().toString());
                params.put("remarks",remark.getText().toString());





                Log.d("params are :", "" + params);

                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


    }

    private void showMonthList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    monthId = String.valueOf(i+1);
                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    private void showYearList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    private void showThematicList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    thematic_id = thematic_intervation_key[i];



                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }

}
