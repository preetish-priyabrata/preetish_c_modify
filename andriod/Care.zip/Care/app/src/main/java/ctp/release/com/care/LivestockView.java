package ctp.release.com.care;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import ctp.release.com.care.DTO.LivestockDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

public class LivestockView extends AppCompatActivity {
    Toolbar toolbar;
    EditText year,month,training_stock,extension,no_animals,medicine,animals_received_medicine,vaccination,
            no_animals_vaccine,others_specify,animal_present,fodder,area_cultivated,new_farmers,conitued_farmers,extension_support,medicine_name,medicine_quantity,vaccination_name,vaccination_quantity,other_name,other_quantity;
    ProgressDialog progressDialog;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    String [] select_array = {"Yes","No"};
    String monthId ="";
    int i=0;
    Button save_livestock;

    AlertDialog dialog;
    SharedPreferenceClass sharedPreferenceClass;
    GPSTracker mGPS;
    DatabaseHandlerNew databaseHandlerNew;
    ArrayList<LivestockDTO> livestockDTOs = new ArrayList<LivestockDTO>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_livestock);
        progressDialog=new ProgressDialog(this);
        sharedPreferenceClass=new SharedPreferenceClass(this);
        databaseHandlerNew=new DatabaseHandlerNew(this);
        mGPS = new GPSTracker(LivestockView.this);
        toolbar= (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);
        training_stock= (EditText) findViewById(R.id.training_stock);
        extension= (EditText) findViewById(R.id.extension);
        no_animals= (EditText) findViewById(R.id.no_animals);
        medicine= (EditText) findViewById(R.id.medicine);
        animals_received_medicine= (EditText) findViewById(R.id.animals_received_medicine);
        vaccination= (EditText) findViewById(R.id.vaccination);
        no_animals_vaccine= (EditText) findViewById(R.id.no_animals_vaccine);
        others_specify= (EditText) findViewById(R.id.others_specify);

        animal_present= (EditText) findViewById(R.id.animal_present);
        fodder= (EditText) findViewById(R.id.fodder);
        area_cultivated= (EditText) findViewById(R.id.area_cultivated);
        new_farmers= (EditText) findViewById(R.id.new_farmers);
        conitued_farmers= (EditText) findViewById(R.id.conitued_farmers);

        extension_support= (EditText) findViewById(R.id.extension_support);
        medicine_name= (EditText) findViewById(R.id.medicine_name);
        medicine_quantity= (EditText) findViewById(R.id.medicine_quantity);
        vaccination_name= (EditText) findViewById(R.id.vaccination_name);
        vaccination_quantity= (EditText) findViewById(R.id.vaccination_quantity);
        other_name= (EditText) findViewById(R.id.other_name);
        other_quantity= (EditText) findViewById(R.id.other_quantity);

        year.setEnabled(false);
        month.setEnabled(false);
        training_stock.setEnabled(false);
        extension.setEnabled(false);
        no_animals.setEnabled(false);
        medicine.setEnabled(false);
        animals_received_medicine.setEnabled(false);
        vaccination.setEnabled(false);
        no_animals_vaccine.setEnabled(false);
        others_specify.setEnabled(false);

        animal_present.setEnabled(false);
        fodder.setEnabled(false);
        area_cultivated.setEnabled(false);
        new_farmers.setEnabled(false);
        conitued_farmers.setEnabled(false);

        extension_support.setEnabled(false);
        medicine_name.setEnabled(false);
        medicine_quantity.setEnabled(false);
        vaccination_name.setEnabled(false);
        vaccination_quantity.setEnabled(false);
        other_name.setEnabled(false);
        other_quantity.setEnabled(false);


        save_livestock= (Button) findViewById(R.id.save_livestock);





        save_livestock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              finish();
            }
        });


        livestockDTOs = databaseHandlerNew.getLivestock_dataWithID(getIntent().getStringExtra("id"));

        year.setText(livestockDTOs.get(0).getPresent_year());
        month.setText(month_array[Integer.valueOf(livestockDTOs.get(0).getMonth_no())-1]);
        training_stock.setText(getYesNo(livestockDTOs.get(0).getInput_training()));
        extension.setText(getYesNo(livestockDTOs.get(0).getInput_extension_suport()));
        no_animals.setText(livestockDTOs.get(0).getInput_extension_suport_animal_no());
        medicine.setText(getYesNo(livestockDTOs.get(0).getInput_medicine()));
        animals_received_medicine.setText(livestockDTOs.get(0).getInput_medicine_animal_no());
        vaccination.setText(getYesNo(livestockDTOs.get(0).getInput_vaccination()));
        no_animals_vaccine.setText(livestockDTOs.get(0).getInput_vaccination_animal_no());
        others_specify.setText(getYesNo(livestockDTOs.get(0).getInput_other()));

        animal_present.setText(livestockDTOs.get(0).getAnimal_present_no());
        fodder.setText(getYesNo(livestockDTOs.get(0).getCultivating_fodder()));
        area_cultivated.setText(livestockDTOs.get(0).getCultivated_area_fodder());
        new_farmers.setText(getYesNo(livestockDTOs.get(0).getNew_farmer()));
        conitued_farmers.setText(getYesNo(livestockDTOs.get(0).getContinued_farmer()));

        extension_support.setText(livestockDTOs.get(0).getInput_extension_suport());
        medicine_name.setText(livestockDTOs.get(0).getMedicine_name_array());
        medicine_quantity.setText(livestockDTOs.get(0).getMedicine_qnty_array());
        vaccination_name.setText(livestockDTOs.get(0).getVaccination_name_array());
        vaccination_quantity.setText(livestockDTOs.get(0).getVaccination_qnty_array());
        other_name.setText(livestockDTOs.get(0).getOthera_name_array());
        other_quantity.setText(livestockDTOs.get(0).getOthera_qnty_array());

    }


    private String getYesNo(String val){

        if(val.equals("1")){
            return "Yes";
        }
        else{
            return "No";
        }

    }

}
