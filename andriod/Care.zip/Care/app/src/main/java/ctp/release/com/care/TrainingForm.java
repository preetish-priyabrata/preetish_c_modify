package ctp.release.com.care;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import ctp.release.com.care.DTO.CareDTO;
import ctp.release.com.care.DTO.ThematicDTO;
import ctp.release.com.care.Database.DatabaseHandlerNew;
import ctp.release.com.care.others.SharedPreferenceClass;
import ctp.release.com.care.others.VolleySingleton;

/**
 * Created by admin on 11-01-2018.
 */

public class TrainingForm extends AppCompatActivity {
    String [] thematic_intervation = {"HKG","Crop Diversification","LST","Post Harvest Management","poultry","Goatery","Diary","collective strenghtening","bcc"};
    String [] thematic_intervation_key;
    String [] month_array = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    String [] year_array = {"2017","2018"};
    String [] topic_array = {"please select thematic intervation"};
    String [] training_type_array = {"Fair/Mela","Group Interaction/FFS","Street play skit","Demosnstration","Exposure visit","Others(specify)"};
    String [] group_type_array = {"Women SHG","Farmer Group","General Partticipants","Other(Specify)"};
    String [] facilitator_array = {"CRP","MT","CBO","MEO"};

    ArrayList<String> get_eight;
    ArrayList<ThematicDTO> thematicDTOs ;
    ArrayList<CareDTO> careDTOs;
    boolean[] bol;
    EditText year,month,intervation,topics,training_date,time_training,no_participant_male,female_participant,
            covered,repeat_male,repeat_female,repeat_hhs,training_type,group_type,facilitator,external_res,remark_training;
    Button save_training;
    private int mYear, mMonth, mDay, mHour, mMinute;
    int i=0;
    String monthId="",thematic_id = "";
    AlertDialog dialog;
    ProgressDialog progressDialog;
    SharedPreferenceClass sharedPreferenceClass;
    GPSTracker mGPS;
    DatabaseHandlerNew databaseHandlerNew;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.training_form);
        progressDialog=new ProgressDialog(this);
        sharedPreferenceClass  = new SharedPreferenceClass(this);
        databaseHandlerNew = new DatabaseHandlerNew(this);
        mGPS = new GPSTracker(this);
        thematicDTOs = new ArrayList<ThematicDTO>();
        careDTOs = new ArrayList<CareDTO>();

        thematicDTOs = databaseHandlerNew.getThematic();
        thematic_id = thematicDTOs.get(0).getThematic_key();
        careDTOs = databaseHandlerNew.getCare(thematic_id);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        assert toolbar != null;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        year= (EditText) findViewById(R.id.year);
        month= (EditText) findViewById(R.id.month);
        intervation= (EditText) findViewById(R.id.intervation);
        topics= (EditText) findViewById(R.id.topics);
        training_date= (EditText) findViewById(R.id.training_date);
        time_training= (EditText) findViewById(R.id.time_training);
        no_participant_male= (EditText) findViewById(R.id.no_participant_male);
        female_participant= (EditText) findViewById(R.id.female_participant);
        covered= (EditText) findViewById(R.id.covered);
        repeat_male= (EditText) findViewById(R.id.repeat_male);
        repeat_female= (EditText) findViewById(R.id.repeat_female);
        repeat_hhs= (EditText) findViewById(R.id.repeat_hhs);
        training_type= (EditText) findViewById(R.id.training_type);
        group_type= (EditText) findViewById(R.id.group_type);
        facilitator= (EditText) findViewById(R.id.facilitator);
        external_res= (EditText) findViewById(R.id.external_res);
        remark_training= (EditText) findViewById(R.id.remark_training);
        save_training= (Button) findViewById(R.id.save_training);

        year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <year_array.length; i++) {
                    if (year_array[i].equals(year.getText().toString())) {
                        pos = i;
                    }
                }
                showYearList(year, "Please select year",
                        year_array, pos);
            }
        });



        month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <month_array.length; i++) {
                    if (month_array[i].equals(month.getText().toString())) {
                        pos = i;
                    }
                }
                showMonthList(month, "Please select month",
                        month_array, pos);
            }
        });

        thematic_intervation = new String[thematicDTOs.size()];
        thematic_intervation_key = new String[thematicDTOs.size()];
        for(int i=0;i<thematicDTOs.size();i++){
            thematic_intervation[i] = thematicDTOs.get(i).getThematic_name();
            thematic_intervation_key[i] = thematicDTOs.get(i).getThematic_key();
        }

        intervation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <thematic_intervation.length; i++) {
                    if (thematic_intervation[i].equals(intervation.getText().toString())) {
                        pos = i;
                    }
                }
                showThematicList(intervation, "Please select thematic innervation",
                        thematic_intervation, pos);
            }
        });




        topics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                topic_array = new String[careDTOs.size()];

                for(int i=0;i<careDTOs.size();i++){
                    topic_array[i] = careDTOs.get(i).getCare_training_name();

                }

                int pos = -1;
                for (int i = 0; i <topic_array.length; i++) {
                    if (topic_array[i].equals(topics.getText().toString())) {
                        pos = i;
                    }
                }
                showYearList(topics, "Please select topic",
                        topic_array, pos);
            }
        });

        training_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <training_type_array.length; i++) {
                    if (training_type_array[i].equals(training_type.getText().toString())) {
                        pos = i;
                    }
                }
                showYearList(training_type, "Please select training type",
                        training_type_array, pos);
            }
        });

        group_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <group_type_array.length; i++) {
                    if (group_type_array[i].equals(group_type.getText().toString())) {
                        pos = i;
                    }
                }
                showYearList(group_type, "Please select group",
                        group_type_array, pos);
            }
        });
        facilitator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* int pos = -1;
                for (int i = 0; i <facilitator_array.length; i++) {
                    if (facilitator_array[i].equals(facilitator.getText().toString())) {
                        pos = i;
                    }
                }
                showYearList(facilitator, "Please select",
                        facilitator_array, pos);*/
                bol = new boolean[facilitator_array.length];
                String[] getValue = facilitator.getText().toString().split(",");

                for(int i=0;i<facilitator_array.length;i++){
                    bol[i]= false;
                }

                for(int i=0;i<facilitator_array.length;i++){

                    for(int j=0;j<getValue.length;j++){
                        if (facilitator_array[i].equals(getValue[j])){
                            bol[i]=true;
                        }

                    }
                }

                showMultipleNum8("Please select", facilitator_array,bol);

            }
        });


        training_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get Current Date
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(TrainingForm.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                training_date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

        save_training.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mGPS.canGetLocation) {
                    sendDatabase();
                }
                else{
                    Toast.makeText(TrainingForm.this, "We can not get your location please enable your gps", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void sendDatabase() {

        Random r = new Random();
        int randomNumber = r.nextInt(1234567890);

        databaseHandlerNew.AddTraining_Form( sharedPreferenceClass.getValue_string("employee_id"),
        sharedPreferenceClass.getValue_string("userid"),
        getIntent().getStringExtra("dist"),
        getIntent().getStringExtra("block"),
        getIntent().getStringExtra("gp"),
        getIntent().getStringExtra("village"),
        String.valueOf(mGPS.getLatitude()),
        String.valueOf(mGPS.getLongitude()),
        monthId,
        year.getText().toString(),
        String.valueOf(randomNumber),
        thematic_id,
        topics.getText().toString(),
        training_date.getText().toString(),
        time_training.getText().toString(),
        no_participant_male.getText().toString(),
        female_participant.getText().toString(),
        covered.getText().toString(),
        repeat_male.getText().toString(),
        repeat_female.getText().toString(),
        repeat_hhs.getText().toString(),
        training_type.getText().toString(),
        group_type.getText().toString(),
        facilitator.getText().toString(),
        remark_training.getText().toString(),
        external_res.getText().toString());

        Toast.makeText(TrainingForm.this, "Submitted", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(TrainingForm.this,TrainingFormView.class);
        intent.putExtra("id",String.valueOf(randomNumber));
        startActivity(intent);
        finish();
    }


    private void submit() {
        progressDialog.show();
        progressDialog.setMessage("Loading...");
        String tag_json_req = "user_login";
        StringRequest data = new StringRequest(com.android.volley.Request.Method.POST,
                "http://tarinaodisha.com/care_api/index.php/api_care/care_api_crp/user_training_info/format/json",
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            Log.d(" response is ", response);

                            /*{
                                "status" = "true";
                                "userid" = "1";

                            }*/



                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject object= null;

                            if (jsonObject.getString("response_status").equals("1")){
                                Toast.makeText(TrainingForm.this, "Submitted", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                            else{
                                Toast.makeText(TrainingForm.this, "Please insert all data", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error.getMessage() == null) {
                    if (i < 3) {
                        Log.e("Retry due to error ", "for time : " + i);
                        i++;
                    } else  {
                        progressDialog.dismiss();
                        Toast.makeText(TrainingForm.this, "Check your network connection.",
                                Toast.LENGTH_LONG).show();
                    }
                } else
                    Toast.makeText(TrainingForm.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Password:admin@123
                Map<String, String> params = new HashMap<>();
                params.put("employee_id",sharedPreferenceClass.getValue_string("employee_id"));
                params.put("userid",sharedPreferenceClass.getValue_string("userid"));
                params.put("district_name",getIntent().getStringExtra("dist"));
                params.put("block_name",getIntent().getStringExtra("block"));

                params.put("GP_name",getIntent().getStringExtra("gp"));
                params.put("Village_name",getIntent().getStringExtra("village"));
                params.put("enter_lat", String.valueOf(mGPS.getLatitude()));
                params.put("enter_long", String.valueOf(mGPS.getLongitude()));
                params.put("month_no",monthId);

                params.put("present_year",year.getText().toString());
                params.put("your_id_delete_training_id","1");

                params.put("thematic_intervention_id",thematic_id);
                params.put("topics_covered",topics.getText().toString());
                params.put("event_date",training_date.getText().toString());
                params.put("duration_session",time_training.getText().toString());
                params.put("male_present",no_participant_male.getText().toString());
                params.put("female_present",female_participant.getText().toString());
                params.put("hhi_covered",covered.getText().toString());
                params.put("male_repeat",repeat_male.getText().toString());
                params.put("female_repeat",repeat_female.getText().toString());
                params.put("hhi_repeat",repeat_hhs.getText().toString());
                params.put("type_of_training",training_type.getText().toString());
                params.put("type_of_group",group_type.getText().toString());
                params.put("training_facilitator",facilitator.getText().toString());
                params.put("remark_detail",remark_training.getText().toString());
                params.put("external_person",external_res.getText().toString());









                Log.d("params are :", "" + params);

                return params;
            }
        };
        data.setRetryPolicy(new
                DefaultRetryPolicy(30000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance().getRequestQueue().add(data).addMarker(tag_json_req);


    }

    private void showMonthList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    monthId = String.valueOf(i+1);
                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }


    private void showYearList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    private void showThematicList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    thematic_id = thematic_intervation_key[i];

                                    careDTOs = databaseHandlerNew.getCare(thematic_id);

                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }


    protected void showMultipleNum8(String title,
                                    final String[] items, boolean[] bol) {
        @SuppressWarnings("rawtypes")


        final ArrayList<Integer> itemsSelected = new ArrayList();
        final ArrayList itemsNoSelected = new ArrayList();

        final ArrayList<String> item_name = new ArrayList<String>();
        get_eight = new ArrayList<String>();



        for(int i=0;i<bol.length;i++){
            if(bol[i]){
                itemsSelected.add(i);
            }
        }


        AlertDialog.Builder builder = new AlertDialog.Builder(TrainingForm.this);
        builder.setTitle(title);
        builder.setMultiChoiceItems(items, bol,
                new DialogInterface.OnMultiChoiceClickListener() {
                    @SuppressWarnings("unchecked")
                    @Override
                    public void onClick(DialogInterface dialog,
                                        int selectedItemId, boolean isSelected) {
                        if (isSelected) {
                            itemsSelected.add(selectedItemId);

                        }
                        else if (itemsSelected.contains(selectedItemId)) {
                            itemsSelected.remove(Integer.valueOf(selectedItemId));
                        }
                    }
                })
                .setPositiveButton("Done",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                // Your logic when OK button is clicked

                                for (int i = 0; i < itemsSelected.size(); i++) {



                                    get_eight.add(facilitator_array[itemsSelected.get(i)]);



                                }
                                  facilitator.setText(arraytoString(get_eight));




                            }
                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        });
        dialog = builder.create();
        dialog.show();

    }

    public static String arraytoString(List<String> language_arr) {
        String ret = "";
        if (language_arr.size() == 0) {
            ret = "";
        } else if (language_arr.size() == 1) {
            ret = language_arr.get(0);
        } else {
            for (int i = 0; i < language_arr.size(); i++) {
                if (i == language_arr.size() - 1) {
                    ret = ret + language_arr.get(i);
                } else {
                    ret = ret + language_arr.get(i) + ",";

                }
            }
        }


        return ret;
    }
}
