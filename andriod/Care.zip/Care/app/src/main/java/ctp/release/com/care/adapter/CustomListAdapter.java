package ctp.release.com.care.adapter;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

import ctp.release.com.care.FarmLand;
import ctp.release.com.care.HHI_Input_Output;
import ctp.release.com.care.Harvest_Lost_From;
import ctp.release.com.care.HhidList;
import ctp.release.com.care.Labour_Saving_From;
import ctp.release.com.care.Livestock;
import ctp.release.com.care.R;

/**
 * Created by admin on 07-01-2018.
 */

public class CustomListAdapter extends RecyclerView.Adapter<CustomListAdapter.MyViewHolder> {

    private final Activity context;
    ArrayList<HashMap<String, String>> taskdetails;
    ArrayList<String> pluses;
    private int i = 0;
    AlertDialog dialog;
    String select_to_fill = "";
    String village,dist,gp,block;

    String [] select_array = {"Crop Diversification",
            "Kitchen Garden",
            "Goatery",
            "Dairy",
            "Poultry",
            "PHL",
            "LST",
            "Input & Output"};

    public CustomListAdapter(Activity context, ArrayList<HashMap<String, String>> taskdetails, ArrayList<String> pluses, String village, String gp, String block, String dist) {
        this.taskdetails = taskdetails;
        this.pluses = pluses;
        this.village = village;
        this.dist = dist;
        this.gp = gp;
        this.block = block;
        this.context = context;
    }

    @Override
    public CustomListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view1 = LayoutInflater.from(context).inflate(R.layout.custom_hhid_list, parent, false);
        CustomListAdapter.MyViewHolder holder = new CustomListAdapter.MyViewHolder(view1);
        return holder;

    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        holder.hhi.setText(taskdetails.get(position).get("care_hhi_id"));
        holder.woman_farmer.setText(taskdetails.get(position).get("care_women_farmer"));
        holder.spouse.setText(taskdetails.get(position).get("care_spouse_name"));

        holder.editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = -1;
                for (int i = 0; i <select_array.length; i++) {
                    if (select_array[i].equals(holder.editText.getText().toString())) {
                        pos = i;
                    }
                }
                showCoverageList(holder.editText, "Please select form",
                        select_array, pos);
            }
        });
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(select_to_fill.equals("")){
                    Toast.makeText(context, "Please select a from type", Toast.LENGTH_SHORT).show();
                }
                else if(select_to_fill.equals("Input & Output")){
                    context.startActivity(new Intent(context, HHI_Input_Output.class)
                    .putExtra("village",village)
                    .putExtra("gp",gp)
                    .putExtra("block",block)
                    .putExtra("dist",dist)
                            .putExtra("care_hhi_id",taskdetails.get(position).get("care_hhi_id"))
                            .putExtra("care_women_farmer",taskdetails.get(position).get("care_women_farmer"))
                            .putExtra("care_spouse_name",taskdetails.get(position).get("care_spouse_name")));
                }
                else if(select_to_fill.equals("Crop Diversification")){
                    context.startActivity(new Intent(context, FarmLand.class)
                    .putExtra("Pluses",pluses)
                            .putExtra("page","Crop Diversification")
                            .putExtra("status","1")
                            .putExtra("village",village)
                            .putExtra("gp",gp)
                            .putExtra("block",block)
                            .putExtra("dist",dist)
                            .putExtra("care_hhi_id",taskdetails.get(position).get("care_hhi_id"))
                            .putExtra("care_women_farmer",taskdetails.get(position).get("care_women_farmer"))
                            .putExtra("care_spouse_name",taskdetails.get(position).get("care_spouse_name")));
                }
                else if(select_to_fill.equals("PHL")){
                    context.startActivity(new Intent(context, Harvest_Lost_From.class)
                            .putExtra("Pluses",pluses)
                            .putExtra("page","Farmland")
                            .putExtra("status","1")
                            .putExtra("village",village)
                            .putExtra("gp",gp)
                            .putExtra("block",block)
                            .putExtra("dist",dist)
                            .putExtra("care_hhi_id",taskdetails.get(position).get("care_hhi_id"))
                            .putExtra("care_women_farmer",taskdetails.get(position).get("care_women_farmer"))
                            .putExtra("care_spouse_name",taskdetails.get(position).get("care_spouse_name")));
                }
                else if(select_to_fill.equals("LST")){
                    context.startActivity(new Intent(context, Labour_Saving_From.class)
                            .putExtra("Pluses",pluses)
                            .putExtra("page","Farmland")
                            .putExtra("status","1")
                            .putExtra("village",village)
                            .putExtra("gp",gp)
                            .putExtra("block",block)
                            .putExtra("dist",dist)
                            .putExtra("care_hhi_id",taskdetails.get(position).get("care_hhi_id"))
                            .putExtra("care_women_farmer",taskdetails.get(position).get("care_women_farmer"))
                            .putExtra("care_spouse_name",taskdetails.get(position).get("care_spouse_name")));
                }
                else if(select_to_fill.equals("Kitchen Garden")){
                    context.startActivity(new Intent(context, FarmLand.class)
                            .putExtra("Pluses",pluses)
                            .putExtra("village",village)
                            .putExtra("gp",gp)
                            .putExtra("block",block)
                            .putExtra("dist",dist)
                            .putExtra("page","Kitchen Garden")
                            .putExtra("status","2")
                            .putExtra("care_hhi_id",taskdetails.get(position).get("care_hhi_id"))
                            .putExtra("care_women_farmer",taskdetails.get(position).get("care_women_farmer"))
                            .putExtra("care_spouse_name",taskdetails.get(position).get("care_spouse_name")));
                }

                else if(select_to_fill.equals("Goatery")){
                    context.startActivity(new Intent(context, Livestock.class)
                            .putExtra("Pluses",pluses)
                            .putExtra("village",village)
                            .putExtra("gp",gp)
                            .putExtra("block",block)
                            .putExtra("dist",dist)
                            .putExtra("page","Livestock")
                            .putExtra("status","1")
                            .putExtra("care_hhi_id",taskdetails.get(position).get("care_hhi_id"))
                            .putExtra("care_women_farmer",taskdetails.get(position).get("care_women_farmer"))
                            .putExtra("care_spouse_name",taskdetails.get(position).get("care_spouse_name")));
                }
                else if(select_to_fill.equals("Dairy")){
                    context.startActivity(new Intent(context, Livestock.class)
                            .putExtra("Pluses",pluses)
                            .putExtra("village",village)
                            .putExtra("gp",gp)
                            .putExtra("block",block)
                            .putExtra("dist",dist)
                            .putExtra("page","Livestock")
                            .putExtra("status","2")
                            .putExtra("care_hhi_id",taskdetails.get(position).get("care_hhi_id"))
                            .putExtra("care_women_farmer",taskdetails.get(position).get("care_women_farmer"))
                            .putExtra("care_spouse_name",taskdetails.get(position).get("care_spouse_name")));
                }
                else if(select_to_fill.equals("Poultry")){
                    context.startActivity(new Intent(context, Livestock.class)
                            .putExtra("Pluses",pluses)
                            .putExtra("village",village)
                            .putExtra("gp",gp)
                            .putExtra("block",block)
                            .putExtra("dist",dist)
                            .putExtra("page","Livestock")
                            .putExtra("status","3")
                            .putExtra("care_hhi_id",taskdetails.get(position).get("care_hhi_id"))
                            .putExtra("care_women_farmer",taskdetails.get(position).get("care_women_farmer"))
                            .putExtra("care_spouse_name",taskdetails.get(position).get("care_spouse_name")));
                }
                else {
                    context.startActivity(new Intent(context, Livestock.class));

                }

            }
        });


    }
    private void showCoverageList(final EditText text3, String s3, final String[] coverage, int pos) {
        final ArrayList itemsSelected = new ArrayList();

        String select;
        final ArrayList<String> item_name = new ArrayList<String>();
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(s3);
        builder.setSingleChoiceItems(coverage, pos, new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId) {
                        itemsSelected.add(selectedItemId);

                        if (itemsSelected.size() > 0) {
                            text3.setText(coverage[(Integer) itemsSelected.get(0)]);

                            for (i = 0; i < coverage.length; i++) {
                                if (coverage[i] == coverage[(Integer) itemsSelected.get(0)]) {
                                    //  Getprojectlist(client_id[i]);
                                    select_to_fill = select_array[i];
                                }
                            }
                        } else {

                            text3.setText("");

                        }
                        dialog.dismiss();
                    }
                }

        );
        dialog = builder.create();
        dialog.show();
    }
    @Override
    public int getItemCount() {
        return taskdetails.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView hhi, woman_farmer, spouse;
        EditText editText;
        Button button;

        public MyViewHolder(View view1) {
            super(view1);
            hhi = (TextView) view1.findViewById(R.id.hhi);
            woman_farmer = (TextView) view1.findViewById(R.id.woman_farmer);
            spouse = (TextView) view1.findViewById(R.id.spouse_name);
            editText = (EditText) view1.findViewById(R.id.spinner);
            button= (Button) view1.findViewById(R.id.button);




        }
    }
}