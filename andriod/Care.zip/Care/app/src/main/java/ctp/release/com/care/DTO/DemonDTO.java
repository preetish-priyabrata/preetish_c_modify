package ctp.release.com.care.DTO;

/**
 * Created by admin on 14-01-2018.
 */

public class DemonDTO {
    String id_demo;
    String subject_demo;

    public String getSubject_demo() {
        return subject_demo;
    }

    public void setSubject_demo(String subject_demo) {
        this.subject_demo = subject_demo;
    }

    public String getId_demo() {
        return id_demo;
    }

    public void setId_demo(String id_demo) {
        this.id_demo = id_demo;
    }
}
